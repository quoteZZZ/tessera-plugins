// @bun
// plugins/log/locales/en.ts
var en = {
  "tessera.log.title": "Log",
  "tessera.log.activated": "Log ready",
  "tessera.log.levelChanged": "Log level set to {level}",
  "web.panel.log": "Log",
  "web.log.level": "Level",
  "web.log.scope": "Scope",
  "web.log.all": "All",
  "web.log.search": "Search key or params",
  "web.log.clear": "Clear",
  "web.log.follow": "Follow",
  "web.log.openDir": "Open Log Folder",
  "web.log.empty": "No entries",
  "web.log.trace": "trace",
  "web.log.debug": "debug",
  "web.log.info": "info",
  "web.log.warn": "warn",
  "web.log.error": "error",
  "tessera.log.ns.ai": "AI",
  "tessera.log.ns.manuscript": "Manuscript",
  "tessera.log.ns.i18n": "Languages",
  "tessera.log.ns.foundation": "Foundation",
  "tessera.log.ns.codex": "Story bible",
  "tessera.log.ns.log": "Log",
  "tessera.log.ns.pipeline": "Review",
  "tessera.log.ns.transfer": "Import/export",
  "tessera.log.ns.admin": "Settings",
  "tessera.log.ns.trash": "Trash",
  "tessera.log.ns.market": "Marketplace",
  "tessera.log.ns.kernel": "Kernel",
  "tessera.log.ns.host": "App",
  "tessera.log.op.list": "List documents",
  "tessera.log.op.open": "Open document",
  "tessera.log.op.save": "Save",
  "tessera.log.op.create": "Create",
  "tessera.log.op.remove": "Delete",
  "tessera.log.op.restore": "Restore",
  "tessera.log.op.digest": "Read digests",
  "tessera.log.op.search": "Search",
  "tessera.log.op.snapshot": "Snapshot",
  "tessera.log.op.rollback": "Roll back",
  "tessera.log.op.chat": "AI chat",
  "tessera.log.op.models": "Read models",
  "tessera.log.op.review": "Review",
  "tessera.log.op.export": "Export",
  "tessera.log.ns.op": "Operation"
};

// plugins/log/locales/zh-cn.ts
var zhCN = {
  "tessera.log.title": "\u65E5\u5FD7",
  "tessera.log.activated": "\u65E5\u5FD7\u5DF2\u5C31\u7EEA",
  "tessera.log.levelChanged": "\u65E5\u5FD7\u7EA7\u522B\u5207\u6362\u4E3A {level}",
  "web.panel.log": "\u65E5\u5FD7",
  "web.log.level": "\u7EA7\u522B",
  "web.log.scope": "\u8303\u56F4",
  "web.log.all": "\u5168\u90E8",
  "web.log.search": "\u641C\u7D22\u952E\u540D\u6216\u53C2\u6570",
  "web.log.clear": "\u6E05\u7A7A",
  "web.log.follow": "\u8DDF\u968F",
  "web.log.openDir": "\u6253\u5F00\u65E5\u5FD7\u76EE\u5F55",
  "web.log.empty": "\u6682\u65E0\u8BB0\u5F55",
  "web.log.trace": "trace",
  "web.log.debug": "debug",
  "web.log.info": "info",
  "web.log.warn": "warn",
  "web.log.error": "error",
  "tessera.log.ns.ai": "AI",
  "tessera.log.ns.manuscript": "\u6587\u7A3F",
  "tessera.log.ns.i18n": "\u591A\u8BED\u8A00",
  "tessera.log.ns.foundation": "\u57FA\u7840",
  "tessera.log.ns.codex": "\u8BBE\u5B9A\u5E93",
  "tessera.log.ns.log": "\u65E5\u5FD7",
  "tessera.log.ns.pipeline": "\u5BA1\u8BFB",
  "tessera.log.ns.transfer": "\u5BFC\u5165\u5BFC\u51FA",
  "tessera.log.ns.admin": "\u8BBE\u7F6E",
  "tessera.log.ns.trash": "\u56DE\u6536\u7AD9",
  "tessera.log.ns.market": "\u63D2\u4EF6\u5E02\u573A",
  "tessera.log.ns.kernel": "\u5185\u6838",
  "tessera.log.ns.host": "\u5E94\u7528",
  "tessera.log.op.list": "\u5217\u6587\u7A3F",
  "tessera.log.op.open": "\u6253\u5F00\u6587\u7A3F",
  "tessera.log.op.save": "\u4FDD\u5B58",
  "tessera.log.op.create": "\u65B0\u5EFA",
  "tessera.log.op.remove": "\u5220\u9664",
  "tessera.log.op.restore": "\u6062\u590D",
  "tessera.log.op.digest": "\u8BFB\u6458\u8981",
  "tessera.log.op.search": "\u641C\u7D22",
  "tessera.log.op.snapshot": "\u5EFA\u5FEB\u7167",
  "tessera.log.op.rollback": "\u56DE\u6EDA",
  "tessera.log.op.chat": "AI \u5BF9\u8BDD",
  "tessera.log.op.models": "\u8BFB\u6A21\u578B\u6E05\u5355",
  "tessera.log.op.review": "\u5BA1\u8BFB",
  "tessera.log.op.export": "\u5BFC\u51FA",
  "tessera.log.ns.op": "\u64CD\u4F5C"
};

// plugins/log/src/index.ts
var LEVELS = new Set(["trace", "debug", "info", "warn", "error"]);
var manifest = {
  apiVersion: 2,
  id: "tessera.log",
  kind: "official",
  version: "0.1.0",
  title: "tessera.log.title",
  activation: ["onStartup"],
  requires: { services: ["log"], plugins: [] },
  contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] }
};
var definition = {
  manifest,
  activate(ctx) {
    const hub = ctx.services.get("log");
    ctx.handle("query", (params) => {
      const request = params ?? {};
      const level = typeof request.level === "string" && LEVELS.has(request.level) ? request.level : undefined;
      const limit = typeof request.limit === "number" ? Math.min(2000, Math.max(1, Math.trunc(request.limit))) : 500;
      try {
        return {
          ok: true,
          value: {
            records: hub.query({
              ...level === undefined ? {} : { level },
              ...typeof request.ns === "string" ? { ns: request.ns } : {},
              ...typeof request.since === "number" ? { since: request.since } : {},
              limit
            }),
            level: hub.level(),
            size: hub.size()
          }
        };
      } catch {
        return { ok: false, reason: "io.failed" };
      }
    });
    ctx.handle("setLevel", (params) => {
      const { level } = params ?? {};
      if (typeof level !== "string" || !LEVELS.has(level))
        return { ok: false, reason: "params.invalid" };
      hub.setLevel(level);
      ctx.log("info", "tessera.log.levelChanged", { level });
      return { ok: true, value: { level: hub.level() } };
    });
    ctx.handle("clear", () => {
      hub.clear();
      return { ok: true, value: { size: hub.size() } };
    });
    ctx.log("info", "tessera.log.activated", { size: hub.size() });
  }
};
export {
  definition
};
