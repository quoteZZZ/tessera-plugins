/**
 * 日志插件的前端部分：底部「日志」面板。
 *
 * 数据从 `tessera.log/query` 拿——面板不认识文件，也不认识 hub，
 * 只认识一条条记录。级别下拉与跟随开关是本地状态（存 localStorage）。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  const LEVELS = ["trace", "debug", "info", "warn", "error"];
  const STORE = "tessera.logPanel";
  const POLL_MS = 900;

  const readStore = () => {
    try {
      const raw = JSON.parse(localStorage.getItem(STORE) ?? "{}");
      return raw !== null && typeof raw === "object" ? raw : {};
    } catch {
      return {};
    }
  };

  let state = { level: "info", scope: "", follow: true, ...readStore() };
  const save = () => {
    try {
      localStorage.setItem(STORE, JSON.stringify(state));
    } catch {
      /* 隐私模式 */
    }
  };

  /* 面板被挂进 DOM 之后才知道自己在不在屏幕上：首次刷新交给 onMount 触发 */
  let pull = null;

  /** 时间只留时分秒：这一屏看的是"刚才发生了什么" */
  const clock = (ts) => {
    const date = new Date(ts);
    const pad = (n, w = 2) => String(n).padStart(w, "0");
    return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}.${pad(date.getMilliseconds(), 3)}`;
  };

/* 日志来源显示成人话：内核的 ns 是 kernel.tessera.<plugin>，那是给开发者看的。
   文案在词表里，原始值留在 title 上，排查时悬停就能拿到 */
const NS_KEYS = {
  "kernel.tessera.ai": "tessera.log.ns.ai",
  "kernel.tessera.manuscript": "tessera.log.ns.manuscript",
  "kernel.tessera.i18n": "tessera.log.ns.i18n",
  "kernel.tessera.foundation": "tessera.log.ns.foundation",
  "kernel.tessera.codex": "tessera.log.ns.codex",
  "kernel.tessera.log": "tessera.log.ns.log",
  "kernel.tessera.pipeline": "tessera.log.ns.pipeline",
  "kernel.tessera.transfer": "tessera.log.ns.transfer",
  "kernel.tessera.admin": "tessera.log.ns.admin",
  "kernel.tessera.trash": "tessera.log.ns.trash",
  "kernel.tessera.market": "tessera.log.ns.market",
  kernel: "tessera.log.ns.kernel",
  rpc: "tessera.log.ns.op",
  host: "tessera.log.ns.host",
};

/* 同一个插件有两种写法：来源列是 kernel.tessera.ai，日志参数里是 tessera.ai */
const pluginName = (id) => {
  const bare = String(id).replace(/^kernel\./, "");
  const key = NS_KEYS["kernel." + bare] ?? NS_KEYS[bare];
  return key === undefined ? bare : ui.t(key);
};

const nsName = (ns) => pluginName(ns);

/* RPC 方法名也翻成人话：tessera.manuscript/docsList 对用户没有意义，
   没收录的方法退回最后一段（docsList），仍然比全名短 */
const METHOD_KEYS = {
  "tessera.manuscript/docsList": "tessera.log.op.list",
  "tessera.manuscript/docOpen": "tessera.log.op.open",
  "tessera.manuscript/docSave": "tessera.log.op.save",
  "tessera.manuscript/docCreate": "tessera.log.op.create",
  "tessera.manuscript/docRemove": "tessera.log.op.remove",
  "tessera.manuscript/docRestore": "tessera.log.op.restore",
  "tessera.manuscript/docDigest": "tessera.log.op.digest",
  "tessera.manuscript/projectSearch": "tessera.log.op.search",
  "tessera.manuscript/docSnapshot": "tessera.log.op.snapshot",
  "tessera.manuscript/docRestoreSnapshot": "tessera.log.op.rollback",
  "tessera.ai/chat": "tessera.log.op.chat",
  "tessera.ai/chatStream": "tessera.log.op.chat",
  "tessera.ai/listModels": "tessera.log.op.models",
  "tessera.pipeline/reviewDoc": "tessera.log.op.review",
  "tessera.transfer/exportProject": "tessera.log.op.export",
};

const methodName = (method) => {
  const key = METHOD_KEYS[method];
  if (key !== undefined) return ui.t(key);
  return String(method).split("/").pop() ?? String(method);
};



  const rowOf = (record) => {
    const row = document.createElement("li");
    row.className = "log-row";
    row.dataset.level = record.level;

    const time = document.createElement("span");
    time.className = "log-time";
    time.textContent = clock(record.ts);

    const level = document.createElement("span");
    level.className = "log-level";
    level.textContent = record.level;

    const ns = document.createElement("span");
    ns.className = "log-ns";
    ns.textContent = nsName(record.ns);
    ns.title = record.ns;

    // 调用链：同一次 RPC 带出的几行共用一个 id，扫这一列就知道它们是一伙的
    const req = document.createElement("span");
    req.className = "log-req";
    req.textContent = record.reqId ?? "";

    const msg = document.createElement("span");
    msg.className = "log-msg";
    // 键在仓库里，文案在词表里：两边都不写死
    // pluginId 参数先换成中文名，否则"已就绪"前面挂的是 tessera.i18n
    const params = record.params === undefined
      ? undefined
      : {
          ...record.params,
          ...(typeof record.params.pluginId === "string" ? { pluginId: pluginName(record.params.pluginId) } : {}),
          ...(typeof record.params.method === "string" ? { method: methodName(record.params.method) } : {}),
        };
    const text = ui.t(record.key, params);
    msg.textContent = text === record.key && params === undefined ? record.key : text;
    if (record.repeat !== undefined && record.repeat > 1) {
      const repeat = document.createElement("span");
      repeat.className = "log-repeat";
      repeat.textContent = `×${record.repeat}`;
      msg.append(repeat);
    }
    if (record.reqId !== undefined) row.title = record.reqId;

    row.append(time, level, ns, req, msg);
    return row;
  };

  const build = () => {
    const root = document.createElement("div");
    root.className = "log-panel";

    const bar = document.createElement("div");
    bar.className = "log-toolbar";

    const level = document.createElement("label");
    level.className = "log-field";
    level.append(ui.t("web.log.level"));
    const levelSelect = document.createElement("select");
    levelSelect.className = "log-select";
    for (const item of LEVELS) {
      const option = document.createElement("option");
      option.value = item;
      option.textContent = ui.t(`web.log.${item}`);
      levelSelect.append(option);
    }
    levelSelect.value = state.level;
    level.append(levelSelect);

    const scope = document.createElement("label");
    scope.className = "log-field";
    scope.append(ui.t("web.log.scope"));
    const scopeSelect = document.createElement("select");
    scopeSelect.className = "log-select";
    const all = document.createElement("option");
    all.value = "";
    all.textContent = ui.t("web.log.all");
    scopeSelect.append(all);
    for (const ns of ["host", "kernel", "tessera.ai", "tessera.manuscript", "tessera.transfer"]) {
      const option = document.createElement("option");
      option.value = ns;
      option.textContent = ns;
      scopeSelect.append(option);
    }
    scopeSelect.value = state.scope;
    scope.append(scopeSelect);

    // 三个动作都是"一眼能认"的图形，写文字会把工具条挤到换行
    const follow = document.createElement("button");
    follow.type = "button";
    follow.className = "log-btn";
    follow.dataset.active = String(state.follow);
    follow.title = ui.t("web.log.follow");
    follow.setAttribute("aria-label", ui.t("web.log.follow"));
    follow.innerHTML = window.TesseraIcons?.svg("arrowDown") ?? "";

    // 搜索只筛已拿到的这批（500 条）：跨文件的历史检索是另一个功能
    const find = document.createElement("input");
    find.type = "search";
    find.className = "log-find";
    find.placeholder = ui.t("web.log.search");
    find.value = state.needle ?? "";
    find.addEventListener("input", () => {
      state = { ...state, needle: find.value };
      lastKey = "";
      void refresh();
    });

    const clear = document.createElement("button");
    clear.type = "button";
    clear.className = "log-btn";
    clear.title = ui.t("web.log.clear");
    clear.setAttribute("aria-label", ui.t("web.log.clear"));
    clear.innerHTML = window.TesseraIcons?.svg("trash") ?? "";

    const open = document.createElement("button");
    open.type = "button";
    open.className = "log-btn";
    open.title = ui.t("web.log.openDir");
    open.setAttribute("aria-label", ui.t("web.log.openDir"));
    open.innerHTML = window.TesseraIcons?.svg("folder") ?? "";
    // 浏览器形态没有"打开目录"这件事，就不给按钮
    const bridge = window.tesseraDesktop;
    if (bridge === undefined || typeof bridge.openLogs !== "function") open.hidden = true;

    bar.append(level, scope, find, follow, clear, open);

    const list = document.createElement("ul");
    list.className = "log-list";
    const empty = document.createElement("p");
    empty.className = "log-empty";
    empty.textContent = ui.t("web.log.empty");

    root.append(bar, list, empty);

    let timer = null;
    let lastKey = "";

    const refresh = async () => {
      if (!root.isConnected) {
        if (timer !== null) clearInterval(timer);
        return;
      }
      const res = await ui.call("tessera.log/query", {
        level: state.level,
        ...(state.scope === "" ? {} : { ns: state.scope }),
        limit: 500,
      });
      if (!res?.ok) return;
      const records = res.value.records ?? [];
      const needle = (state.needle ?? "").trim().toLowerCase();
      const shown = needle === ""
        ? records
        : records.filter((record) => {
            const text = ui.t(record.key, record.params);
            return `${record.ns} ${record.key} ${record.level} ${text}`.toLowerCase().includes(needle);
          });
      // 记录没变就别动 DOM：每秒重建 500 行会让滚动和选中都抖
      const fingerprint = `${shown.length}:${shown[shown.length - 1]?.ts ?? 0}:${needle}`;
      if (fingerprint === lastKey) return;
      lastKey = fingerprint;

      const stick = state.follow && list.parentElement !== null;
      list.replaceChildren(...shown.map(rowOf));
      empty.hidden = shown.length > 0;
      if (stick) list.scrollTop = list.scrollHeight;
    };

    levelSelect.addEventListener("change", () => {
      state = { ...state, level: levelSelect.value };
      save();
      lastKey = "";
      // 级别是"接下来留多少"：必须告诉宿主，否则选 debug 也只是看到 info
      void ui.call("tessera.log/setLevel", { level: state.level }).then(() => refresh());
    });
    scopeSelect.addEventListener("change", () => {
      state = { ...state, scope: scopeSelect.value };
      save();
      lastKey = "";
      void refresh();
    });
    follow.addEventListener("click", () => {
      state = { ...state, follow: !state.follow };
      follow.dataset.active = String(state.follow);
      save();
      if (state.follow) list.scrollTop = list.scrollHeight;
    });
    clear.addEventListener("click", async () => {
      await ui.call("tessera.log/clear", {});
      lastKey = "";
      void refresh();
    });
    open.addEventListener("click", () => bridge?.openLogs?.());

    timer = setInterval(() => void refresh(), POLL_MS);
    pull = refresh;
    return root;
  };

  ui.registerPanel({
    id: "log",
    titleKey: "web.panel.log",
    render: () => build(),
    onMount: () => {
      void (async () => {
        // 只在宿主级别与上次选择不一致时改一次：
        // 每次开面板都调 setLevel 会平白写一条"级别切换"的日志
        const current = await ui.call("tessera.log/query", { limit: 1 });
        if (current?.ok && current.value.level !== state.level) {
          await ui.call("tessera.log/setLevel", { level: state.level });
        }
        await pull?.();
      })();
    },
  });
}
