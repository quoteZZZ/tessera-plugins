/**
 * 插件管理器：底部「插件」页签。
 *
 * 一行的信息来自两个真相：`kernel/plugins`（运行时：版本、类型、状态、声明了什么）
 * 与 `tessera.admin/getSettings`（配置：开没开、授了什么权）。只信一边就会出现
 * "配置说开着、运行时其实 failed" 这种看不出来的状态。
 *
 * 授权在这里就能改（走 admin/setGrant），不必让人去手写 JSON。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  const expanded = new Set();
  /** 改过启停、但还没重启的插件：只写进配置，运行中的树不会立刻变 */
  const pendingRestart = new Set();
  let countHost = null;
  let listHost = null;
  let catalogHost = null;
  let note = null;
  let root = null;
  let search = null;
  let pull = null;
  /** 远程目录：只读展示；安装走 admin/installFromUrl */
  let catalogEntries = [];
  let catalogLoaded = false;

  /** 合并两个来源；插件没注册（只在配置里）也要能关掉 */
  const collect = async () => {
    const [runtime, config] = await Promise.all([
      ui.call("kernel/plugins", {}),
      ui.call("tessera.admin/getSettings", {}),
    ]);
    const running = new Map();
    for (const info of Array.isArray(runtime) ? runtime : []) running.set(info.id, info);

    const grants = new Map();
    for (const entry of config?.value?.grants ?? []) grants.set(entry.pluginId, [...entry.capabilities]);

    const entries = new Map();
    for (const row of config?.value?.plugins ?? []) {
      entries.set(row.id, { id: row.id, enabled: row.enabled === true, caps: grants.get(row.id) ?? [] });
    }
    for (const [id, info] of running) {
      entries.set(id, { ...(entries.get(id) ?? { id, enabled: false, caps: grants.get(id) ?? [] }), id, info });
    }
    return [...entries.values()].sort((a, b) => {
      if (a.enabled !== b.enabled) return a.enabled ? -1 : 1;
      return a.id.localeCompare(b.id);
    });
  };

  const chip = (text, onRemove) => {
    const node = document.createElement("span");
    node.className = "cap-chip";
    const label = document.createElement("span");
    label.textContent = text;
    node.append(label);
    if (onRemove !== undefined) {
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "cap-remove";
      remove.textContent = "×";
      remove.title = ui.t("web.plugins.removeGrant");
      remove.addEventListener("click", onRemove);
      node.append(remove);
    }
    return node;
  };

  const line = (label, values) => {
    const row = document.createElement("div");
    row.className = "plugin-detail-line";
    const key = document.createElement("span");
    key.className = "plugin-detail-key";
    key.textContent = ui.t(label);
    const value = document.createElement("span");
    value.className = "plugin-detail-value";
    if (values.length === 0) {
      value.textContent = ui.t("web.plugins.none");
      value.dataset.empty = "true";
    } else {
      for (const item of values) value.append(chip(item));
    }
    row.append(key, value);
    return row;
  };

  /** 展开区：状态 / 激活事件 / 声明能力 / 已授权（可增删）/ 导出 */
  const detailOf = (entry, afterChange) => {
    const box = document.createElement("div");
    box.className = "plugin-detail";

    const info = entry.info;
    box.append(
      line("web.plugins.status", info?.status ? [info.status] : []),
      line("web.plugins.activation", info?.activation ?? []),
      line("web.plugins.declared", info?.capabilities ?? []),
      line("web.plugins.exposes", info?.exposes ?? []),
    );

    const granted = document.createElement("div");
    granted.className = "plugin-detail-line";
    const key = document.createElement("span");
    key.className = "plugin-detail-key";
    key.textContent = ui.t("web.plugins.granted");
    const value = document.createElement("div");
    value.className = "plugin-detail-value";

    const write = async (caps) => {
      const res = await ui.call("tessera.admin/setGrant", { pluginId: entry.id, capabilities: caps });
      if (!res?.ok) {
        ui.toast("web.status.error", "bad");
        return false;
      }
      entry.caps = caps;
      afterChange?.();
      return true;
    };

    const paint = () => {
      value.replaceChildren();
      if (entry.caps.length === 0) {
        const none = document.createElement("span");
        none.className = "plugin-detail-empty";
        none.textContent = ui.t("web.plugins.none");
        value.append(none);
      }
      for (const cap of entry.caps) {
        value.append(chip(cap, () => void write(entry.caps.filter((item) => item !== cap)).then(paint)));
      }
      value.append(addGrant(entry, write, paint));
    };
    paint();

    granted.append(key, value);
    box.append(granted);
    return box;
  };

  /** 加一条授权：输入框 + 添加。能力串没有白名单，写错会在下次启动被 manifest 校验拒掉 */
  const addGrant = (entry, write, paint) => {
    const wrap = document.createElement("span");
    wrap.className = "cap-add";
    const input = document.createElement("input");
    input.type = "text";
    input.className = "cap-input";
    input.placeholder = ui.t("web.plugins.addGrant");
    input.spellcheck = false;
    const add = document.createElement("button");
    add.type = "button";
    add.className = "cap-add-btn";
    add.textContent = "+";
    add.title = ui.t("web.plugins.addGrant");
    add.addEventListener("click", async () => {
      const cap = input.value.trim();
      if (cap === "" || entry.caps.includes(cap)) return;
      const ok = await write([...entry.caps, cap]);
      if (ok) {
        input.value = "";
        paint();
      }
    });
    wrap.append(input, add);
    return wrap;
  };

  const rowOf = (entry, afterChange) => {
    const item = document.createElement("li");
    item.className = "plugin-row";
    item.dataset.enabled = String(entry.enabled);
    item.dataset.open = String(expanded.has(entry.id));

    const head = document.createElement("div");
    head.className = "plugin-head";

    const caret = document.createElement("button");
    caret.type = "button";
    caret.className = "plugin-caret";
    caret.setAttribute("aria-expanded", String(expanded.has(entry.id)));
    caret.innerHTML = window.TesseraIcons?.svg("chevronRight") ?? "";
    caret.addEventListener("click", () => {
      if (expanded.has(entry.id)) expanded.delete(entry.id);
      else expanded.add(entry.id);
      afterChange?.();
    });

    const main = document.createElement("div");
    main.className = "plugin-main";

    const name = document.createElement("span");
    name.className = "plugin-name";
    name.textContent = entry.info?.title ? ui.t(entry.info.title) : entry.id;

    const badge = document.createElement("span");
    badge.className = "plugin-badge";
    badge.dataset.kind = entry.info?.kind ?? "official";
    badge.textContent = ui.t(entry.info?.kind === "community" ? "web.plugins.community" : "web.plugins.official");

    const meta = document.createElement("span");
    meta.className = "plugin-meta";
    /* 右栏只有 300px：id 放不下，截断成 "tessera.admi… · v…" 两头都读不出。
       id 挪进 title，行内只留版本；非 active 时补状态 */
    const bits = entry.info?.version ? [`v${entry.info.version}`] : [];
    if (entry.info?.status && entry.info.status !== "active") bits.push(entry.info.status);
    meta.textContent = bits.join("  ·  ");
    meta.title = entry.id;

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "switch";
    toggle.setAttribute("role", "switch");
    toggle.setAttribute("aria-checked", String(entry.enabled));
    toggle.title = ui.t(entry.enabled ? "web.plugins.enabled" : "web.plugins.disabled");
    toggle.addEventListener("click", async () => {
      const next = !entry.enabled;
      const res = await ui.call("tessera.admin/setPluginEnabled", { id: entry.id, enabled: next });
      if (!res?.ok) {
        ui.toast("web.status.error", "bad");
        return;
      }
      entry.enabled = next;
      pendingRestart.add(entry.id);
      note.hidden = false;
      afterChange?.();
    });

    /* 名称一排、描述一排：VSCode 的扩展列表也是这个结构，
       一行塞下名称+徽章+版本+描述，窄侧栏里会挤成一坨 */
    const titleRow = document.createElement("div");
    titleRow.className = "plugin-title-row";
    titleRow.append(name, badge, meta);
    /* 启用 ≠ 生效：改完只是写进配置，必须重启。逐行标出来，
       否则用户会以为"开关变了但没反应"是坏的 */
    if (pendingRestart.has(entry.id)) {
      const pending = document.createElement("span");
      pending.className = "plugin-pending";
      pending.textContent = ui.t("web.plugins.pending");
      pending.title = ui.t("web.plugins.restartHint");
      titleRow.append(pending);
    }
    main.append(titleRow);

    const descKey = `web.plugins.desc.${entry.id}`;
    const descText = ui.t(descKey);
    if (descText !== descKey) {
      const desc = document.createElement("span");
      desc.className = "plugin-desc";
      desc.textContent = descText;
      main.append(desc);
    }

    head.append(caret, main, toggle);
    item.append(head);
    if (expanded.has(entry.id)) item.append(detailOf(entry, afterChange));
    return item;
  };

  const catalogUrl = () => String(window.__TESSERA__?.catalogUrl ?? "");

  const loadCatalog = async () => {
    if (catalogLoaded || catalogHost === null) return;
    const url = catalogUrl();
    if (url === "") return;
    const res = await ui.call("tessera.admin/loadCatalog", { url }).catch(() => null);
    if (res?.ok !== true) return;
    catalogEntries = Array.isArray(res.value) ? res.value : [];
    catalogLoaded = true;
  };

  const renderCatalog = (entries) => {
    if (catalogHost === null) return;
    const installed = new Set(entries.map((entry) => entry.id));
    const rows = catalogEntries.filter((entry) => !installed.has(entry.id));
    catalogHost.replaceChildren();
    catalogHost.hidden = rows.length === 0;
    if (rows.length === 0) return;

    const head = document.createElement("li");
    head.className = "plugin-group";
    head.textContent = ui.t("web.plugins.catalog");
    catalogHost.append(head);

    for (const entry of rows) {
      const li = document.createElement("li");
      li.className = "plugin-row catalog-row";

      const main = document.createElement("div");
      main.className = "plugin-main";
      const titleRow = document.createElement("div");
      titleRow.className = "plugin-title-row";
      const name = document.createElement("span");
      name.className = "plugin-name";
      name.textContent = entry.name;
      const meta = document.createElement("span");
      meta.className = "plugin-meta";
      meta.textContent = [`v${entry.version}`, entry.author].filter((part) => typeof part === "string" && part !== "").join("  ·  ");
      titleRow.append(name, meta);
      main.append(titleRow);
      if (typeof entry.summary === "string" && entry.summary !== "") {
        const desc = document.createElement("span");
        desc.className = "plugin-desc";
        desc.textContent = entry.summary;
        main.append(desc);
      }

      const install = document.createElement("button");
      install.type = "button";
      install.className = "btn";
      install.textContent = ui.t("web.plugins.install");
      install.disabled = entry.dist === undefined;
      install.addEventListener("click", () => void askRemoteInstall(entry));

      li.append(main, install);
      catalogHost.append(li);
    }
  };

  const askRemoteInstall = async (entry) => {
    if (entry.dist === undefined) return;
    const dialog = document.createElement("dialog");
    dialog.className = "settings sheet plugin-install";
    const head = document.createElement("div");
    head.className = "sheet-head";
    const title = document.createElement("h2");
    title.textContent = ui.t("web.plugins.installTitle");
    head.append(title);

    const body = document.createElement("div");
    body.className = "plugin-install-body";
    const meta = document.createElement("p");
    meta.className = "plugin-install-file";
    meta.textContent = `${entry.name} · v${entry.version}`;
    const warn = document.createElement("p");
    warn.className = "plugin-install-warn";
    warn.textContent = ui.t("web.plugins.installWarn");
    body.append(meta, warn);

    const actions = document.createElement("div");
    actions.className = "plugin-install-actions";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "btn";
    cancel.textContent = ui.t("web.cancel");
    cancel.addEventListener("click", () => dialog.close());
    const confirm = document.createElement("button");
    confirm.type = "button";
    confirm.className = "btn primary";
    confirm.textContent = ui.t("web.plugins.install");
    confirm.addEventListener("click", async () => {
      confirm.disabled = true;
      const res = await ui.call("tessera.admin/installFromUrl", {
        url: entry.dist.url,
        integrity: entry.dist.integrity,
      }).catch(() => null);
      if (res?.ok !== true) {
        ui.toast("web.status.error", "bad");
        confirm.disabled = false;
        return;
      }
      dialog.close();
      ui.toast("web.plugins.installed", "ok");
      await refresh();
    });
    actions.append(cancel, confirm);

    dialog.append(head, body, actions);
    dialog.addEventListener("close", () => dialog.remove());
    document.body.append(dialog);
    dialog.showModal();
  };

  const refresh = async () => {
    if (!root?.isConnected) return;
    const entries = await collect();
    await loadCatalog();
    renderCatalog(entries);
    const needle = (search?.value ?? "").trim().toLowerCase();
    const shown = needle === ""
      ? entries
      : entries.filter((entry) => {
          const title = entry.info?.title ? ui.t(entry.info.title) : "";
          return entry.id.toLowerCase().includes(needle) || title.toLowerCase().includes(needle);
        });
    countHost.textContent = ui.t("web.plugins.count", { count: entries.length });
    listHost.replaceChildren();
    /* 分成两段：在用的排前面，停用的收在后面。混在一起时找"刚关掉的那个"要扫全表 */
    for (const group of [
      { labelKey: "web.plugins.groupEnabled", items: shown.filter((entry) => entry.enabled) },
      { labelKey: "web.plugins.groupDisabled", items: shown.filter((entry) => !entry.enabled) },
    ]) {
      if (group.items.length === 0) continue;
      const head = document.createElement("li");
      head.className = "plugin-group";
      head.textContent = ui.t(group.labelKey);
      listHost.append(head);
      for (const entry of group.items) listHost.append(rowOf(entry, () => void refresh()));
    }
    if (shown.length === 0) {
      const empty = document.createElement("li");
      empty.className = "hint";
      empty.textContent = ui.t("web.plugins.empty");
      listHost.append(empty);
    }
  };

  /** 从文件安装：包走 base64（请求体上限 2 MB，这里先卡 1.5 MB） */
  const askInstall = async (file) => {
    const LIMIT = 1_500_000;
    if (file.size > LIMIT) {
      ui.toast("web.plugins.installTooLarge", "bad", { limit: "1.5 MB" });
      return;
    }

    const dialog = document.createElement("dialog");
    dialog.className = "settings sheet plugin-install";

    const head = document.createElement("div");
    head.className = "sheet-head";
    const title = document.createElement("h2");
    title.textContent = ui.t("web.plugins.installTitle");
    head.append(title);

    const body = document.createElement("div");
    body.className = "plugin-install-body";
    const meta = document.createElement("p");
    meta.className = "plugin-install-file";
    meta.textContent = `${file.name} · ${Math.max(1, Math.ceil(file.size / 1024))} KB`;
    const warn = document.createElement("p");
    warn.className = "plugin-install-warn";
    warn.textContent = ui.t("web.plugins.installWarn");
    body.append(meta, warn);

    const actions = document.createElement("div");
    actions.className = "plugin-install-actions";
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "btn";
    cancel.textContent = ui.t("web.cancel");
    cancel.addEventListener("click", () => dialog.close());
    const confirm = document.createElement("button");
    confirm.type = "button";
    confirm.className = "btn primary";
    confirm.textContent = ui.t("web.plugins.install");
    confirm.addEventListener("click", async () => {
      confirm.disabled = true;
      try {
        const bytes = new Uint8Array(await file.arrayBuffer());
        let binary = "";
        for (let i = 0; i < bytes.length; i += 0x8000) {
          binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
        }
        const res = await ui.call("tessera.admin/installPlugin", { dataBase64: btoa(binary) });
        if (res?.ok !== true) {
          ui.toast("web.status.error", "bad");
          confirm.disabled = false;
          return;
        }
        dialog.close();
        ui.toast("web.plugins.installed", "ok");
        await refresh();
      } catch {
        ui.toast("web.status.error", "bad");
        confirm.disabled = false;
      }
    });
    actions.append(cancel, confirm);

    dialog.append(head, body, actions);
    dialog.addEventListener("close", () => dialog.remove());
    document.body.append(dialog);
    dialog.showModal();
  };

  const build = () => {
    root = document.createElement("div");
    root.className = "plugin-panel";

    const bar = document.createElement("div");
    bar.className = "plugin-toolbar";
    search = document.createElement("input");
    search.type = "search";
    search.className = "plugin-search";
    search.placeholder = ui.t("web.plugins.search");
    search.addEventListener("input", () => void refresh());
    countHost = document.createElement("span");
    countHost.className = "plugin-count";
    bar.append(search, countHost);

    catalogHost = document.createElement("ul");
    catalogHost.className = "plugin-list plugin-catalog";
    catalogHost.hidden = true;

    listHost = document.createElement("ul");
    listHost.className = "plugin-list";

    note = document.createElement("p");
    note.className = "plugin-note";
    note.hidden = true;
    note.textContent = ui.t("web.plugins.restartHint");

    root.append(bar, catalogHost, listHost, note);

    /* 从文件安装：目录还没托管处，先给一条不依赖网络的路 */
    const installRow = document.createElement("div");
    installRow.className = "plugin-install-row";
    const installButton = document.createElement("button");
    installButton.type = "button";
    installButton.className = "plugin-install-btn";
    installButton.textContent = ui.t("web.plugins.fromFile");
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = ".tgz,.tar.gz,application/gzip";
    fileInput.hidden = true;
    installButton.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      const file = fileInput.files?.[0];
      fileInput.value = "";
      if (file !== undefined) void askInstall(file);
    });
    installRow.append(installButton, fileInput);
    root.append(installRow);

    pull = refresh;
    return root;
  };

  /* 插件市场在左侧活动栏，不在右栏：它管的是"有哪些插件、开没开"，
     和 AI 面板那种"边写边用"的东西不是一类，混在一排标签里两边都不顺手 */
  ui.registerSideView({
    id: "market",
    titleKey: "web.market.title",
    render: (container) => {
      container.append(build());
      void pull?.();
    },
  });
}
