/**
 * ai 插件（前端）：右侧对话面板。
 *
 * 壳只提供传输与编辑器能力：aiChat / insertText / getSelection / getDocText / pref。
 * 界面（消息流、上下文 chip、输入区）全部由插件自己建——壳里不再有它的 DOM。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  /* 生成参数归本插件：默认值也一起搬过来，`ui.pref` 的调用点都带了兜底 */
  ui.registerPrefs({
    id: "plugin.ai.generation",
    titleKey: "web.settings.group.generation",
    page: "ai",
    order: 5,
    items: [
      {
        key: "ai.style",
        labelKey: "pref.ai.style",
        type: "select",
        default: "natural",
        options: [
          { value: "restrained", labelKey: "pref.ai.style.restrained" },
          { value: "natural", labelKey: "pref.ai.style.natural" },
          { value: "conversational", labelKey: "pref.ai.style.conversational" },
          { value: "webnovel", labelKey: "pref.ai.style.webnovel" },
        ],
      },
      {
        key: "ai.temperature",
        labelKey: "pref.ai.temperature",
        type: "select",
        default: "0.7",
        options: [
          { value: "0.3", labelKey: "pref.ai.temp.stable" },
          { value: "0.7", labelKey: "pref.ai.temp.balanced" },
          { value: "1", labelKey: "pref.ai.temp.creative" },
        ],
      },
      { key: "ai.stream", labelKey: "pref.ai.stream", type: "toggle", default: true },
      {
        key: "ai.contextMode",
        labelKey: "pref.ai.contextMode",
        type: "select",
        default: "auto",
        options: [
          { value: "auto", labelKey: "web.ai.ctx.mode.auto" },
          { value: "doc", labelKey: "web.ai.ctx.mode.doc" },
          { value: "none", labelKey: "web.ai.ctx.mode.none" },
        ],
      },
      { key: "ai.contextChars", labelKey: "pref.ai.contextChars", type: "range", min: 0, max: 20000, step: 500, default: 4000, unitKey: "pref.unit.char" },
      /* 回复长度以前写死 2048：长章节续写会被截断，而用户没有任何地方能改 */
      { key: "ai.maxTokens", labelKey: "pref.ai.maxTokens", type: "range", min: 512, max: 8192, step: 256, default: 2048, unitKey: "pref.unit.char" },
    ],
  });

  /* 记忆：设置页里维护的几条事实，发请求时拼进系统提示词。
     只在面板挂载与"记忆变了"时读一次——每条消息都读盘没必要 */
  let memoryLines = [];
  const MEMORY_LABEL = "Facts the writer asked you to remember:";
  const loadMemory = async () => {
    const res = await ui.call("tessera.ai/memoryList", {}).catch(() => null);
    memoryLines = (res?.entries ?? []).map((entry) => `- ${entry.text}`);
  };
  document.addEventListener("tessera:memory-changed", () => void loadMemory());

  /* 设定层：只取条目的名字与一句话摘要，详情不进上下文（那是几万字的长文） */
  let codexLines = [];
  const loadCodex = async () => {
    const projectId = ui.getProjectId();
    /* 书架还没加载完时 projectId 是占位值 "main"：拿它去 list 会在库里
       写出一个空的 main/ 目录，书架于是凭空多出一本删不掉的书。等真项目再读 */
    if (typeof projectId !== "string" || projectId === "" || projectId === "main") {
      codexLines = [];
      return;
    }
    const res = await ui.call("tessera.codex/list", { projectId }).catch(() => null);
    const entities = res?.ok === true ? (res.entities ?? []) : [];
    codexLines = entities.map((entity) =>
      entity.summary === "" ? `- ${entity.name}` : `- ${entity.name}: ${entity.summary}`,
    );
  };

  const STYLE_HINT = {
    restrained: "Write in a restrained, precise tone. Avoid filler and cliches.",
    natural: "Write in clear, natural prose. Prefer concrete detail over adjectives.",
    conversational: "Write in a conversational, spoken tone. Short sentences.",
    webnovel: "Write in a fast-paced web-novel style: vivid action, hooks at paragraph ends.",
  };
  /* 改稿格式说明是**给模型的**，不是界面文案：和 STYLE_HINT 一样写英文常量。
     放进词表会被 ui-copy-not-sentence 拦住（那是对的：界面文案不放整句指导） */
  const EDIT_FORMAT = [
    "When the user asks you to change the text, answer with edit blocks that mark the exact original and the replacement.",
    "The original must appear exactly once in the document; no prose outside the blocks.",
    "One paragraph per block by default. To rewrite several paragraphs at once, quote the whole passage (paragraphs separated by a blank line) in SEARCH and write the new paragraphs, also separated by a blank line, in REPLACE.",
    "REPLACE may use Markdown (emphasis, headings, lists); it is applied as formatted text.",
    "<<<<<<< SEARCH",
    "original",
    "=======",
    "replacement",
    ">>>>>>> REPLACE",
  ].join(String.fromCharCode(10));
  const NL = String.fromCharCode(10);

  let host = null;
  let log = null;
  let input = null;
  let contextBar = null;
  /** 动态上下文 chips 的容器：常驻芯片不放在里面 */
  let contextChips = null;
  let send = null;
  let budget = null;
  let scrollBtn = null;
  /**
   * 会话记录：刷新后要还在，否则"历史提问"和刚聊出来的结果都会丢。
   * 存 localStorage 而不是书库：它是工作台级的临时记录，不该进文稿目录。
   * 只留最近 100 条、单条截 4000 字，避免把 localStorage 撑满。
   */
  const STORE_KEY = "tessera.ai.messages";
  let messages = [];
  let persistTimer = null;
  let streaming = false;
  const CONTEXT_MODES = ["auto", "doc", "none"];
  const readContextMode = () => {
    const value = String(ui.pref("ai.contextMode", "auto"));
    return CONTEXT_MODES.includes(value) ? value : "auto";
  };
  let contextMode = readContextMode();

  /** 模式写回偏好：下次打开面板还是这个选择，不用每次重拨 */
  const setContextMode = (next) => {
    contextMode = next;
    try {
      window.TesseraPrefs?.set("ai.contextMode", next);
    } catch {
      /* 隐私模式写不进去：本次会话内仍然有效 */
    }
    renderContext();
  };
  // 设置页改了这几项会广播：面板开着时也要跟着变，不用刷新
  document.addEventListener("tessera:prefs-applied", () => {
    const next = readContextMode();
    if (next !== contextMode) {
      contextMode = next;
      renderContext();
    }
  });

  /* ---------- 会话日志 ----------
     存在数据目录（不是书库）：书库会被同步盘带走，聊天里常有未发表片段。
     localStorage 仍是快速缓存；文件是"清了缓存也还在"的那一份 */
  let sessionId = "";
  let restoredOnce = false;
  const sessionKey = () => `tessera.ai.session.${ui.getProjectId() || "default"}`;
  const rotateSession = () => {
    sessionId = `s${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    try {
      localStorage.setItem(sessionKey(), sessionId);
    } catch {
      /* 隐私模式：只在本次会话里有效 */
    }
    return sessionId;
  };
  const ensureSession = () => {
    if (sessionId !== "") return sessionId;
    try {
      const saved = localStorage.getItem(sessionKey());
      if (typeof saved === "string" && saved !== "") {
        sessionId = saved;
        return sessionId;
      }
    } catch {
      /* 读不到就当没有 */
    }
    return rotateSession();
  };
  const logSession = (events) => {
    const projectId = ui.getProjectId();
    if (typeof projectId !== "string" || projectId === "" || projectId === "main" || events.length === 0) return;
    void ui.call("tessera.ai/sessionAppend", { projectId, sessionId: ensureSession(), events }).catch(() => {});
  };

  /** 从文件恢复：localStorage 已经有内容就以它为准（那是最近一次缓存） */
  const restoreSession = async () => {
    if (restoredOnce || messages.length > 0) {
      restoredOnce = true;
      return;
    }
    const projectId = ui.getProjectId();
    if (typeof projectId !== "string" || projectId === "" || projectId === "main") return;
    restoredOnce = true;

    let id = ensureSession();
    let events = [];
    const first = await ui.call("tessera.ai/sessionRead", { projectId, sessionId: id }).catch(() => null);
    events = first?.ok === true ? (first.events ?? []) : [];
    if (events.length === 0) {
      // 缓存和 sessionId 一起丢了：找这本书最近的一次会话
      const listed = await ui.call("tessera.ai/sessionList", { projectId }).catch(() => null);
      const newest = (listed?.sessions ?? [])[0];
      if (newest === undefined) return;
      id = String(newest.id);
      sessionId = id;
      try {
        localStorage.setItem(sessionKey(), id);
      } catch {
        /* 写不回去也不影响本次恢复 */
      }
      const again = await ui.call("tessera.ai/sessionRead", { projectId, sessionId: id }).catch(() => null);
      events = again?.ok === true ? (again.events ?? []) : [];
    }

    const rebuilt = [];
    for (const event of events) {
      if (event === null || typeof event !== "object") continue;
      if (event.type === "user" && typeof event.text === "string") {
        rebuilt.push({ role: "user", text: event.text });
      } else if (event.type === "assistant" && typeof event.text === "string") {
        rebuilt.push({
          role: "assistant",
          text: event.text,
          ...(Array.isArray(event.findings) ? { findings: event.findings } : {}),
          ...(event.stats === undefined ? {} : { stats: event.stats }),
        });
      }
    }
    if (rebuilt.length === 0) return;
    messages = rebuilt.slice(-100);
    renderLog();
  };

  /* 历史遗留的报错文本：文案可能变，所以列出已知几种，宁可漏掉也不误删正文 */
  const isErrorText = (text) => {
    const known = [ui.t("web.ai.err.provider"), ui.t("web.ai.err.net")];
    return known.some((prefix) => prefix !== "" && String(text).startsWith(prefix));
  };

  /** 读回上次的会话；坏数据当空，不让它挡住面板启动 */
  const loadHistory = () => {
    try {
      const raw = JSON.parse(localStorage.getItem(STORE_KEY) ?? "[]");
      if (!Array.isArray(raw)) return;
      messages = raw
        .filter((item) => item !== null && typeof item === "object")
        .filter((item) => (item.role === "user" || item.role === "assistant") && typeof item.text === "string")
        // 早先版本把报错也存了盘：按已知文案清掉，否则面板一打开就是两行红字
        .filter((item) => item.error !== true && !isErrorText(item.text))
        .slice(-100);
    } catch {
      messages = [];
    }
  };

  /** 写回：防抖 200ms；渲染中的那条（streaming）不落盘，等它结束再写 */
  const persist = () => {
    if (persistTimer !== null) return;
    persistTimer = setTimeout(() => {
      persistTimer = null;
      const saveable = messages
        .filter((item) => item.streaming !== true && item.error !== true)
        .slice(-100)
        .map((item) => ({
          role: item.role,
          text: item.text.slice(0, 4000),
          // 审读意见/统计、已应用的改稿下标都要活过刷新，否则重开就只剩一段摘要
          ...(Array.isArray(item.findings) && item.findings.length > 0 ? { findings: item.findings.slice(0, 20) } : {}),
          ...(item.stats === undefined ? {} : { stats: item.stats }),
          ...(Array.isArray(item.applied) && item.applied.length > 0 ? { applied: item.applied } : {}),
        }));
      try {
        localStorage.setItem(STORE_KEY, JSON.stringify(saveable));
      } catch {
        /* 隐私模式或配额满：丢记录不影响对话 */
      }
    }, 200);
  };

  /* ---------- 上下文 ---------- */
  const pickContext = () => {
    if (contextMode === "none") return null;
    const selection = ui.getSelection();
    if (contextMode === "auto" && selection.trim() !== "") {
      return { labelKey: "web.ai.ctx.selection", count: [...selection].length, text: selection };
    }
    const doc = ui.getDocText();
    if (doc.trim() === "") return null;
    return { labelKey: "web.ai.ctx.doc", count: [...doc].length, text: doc };
  };

  const renderContext = () => {
    if (contextChips === null) return;
    // 只重绘动态部分：模型/选区两颗是常驻的，清空整条会把它们一起删掉
    contextChips.replaceChildren();
    const picked = pickContext();
    if (picked !== null) {
      const chip = document.createElement("span");
      chip.className = "ai-chip";
      const label = document.createElement("span");
      label.className = "ai-chip-text";
      label.textContent = ui.t(picked.labelKey, { count: picked.count });
      label.title = picked.text.slice(0, 400);
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "ai-chip-x";
      remove.innerHTML = window.TesseraIcons?.svg("close") ?? "";
      remove.addEventListener("click", () => {
        setContextMode("none");
      });
      chip.append(label, remove);
      contextChips.append(chip);
    }
    /* 开关必须常驻：none 模式下 chip 没了，但按钮还得在。
       用文字而不是图标：状态藏在颜色里，用户读不出来 */
    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "ai-chip ai-chip-btn";
    toggle.dataset.mode = contextMode;
    toggle.title = ui.t("web.ai.ctx.toggleHint");
    toggle.setAttribute("aria-label", ui.t("web.ai.ctx.toggle"));
    toggle.textContent = ui.t(`web.ai.ctx.mode.${contextMode}`);
    toggle.addEventListener("click", () => {
      const next = contextMode === "auto" ? "doc" : contextMode === "doc" ? "none" : "auto";
      setContextMode(next);
    });
    contextChips.append(toggle);
  };

  /* ---------- 消息 ---------- */
  /* 空态只留四个动作：面板标题已经写着"AI 助手"，
     再放 logo、口号、免责声明就是落地页，不是工具面板 */
  const emptyState = () => {
    const box = document.createElement("div");
    box.className = "ai-empty";

    const quick = document.createElement("div");
    quick.className = "ai-quick";
    for (const key of ["polish", "continue", "summary", "outline"]) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "ai-quick-item";
      button.textContent = ui.t("web.ai.quick." + key);
      button.addEventListener("click", () => {
        input.value = ui.t("web.ai.quick." + key);
        input.focus();
        autoGrow();
      });
      quick.append(button);
    }

    box.append(quick);
    return box;
  };

  /* 改稿提案：解析在 packages/editor（与文档定位同一套规则），界面只决定按钮 */
  const EDIT_REASON = {
    "not-found": "web.ai.edit.notFound",
    ambiguous: "web.ai.edit.ambiguous",
    multiline: "web.ai.edit.multiline",
    overlap: "web.ai.edit.overlap",
    empty: "web.ai.edit.empty",
    "prose.required": "web.ai.edit.proseOnly",
    "save.failed": "web.ai.edit.saveFailed",
    "snapshot.failed": "web.ai.edit.snapshotFailed",
  };
  const proposalsOf = (text) => window.TesseraVendor?.prose?.parseProposals?.(text) ?? [];
  const editFailed = (res) => ui.toast(EDIT_REASON[res?.reason] ?? "web.ai.edit.failed", "bad");
  /** 正在预览哪条消息：日志重绘后按钮状态要跟着回来，不能只改 DOM */
  let activePreview = null;
  /** 每条消息里"哪几条改动被勾选"：接受一条后重绘，不能把取消的又勾回来 */
  const editPicks = new WeakMap();

  /* 记录：审读意见 + 会话日志，两页共用一个弹窗 */
  let recordsDialog = null;
  let recordsTabs = null;
  let reviewsList = null;
  let sessionsList = null;
  let recordsDetail = null;
  let recordsMode = "reviews";
  let recordsSearch = null;

  /** 记录多了要靠搜：按行文本过滤，两个页签共用同一个关键字 */
  const filterRecords = () => {
    const needle = (recordsSearch?.value ?? "").trim().toLowerCase();
    for (const list of [reviewsList, sessionsList]) {
      if (list === null) continue;
      for (const row of list.children) {
        row.hidden = needle !== "" && !(row.textContent ?? "").toLowerCase().includes(needle);
      }
    }
  };

  const showRecordsMode = (mode) => {
    recordsMode = mode;
    for (const tab of recordsTabs.querySelectorAll("[data-mode]")) {
      tab.setAttribute("aria-selected", tab.dataset.mode === mode ? "true" : "false");
    }
    reviewsList.hidden = mode !== "reviews";
    sessionsList.hidden = mode !== "sessions";
    recordsDetail.hidden = true;
    const back = recordsDialog.querySelector(".dialog-actions button");
    if (back !== null) back.hidden = true;
  };

  const showDetail = (text) => {
    recordsDetail.textContent = text;
    recordsDetail.hidden = false;
    reviewsList.hidden = true;
    sessionsList.hidden = true;
    const back = recordsDialog.querySelector(".dialog-actions button");
    if (back !== null) back.hidden = false;
  };

  const emptyRow = (list, key) => {
    const empty = document.createElement("li");
    empty.className = "sheet-empty-title";
    empty.textContent = ui.t(key);
    list.append(empty);
  };

  const loadReviews = async () => {
    const res = await ui.call("tessera.pipeline/listReviews", { projectId: ui.getProjectId() }).catch(() => null);
    const records = res?.ok === true ? (res.records ?? []) : [];
    reviewsList.replaceChildren();
    if (records.length === 0) {
      emptyRow(reviewsList, "web.ai.reviews.empty");
      return;
    }
    for (const record of records) {
      const row = document.createElement("li");
      const button = document.createElement("button");
      button.type = "button";
      button.className = "ai-review-row";
      const name = document.createElement("span");
      name.textContent = String(record.docId ?? "").split("/").pop() ?? record.docId;
      const meta = document.createElement("small");
      meta.textContent = `${new Date(record.at).toLocaleString()} · ${record.model}`;
      button.append(name, meta);
      button.addEventListener("click", async () => {
        const detail = await ui.call("tessera.pipeline/readReview", { projectId: ui.getProjectId(), id: record.id }).catch(() => null);
        if (detail?.ok !== true) {
          ui.toast("web.status.error", "bad");
          return;
        }
        showDetail(detail.detail.review);
      });
      row.append(button);
      reviewsList.append(row);
    }
    filterRecords();
  };

  const loadSessions = async () => {
    const res = await ui.call("tessera.ai/sessionList", { projectId: ui.getProjectId() }).catch(() => null);
    const sessions = res?.ok === true ? (res.sessions ?? []) : [];
    sessionsList.replaceChildren();
    if (sessions.length === 0) {
      emptyRow(sessionsList, "web.ai.reviews.empty");
      return;
    }
    for (const session of sessions) {
      const row = document.createElement("li");
      const button = document.createElement("button");
      button.type = "button";
      button.className = "ai-review-row";
      const name = document.createElement("span");
      const preview = typeof session.preview === "string" ? session.preview.trim() : "";
      name.textContent = preview === "" ? new Date(Number(session.at) || 0).toLocaleString() : preview;
      const meta = document.createElement("small");
      meta.textContent = `${new Date(Number(session.at) || 0).toLocaleString()} · ${Math.max(1, Math.round(Number(session.bytes) / 1024))} KB`;
      button.append(name, meta);
      button.addEventListener("click", async () => {
        const read = await ui.call("tessera.ai/sessionRead", { projectId: ui.getProjectId(), sessionId: session.id }).catch(() => null);
        const events = read?.ok === true ? (read.events ?? []) : [];
        if (events.length === 0) {
          ui.toast("web.status.error", "bad");
          return;
        }
        const lines = events.map((event) => {
          const at = new Date(Number(event?.ts) || 0).toLocaleTimeString();
          if (event?.type === "adopt") return `[${at}] ${ui.t("web.ai.session.adopt", { count: Number(event.count) || 0 })}`;
          const key = `web.ai.session.${String(event?.type ?? "")}`;
          const who = ui.t(key);
          const label = who === key ? String(event?.type ?? "") : who;
          return `[${at}] ${label}: ${String(event?.text ?? "")}`;
        });
        showDetail(lines.join(String.fromCharCode(10, 10)));
      });
      row.append(button);
      sessionsList.append(row);
    }
    filterRecords();
  };

  const openRecords = async (mode = "reviews") => {
    if (recordsDialog === null) {
      recordsDialog = document.createElement("dialog");
      recordsDialog.className = "settings sheet";
      recordsDialog.id = "plugin-ai-records";

      const head = document.createElement("div");
      head.className = "sheet-head";
      const title = document.createElement("h2");
      title.textContent = ui.t("web.ai.records");
      const close = document.createElement("button");
      close.type = "button";
      close.className = "icon-btn sheet-x";
      close.innerHTML = window.TesseraIcons?.svg("close") ?? "";
      close.addEventListener("click", () => recordsDialog.close());
      head.append(title, close);

      recordsTabs = document.createElement("div");
      recordsTabs.className = "ai-record-tabs";
      for (const [id, key] of [["reviews", "web.ai.records.reviews"], ["sessions", "web.ai.records.sessions"]]) {
        const tab = document.createElement("button");
        tab.type = "button";
        tab.className = "ai-record-tab";
        tab.dataset.mode = id;
        tab.textContent = ui.t(key);
        tab.addEventListener("click", () => {
          showRecordsMode(id);
          void (id === "reviews" ? loadReviews() : loadSessions());
        });
        recordsTabs.append(tab);
      }

      recordsSearch = document.createElement("input");
      recordsSearch.type = "search";
      recordsSearch.className = "ai-record-search";
      recordsSearch.placeholder = ui.t("web.ai.records.search");
      recordsSearch.addEventListener("input", () => filterRecords());

      reviewsList = document.createElement("ul");
      reviewsList.className = "ai-review-list";
      reviewsList.id = "ai-review-list";
      sessionsList = document.createElement("ul");
      sessionsList.className = "ai-review-list";
      sessionsList.id = "ai-session-list";
      sessionsList.hidden = true;

      recordsDetail = document.createElement("pre");
      recordsDetail.className = "ai-review-text";
      recordsDetail.hidden = true;

      const actions = document.createElement("div");
      actions.className = "dialog-actions";
      const back = document.createElement("button");
      back.type = "button";
      back.textContent = ui.t("web.ai.reviews.back");
      back.hidden = true;
      back.addEventListener("click", () => showRecordsMode(recordsMode));
      actions.append(back);

      recordsDialog.append(head, recordsTabs, recordsSearch, reviewsList, sessionsList, recordsDetail, actions);
      document.body.append(recordsDialog);
    }

    showRecordsMode(mode);
    ui.openModal(recordsDialog);
    await (mode === "reviews" ? loadReviews() : loadSessions());
  };

  /* 审读意见：severity / kind 是模型给的枚举，词表里没有就原样显示，
     不要为了一个未知取值把整条意见藏起来 */
  const findingLabel = (group, value) => {
    const key = `web.ai.find.${group}.${String(value ?? "")}`;
    const text = ui.t(key);
    return text === key ? String(value ?? "") : text;
  };

  const renderFindings = (findings) => {
    const list = document.createElement("div");
    list.className = "ai-findings";
    for (const finding of findings) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "ai-finding";
      row.dataset.severity = String(finding.severity ?? "medium");
      row.title = String(finding.quote ?? "");

      const head = document.createElement("span");
      head.className = "ai-finding-head";
      const severity = document.createElement("span");
      severity.className = "ai-finding-sev";
      severity.textContent = findingLabel("sev", finding.severity);
      const kind = document.createElement("span");
      kind.className = "ai-finding-kind";
      kind.textContent = findingLabel("kind", finding.kind);
      head.append(severity, kind);

      const text = document.createElement("span");
      text.className = "ai-finding-text";
      text.textContent = String(finding.suggestion ?? "");

      /* 只显示建议、把原句藏进 title 的话，用户不知道这条在说哪一句 */
      const quote = document.createElement("span");
      quote.className = "ai-finding-quote";
      quote.textContent = String(finding.quote ?? "");

      row.append(head, quote, text);

      row.addEventListener("click", () => {
        if (!ui.revealQuote(String(finding.quote ?? ""))) ui.toast("web.ai.find.miss", "dirty");
      });
      list.append(row);
    }
    return list;
  };

  const renderMessage = (message) => {
    const row = document.createElement("div");
    row.className = "ai-msg ai-msg-" + message.role;
    const body = document.createElement("div");
    body.className = "ai-msg-body";
    if (message.role === "assistant" && window.TesseraMarkdown !== undefined) {
      const blocks = proposalsOf(message.text);
      const rest = blocks.length === 0 ? message.text : (window.TesseraVendor?.prose?.stripProposals?.(message.text) ?? "");
      body.innerHTML = window.TesseraMarkdown.render(rest);
      // 改动块本身不摊在对话里：给一行"待审"，具体内容在正文里预览
      if (blocks.length > 0) {
        const left = blocks.length - (Array.isArray(message.applied) ? message.applied.length : 0);
        if (left > 0) {
          const pending = document.createElement("div");
          pending.className = "ai-edit-pending";
          pending.textContent = ui.t("web.ai.edit.pending", { count: left });
          body.append(pending);
        }
      }
    } else {
      body.textContent = message.text;
    }
    if (message.streaming) {
      const caret = document.createElement("span");
      caret.className = "ai-caret";
      body.append(caret);
    }
    row.append(body);

    if (message.role === "assistant" && Array.isArray(message.findings) && message.findings.length > 0) {
      row.append(renderFindings(message.findings));
      if (message.stats !== undefined && message.stats !== null && Number(message.stats.total) > 0) {
        const detail = Object.entries(message.stats.byKind ?? {})
          .filter(([, count]) => Number(count) > 0)
          .sort((a, b) => Number(b[1]) - Number(a[1]))
          .map(([kind, count]) => `${findingLabel("kind", kind)} ${String(count)}`)
          .join(" · ");
        const line = document.createElement("div");
        line.className = "ai-finding-stats";
        line.textContent = ui.t("web.ai.find.stats", { total: message.stats.total, detail });
        row.append(line);
      }
    }

    if (message.role === "assistant" && !message.streaming && message.text !== "") {
      const tools = document.createElement("div");
      tools.className = "ai-msg-tools";
      const copy = document.createElement("button");
      copy.type = "button";
      copy.className = "ai-mini";
      copy.textContent = ui.t("web.ai.copy");
      copy.addEventListener("click", () => {
        void navigator.clipboard?.writeText(message.text);
        ui.toast("web.status.copied", "ok");
      });
      const again = document.createElement("button");
      again.type = "button";
      again.className = "ai-mini";
      again.textContent = ui.t("web.ai.regenerate");
      again.addEventListener("click", () => {
        // 退回到这条回复之前的用户提问，重新发一次
        const at = messages.indexOf(message);
        const lastUser = [...messages.slice(0, at)].reverse().find((m) => m.role === "user");
        if (lastUser === undefined) return;
        messages.splice(at - 1);
        renderLog();
        void sendMessage(lastUser.text);
      });

      const blocks = proposalsOf(message.text);
      if (blocks.length > 0) {
        const applied = new Set(Array.isArray(message.applied) ? message.applied : []);
        const remaining = blocks.map((block, index) => ({ block, index })).filter((item) => !applied.has(item.index));

        /* 全部应用过：只留状态。继续给"预览"只会得到"找不到原文" */
        if (remaining.length === 0) {
          const state = document.createElement("span");
          state.className = "ai-mini-state";
          state.textContent = ui.t("web.ai.edit.applied");
          tools.append(copy, state, again);
          row.append(tools);
          return row;
        }

        /* 逐条接受：默认全选，取消勾选的条目既不高亮也不会被应用 */
        const preview = document.createElement("button");
        preview.type = "button";
        preview.className = "ai-mini";
        preview.dataset.edit = "preview";
        preview.textContent = ui.t("web.ai.edit.preview");
        const accept = document.createElement("button");
        accept.type = "button";
        accept.className = "ai-mini";
        accept.dataset.edit = "accept";
        accept.textContent = ui.t("web.ai.edit.accept");
        const reject = document.createElement("button");
        reject.type = "button";
        reject.className = "ai-mini";
        reject.dataset.edit = "reject";
        reject.textContent = ui.t("web.ai.edit.reject");

        /* 勾选按消息记：接受一条后日志会重绘，不能把用户取消的又勾回来 */
        let picks = editPicks.get(message);
        if (picks === undefined) {
          picks = new Set(remaining.map((item) => item.index));
          editPicks.set(message, picks);
        }
        const chosen = () => remaining.filter((item) => picks.has(item.index)).map((item) => item.block);

        const list = document.createElement("div");
        list.className = "ai-edit-list";
        list.hidden = activePreview !== message;
        for (const item of remaining) {
          const line = document.createElement("label");
          line.className = "ai-edit-row";
          const box = document.createElement("input");
          box.type = "checkbox";
          box.checked = picks.has(item.index);
          const text = document.createElement("span");
          text.className = "ai-edit-text";
          text.textContent = `${item.block.search} → ${item.block.replace}`;
          text.title = `${item.block.search}${NL}→ ${item.block.replace}`;
          line.append(box, text);
          box.addEventListener("change", () => {
            if (box.checked) picks.add(item.index);
            else picks.delete(item.index);
            const count = chosen().length;
            preview.disabled = count === 0;
            accept.disabled = count === 0;
            if (count === 0) {
              ui.clearEdits();
              return;
            }
            const res = ui.previewEdits(chosen());
            if (!res.ok) editFailed(res);
          });
          list.append(line);
        }

        const active = activePreview === message;
        preview.hidden = active;
        accept.hidden = !active;
        reject.hidden = !active;
        preview.disabled = chosen().length === 0;
        accept.disabled = chosen().length === 0;

        preview.addEventListener("click", () => {
          const res = ui.previewEdits(chosen());
          if (!res.ok) return editFailed(res);
          activePreview = message;
          preview.hidden = true;
          accept.hidden = false;
          reject.hidden = false;
          list.hidden = false;
        });
        accept.addEventListener("click", async () => {
          const picked = chosen();
          if (picked.length === 0) return;
          // 接受前会先落盘再打快照，这两步都是异步的：按钮先锁住，避免连点应用两次
          accept.disabled = true;
          const res = await ui.applyEdits(picked, { reason: ui.t("web.ai.edit.snapshot") });
          accept.disabled = false;
          if (!res.ok) return editFailed(res);
          const done = new Set([...applied, ...remaining.filter((item) => picks.has(item.index)).map((item) => item.index)]);
          message.applied = [...done].sort((a, b) => a - b);
          activePreview = null;
          persist();
          logSession([{ type: "adopt", ...(typeof ui.getCurrentDoc() === "string" ? { docId: ui.getCurrentDoc() } : {}), count: picked.length }]);
          ui.toast("web.ai.applied", "ok");
          renderLog();
        });
        reject.addEventListener("click", () => {
          ui.clearEdits();
          activePreview = null;
          preview.hidden = false;
          accept.hidden = true;
          reject.hidden = true;
          list.hidden = true;
        });

        tools.append(copy, preview, accept, reject, again);
        row.append(tools, list);
        return row;
      }

      const insert = document.createElement("button");
      insert.type = "button";
      insert.className = "ai-mini";
      insert.textContent = ui.t("web.ai.apply");
      insert.addEventListener("click", () => {
        ui.insertText(message.text);
        ui.toast("web.ai.applied", "ok");
      });

      tools.append(copy, insert, again);
      row.append(tools);
      return row;
    }
    return row;
  };

  const renderLog = () => {
    if (log === null) return;
    const stick = log.scrollHeight - log.scrollTop - log.clientHeight < 48;
    // 消息变化只有这一个出口（发送/删除/清空都走这里），在渲染处落盘反而不会漏
    persist();
    log.replaceChildren();
    if (messages.length === 0) {
      log.append(emptyState());
    } else {
      messages.forEach((message, index) => {
        const row = renderMessage(message);
        row.dataset.index = String(index);
        log.append(row);
      });
    }
    if (stick) log.scrollTop = log.scrollHeight;
    const askCount = messages.filter((message) => message.role === "user").length;
    const historyBtn = document.getElementById("ai-history");
    if (historyBtn !== null) historyBtn.disabled = askCount === 0;
    if (scrollBtn !== null) scrollBtn.hidden = log.scrollHeight <= log.clientHeight + 4;
  };

  /* ---------- 斜杠命令 ---------- */
  const closeSlash = () => {
    slashMenu?.remove();
    slashMenu = null;
    slashShown = [];
    slashIndex = 0;
  };

  const paintSlash = () => {
    if (slashMenu === null) return;
    const list = slashMenu.querySelector(".ai-slash-list");
    list.replaceChildren();
    slashShown.forEach((command, index) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "ai-slash-item";
      row.dataset.active = String(index === slashIndex);
      const label = document.createElement("span");
      label.textContent = command.label;
      const key = document.createElement("span");
      key.className = "ai-slash-key";
      key.textContent = `/${command.id}`;
      row.append(label, key);
      row.addEventListener("click", () => runSlash(command));
      list.append(row);
    });
  };

  const runSlash = (command) => {
    if (command === undefined) return;
    closeSlash();
    if (input === null) return;
    input.value = "";
    autoGrow();
    command.run();
  };

  const refreshSlash = () => {
    if (input === null) return;
    const text = input.value;
    if (!text.startsWith("/") || text.includes(String.fromCharCode(10))) {
      closeSlash();
      return;
    }
    const query = text.slice(1).toLowerCase();
    slashShown = slashCommands.filter(
      (command) => command.id.startsWith(query) || command.label.toLowerCase().includes(query),
    );
    if (slashShown.length === 0) {
      closeSlash();
      return;
    }
    slashIndex = Math.min(slashIndex, slashShown.length - 1);
    if (slashMenu === null) {
      slashMenu = document.createElement("div");
      slashMenu.className = "ai-slash";
      const list = document.createElement("div");
      list.className = "ai-slash-list";
      slashMenu.append(list);
      document.body.append(slashMenu);
      const away = (event) => {
        if (event.target instanceof Node && slashMenu !== null && !slashMenu.contains(event.target) && event.target !== input) {
          closeSlash();
          document.removeEventListener("click", away);
        }
      };
      document.addEventListener("click", away);
    }
    paintSlash();
    // 贴着输入框上沿：位置每敲一个字都重算，面板高度会变
    const rect = input.getBoundingClientRect();
    slashMenu.style.left = `${Math.round(rect.left)}px`;
    slashMenu.style.top = `${Math.round(rect.top - slashMenu.offsetHeight - 6)}px`;
  };

  /* ---------- 发送 ---------- */
  const autoGrow = () => {
    if (input === null) return;
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 120) + "px";
  };

  /* 三种模式只改 system prompt，不动请求结构：切模式不该让上下文失效 */
  const AI_MODES = [
    { id: "craft", labelKey: "web.ai.mode.craft", hintKey: "web.ai.mode.craft.hint", promptKey: "web.ai.mode.craft.prompt" },
    { id: "ask", labelKey: "web.ai.mode.ask", hintKey: "web.ai.mode.ask.hint", promptKey: "web.ai.mode.ask.prompt" },
    { id: "plan", labelKey: "web.ai.mode.plan", hintKey: "web.ai.mode.plan.hint", promptKey: "web.ai.mode.plan.prompt" },
  ];

  const readMode = () => {
    try {
      const saved = localStorage.getItem("tessera.aiMode");
      return AI_MODES.find((mode) => mode.id === saved) ?? AI_MODES[0];
    } catch {
      return AI_MODES[0];
    }
  };

  /* 手动引用的文档：@ 挑中的其他章节，内容随请求一起带过去 */
  const referenced = new Map();

  const renderRefChips = () => {
    if (contextChips === null) return;
    for (const chip of [...contextChips.querySelectorAll("[data-ref]")]) chip.remove();
    for (const [docId, entry] of referenced) {
      const chip = document.createElement("span");
      chip.className = "ai-chip ai-ref-chip";
      chip.dataset.ref = docId;
      const label = document.createElement("span");
      label.className = "ai-chip-text";
      label.textContent = `@${entry.title}`;
      const close = document.createElement("button");
      close.type = "button";
      close.className = "ai-ref-close";
      close.textContent = "×";
      close.title = ui.t("web.ai.reference.remove");
      close.addEventListener("click", () => {
        referenced.delete(docId);
        renderRefChips();
      });
      chip.append(label, close);
      contextChips.append(chip);
    }
  };

  /* 大纲层：从正文里摘标题，让模型知道这本书长什么样，又不必吞整本 */
  const outlineLines = (text) => {
    const out = [];
    for (const match of text.matchAll(/^#{1,6}[ \t]+(.+)$/gm)) {
      const title = (match[1] ?? "").trim();
      if (title !== "") out.push(`- ${title}`);
      if (out.length >= 40) break;
    }
    return out;
  };

  const charLen = (text) => [...text].length;

  /** 按行取到配额上限：宁可少一条设定，也不把一句话截成半句 */
  const takeLines = (lines, cap) => {
    const out = [];
    let used = 0;
    for (const line of lines) {
      const size = charLen(line) + 1;
      if (cap !== Infinity && used + size > cap) break;
      out.push(line);
      used += size;
    }
    return { text: out.join(NL), count: out.length };
  };

  /** 正文按句读截断；边界丢掉 40% 以上就硬切（保住上下文优先） */
  const clipBody = (text, cap) => {
    const total = charLen(text);
    if (cap === Infinity || total <= cap) return { text, kept: total, clipped: false };
    const head = [...text].slice(0, cap).join("");
    const boundary = Math.max(head.lastIndexOf(NL + NL), head.lastIndexOf("。"), head.lastIndexOf(". "));
    const text2 = boundary > cap * 0.6 ? head.slice(0, boundary + 1) : head;
    return { text: text2, kept: charLen(text2), clipped: true };
  };

  /** 每次发送后写一行"这次送了哪些"：只报数，不解释（界面铁律） */
  const paintBudget = (data) => {
    if (budget === null) return;
    budget.textContent = data.limit > 0
      ? ui.t("web.ai.budget", {
          body: data.body,
          settings: data.settings,
          outline: data.outline,
          kept: data.kept,
          limit: data.limit,
        })
      : ui.t("web.ai.budgetNoLimit", { body: data.body, settings: data.settings, outline: data.outline, kept: data.kept });
    budget.hidden = false;
  };

  const buildRequest = (question) => {
    const style = String(ui.pref("ai.style", "natural"));
    const custom = String(ui.pref("plugin.ai.systemPrompt", "")).trim();
    const memory = memoryLines.length === 0 ? "" : `${MEMORY_LABEL}${NL}${memoryLines.join(NL)}`;
    const mode = readMode();
    // 写作模式顺手把"怎么交改动"说清楚：回复里的 SEARCH/REPLACE 块会被渲染成可接受的预览
    const editRule = mode.id === "craft" ? EDIT_FORMAT : "";
    const system = [custom, memory, ui.t(mode.promptKey), editRule, STYLE_HINT[style] === undefined ? "" : STYLE_HINT[style]]
      .filter((part) => part !== "")
      .join(NL + NL);

    const picked = pickContext();
    const referencedText = [...referenced.values()]
      .map((entry) => `${entry.title}${NL}${entry.text}`)
      .join(`${NL}${NL}---${NL}${NL}`);
    const limit = Number(ui.pref("ai.contextChars", 4000));

    /* 四层预算：设定 25%、大纲 10%，剩下的都给正文。
       配额花不完的部分顺延给正文——短设定不该浪费正文的空间 */
    const capSettings = limit > 0 ? Math.floor(limit * 0.25) : Infinity;
    const capOutline = limit > 0 ? Math.floor(limit * 0.1) : Infinity;
    const settings = picked === null ? { text: "", count: 0 } : takeLines(codexLines, capSettings);
    const outline = picked === null ? { text: "", count: 0 } : takeLines(outlineLines(picked.text), capOutline);
    /* 段头与分隔线也占额度：不把它们算进去，界面上的"共 N/M 字"会比 M 多出十几字 */
    const sectionHead = (text) => (text === "" ? 0 : 8);
    const beforeCount = (settings.text === "" ? 0 : 1) + (outline.text === "" ? 0 : 1);
    const beforeChars =
      charLen(settings.text) + charLen(outline.text) + sectionHead(settings.text) + sectionHead(outline.text) + beforeCount * 7;
    const bodyText = picked === null ? "" : [picked.text, referencedText].filter((part) => part !== "").join(NL + NL + "---" + NL + NL);
    const bodyOverhead = bodyText === "" ? 0 : 9 + (beforeCount > 0 ? 7 : 0);
    const bodyCap = limit > 0 ? Math.max(0, limit - beforeChars - bodyOverhead) : Infinity;
    const body = clipBody(bodyText, bodyCap);

    const sections = [
      settings.text === "" ? "" : `SETTING${NL}${settings.text}`,
      outline.text === "" ? "" : `OUTLINE${NL}${outline.text}`,
      body.text === "" ? "" : `DOCUMENT${NL}${body.text}`,
    ].filter((part) => part !== "");
    const contextText = sections.join(`${NL}${NL}---${NL}${NL}`);
    const kept = charLen(contextText);
    const total = beforeChars + charLen(bodyText);

    /* 上下文在前、问题在后：同一篇文档连续提问时，前缀（system + 设定 + 正文）字节不变，
       供应商的 prompt cache 才命中；把问题放前面等于每次都换前缀 */
    const content = contextText === "" ? question : contextText + NL + NL + "---" + NL + question;
    return {
      messages: [...(system === "" ? [] : [{ role: "system", content: system }]), { role: "user", content }],
      temperature: Number(ui.pref("ai.temperature", 0.7)),
      maxTokens: Number(ui.pref("ai.maxTokens", 2048)),
      truncated: body.clipped || settings.text.length < codexLines.join(NL).length || outline.count >= 40,
      kept,
      total,
      budget: {
        body: body.kept,
        settings: settings.count,
        outline: outline.count,
        kept,
        total,
        limit,
      },
    };
  };

  /* 发送按钮的两个形态：空按钮只是个蓝方块，必须自己带图标 */
  const paintSend = (mode) => {
    if (send === null) return;
    send.dataset.mode = mode;
    send.innerHTML = window.TesseraIcons?.svg(mode === "stop" ? "stop" : "send") ?? "";
    const key = mode === "stop" ? "web.ai.stop" : "web.ai.send";
    send.setAttribute("aria-label", ui.t(key));
    send.title = ui.t(key);
  };

  let currentStreamId = "";

  /* 斜杠命令：面板自己的三个动作。输入框里打 "/" 就列出来，
     和"发送"共用回车键，所以打开时回车先给菜单 */
  let slashCommands = [];
  let slashMenu = null;
  let slashShown = [];
  let slashIndex = 0;

  const sendMessage = async (preset) => {
    if (streaming) return;
    const question = String(preset === undefined ? input.value : preset).trim();
    if (question === "") return;
    const askedIn = ui.getCurrentDoc();

    // 设定可能在两次提问之间改过：每次发送重取一次（只是列表，不读长文）
    await loadCodex();
    const request = buildRequest(question);
    paintBudget(request.budget);
    if (request.truncated) {
      ui.toast("web.ai.ctx.truncated", "dirty", { kept: request.kept, total: request.total });
    }

    messages.push({ role: "user", text: question });
    const assistant = { role: "assistant", text: "", streaming: true };
    messages.push(assistant);
    input.value = "";
    autoGrow();
    streaming = true;
    paintSend("stop");
    renderLog();

    try {
      const res = await ui.aiChat({
        messages: request.messages,
        temperature: request.temperature,
        maxTokens: request.maxTokens,
        onStart: (id) => {
          currentStreamId = id;
        },
        onDelta: (text) => {
          assistant.text += text;
          const last = log.lastElementChild;
          const body = last?.querySelector(".ai-msg-body");
          if (body !== null && body !== undefined) {
            /* 只追加这一片，不重建整段：长回复每秒十几片，全量赋值是 O(n²) */
            let caret = body.querySelector(".ai-caret");
            if (caret === null) {
              body.replaceChildren();
              caret = document.createElement("span");
              caret.className = "ai-caret";
              body.append(caret);
            }
            body.insertBefore(document.createTextNode(text), caret);
          }
          log.scrollTop = log.scrollHeight;
        },
      });

      assistant.streaming = false;
      if (res.ok) {
        if (assistant.text === "") assistant.text = res.text;
      } else if (res.reason === "cancelled") {
        if (assistant.text === "") assistant.text = ui.t("web.ai.cancelled");
      } else {
        /* 后端带了 detail（如 "401 Unauthorized {...}"）：只显示"模型服务报错"
           等于让人无从排查，是配置错、模型错还是网络不通全靠猜 */
        const detail = typeof res.detail === "string" && res.detail !== "" ? ` · ${res.detail}` : "";
        assistant.text = `${ui.t("web.ai.err.provider")}${detail}`;
        // 报错不是对话内容：标上，别让它落盘变成下次打开时的第一条消息
        assistant.error = true;
      }
    } catch {
      assistant.streaming = false;
      assistant.text = ui.t("web.ai.err.net");
      assistant.error = true;
    } finally {
      streaming = false;
      paintSend("send");
      renderLog();
      if (assistant.error !== true && assistant.text !== "") {
        logSession([
          { type: "user", text: question, ...(typeof askedIn === "string" && askedIn !== "" ? { docId: askedIn } : {}) },
          { type: "assistant", text: assistant.text },
        ]);
      }
    }
  };

  /* ---------- 组装 ---------- */
  const build = (container) => {
    host = container;

    const head = document.createElement("div");
    head.className = "ai-head";

    const title = document.createElement("span");
    title.className = "ai-head-title";
    title.textContent = ui.t("web.ai.title");

    const spacer = document.createElement("span");
    spacer.className = "spacer";

    /* 历史提问：只列这一次会话里问过的，点一条滚回去。空的时候按钮直接禁用，
       不用"还没有提问记录"这种空态句 */
    const history = document.createElement("button");
    history.type = "button";
    history.className = "icon-btn";
    history.id = "ai-history";
    history.title = ui.t("web.ai.history");
    history.innerHTML = window.TesseraIcons?.svg("history") ?? "";
    history.disabled = true;
    history.addEventListener("click", () => {
      const asked = messages.map((message, index) => ({ message, index })).filter((item) => item.message.role === "user");
      if (asked.length === 0) return;
      const panel = document.createElement("div");
      panel.className = "ai-history";
      const bar = document.createElement("div");
      bar.className = "ai-history-head";
      const label = document.createElement("span");
      label.textContent = ui.t("web.ai.history");
      const close = document.createElement("button");
      close.type = "button";
      close.className = "icon-btn";
      close.innerHTML = window.TesseraIcons?.svg("close") ?? "";
      close.addEventListener("click", () => panel.remove());
      bar.append(label, close);
      const list = document.createElement("div");
      list.className = "ai-history-list";
      for (const item of asked) {
        const row = document.createElement("button");
        row.type = "button";
        row.className = "ai-history-item";
        row.textContent = item.message.text;
        row.title = item.message.text;
        row.addEventListener("click", () => {
          panel.remove();
          const target = log?.querySelector(`[data-index="${item.index}"]`);
          target?.scrollIntoView({ block: "center", behavior: "smooth" });
        });
        list.append(row);
      }
      panel.append(bar, list);
      const rect = history.getBoundingClientRect();
      document.body.append(panel);
      panel.style.top = `${rect.bottom + 4}px`;
      panel.style.left = `${Math.max(8, rect.right - panel.offsetWidth)}px`;
      const away = (event) => {
        if (event.target instanceof Node && !panel.contains(event.target) && event.target !== history) {
          panel.remove();
          document.removeEventListener("click", away);
        }
      };
      document.addEventListener("click", away);
    });

    const newChat = document.createElement("button");
    newChat.type = "button";
    newChat.className = "icon-btn";
    newChat.title = ui.t("web.ai.new");
    newChat.innerHTML = window.TesseraIcons?.svg("plus") ?? "";
    newChat.addEventListener("click", () => {
      messages = [];
      rotateSession();
      renderLog();
      input.focus();
    });

    const settings = document.createElement("button");
    settings.type = "button";
    settings.className = "icon-btn";
    settings.title = ui.t("web.settings.open");
    settings.innerHTML = window.TesseraIcons?.svg("gear") ?? "";
    settings.addEventListener("click", () => {
      window.dispatchEvent(new CustomEvent("tessera:open-settings", { detail: "ai" }));
    });

    /* 记录入口：审读意见与会话日志共用一扇门 */
    const records = document.createElement("button");
    records.type = "button";
    records.className = "icon-btn";
    records.id = "ai-records";
    records.title = ui.t("web.ai.records");
    records.innerHTML = window.TesseraIcons?.svg("doc") ?? "";
    records.addEventListener("click", () => void openRecords("reviews"));

    head.append(title, spacer, records, history, newChat, settings);

    log = document.createElement("div");
    log.className = "ai-log";
    log.addEventListener("scroll", () => {
      if (scrollBtn !== null) scrollBtn.hidden = log.scrollHeight - log.scrollTop - log.clientHeight < 48;
    });

    scrollBtn = document.createElement("button");
    scrollBtn.type = "button";
    scrollBtn.className = "ai-scroll";
    scrollBtn.textContent = "↓";
    scrollBtn.hidden = true;
    scrollBtn.addEventListener("click", () => {
      log.scrollTop = log.scrollHeight;
      scrollBtn.hidden = true;
    });

    const composer = document.createElement("div");
    composer.className = "ai-composer";
    contextBar = document.createElement("div");
    contextBar.className = "ai-context";
    contextChips = document.createElement("span");
    contextChips.className = "ai-context-chips";
    /* @ 引用：挑一篇别的章节带进这一次提问（当前文档/选区是自动带的，这个是手动） */
    /* 引用入口：文档和选区合成一个菜单，输入区不再放两颗只有图标的按钮 */
    const quoteSelection = () => {
      const text = ui.getSelection();
      if (text === "") {
        ui.toast("web.ai.noSelection", "dirty");
        return;
      }
      const quoted = `${NL}> ${text.split(NL).join(`${NL}> `)}`;
      input.value = `${input.value}${input.value === "" ? "" : NL}${quoted}`;
      input.focus();
      autoGrow();
    };

    const atButton = document.createElement("button");
    atButton.type = "button";
    atButton.className = "ai-chip ai-chip-btn";
    atButton.dataset.action = "reference";
    atButton.textContent = ui.t("web.ai.reference");
    atButton.title = ui.t("web.ai.referenceHint");
    atButton.addEventListener("click", async () => {
      const projectId = ui.getProjectId();
      const res = await ui.call("tessera.manuscript/docsList", { projectId });
      const docs = res?.ok === true && Array.isArray(res.docs) ? res.docs : [];
      const menu = document.createElement("div");
      menu.className = "menu ai-model-menu";
      menu.setAttribute("role", "menu");

      const pickSelection = document.createElement("button");
      pickSelection.type = "button";
      pickSelection.className = "ai-model-item";
      pickSelection.setAttribute("role", "menuitem");
      pickSelection.textContent = ui.t("web.ai.useSelection");
      pickSelection.addEventListener("click", () => {
        menu.remove();
        quoteSelection();
      });
      const sep = document.createElement("div");
      sep.className = "menu-sep";
      menu.append(pickSelection, sep);
      for (const doc of docs) {
        if (referenced.has(doc.docId)) continue;
        const item = document.createElement("button");
        item.type = "button";
        item.className = "ai-model-item";
        item.setAttribute("role", "menuitem");
        const name = document.createElement("span");
        name.textContent = String(doc.title ?? doc.docId);
        item.append(name);
        item.addEventListener("click", async () => {
          menu.remove();
          const opened = await ui.call("tessera.manuscript/docOpen", { docId: doc.docId });
          if (opened?.ok !== true) {
            ui.toast("web.status.error", "bad");
            return;
          }
          referenced.set(doc.docId, { title: String(doc.title ?? doc.docId), text: String(opened.text ?? "") });
          renderRefChips();
        });
        menu.append(item);
      }
      if (menu.childElementCount === 0) {
        const empty = document.createElement("div");
        empty.className = "ai-model-group";
        empty.textContent = ui.t("web.ai.reference.empty");
        menu.append(empty);
      }
      const rect = atButton.getBoundingClientRect();
      document.body.append(menu);
      menu.style.left = `${rect.left}px`;
      menu.style.top = `${rect.top - menu.offsetHeight - 6}px`;
      const away = (event) => {
        if (event.target instanceof Node && !menu.contains(event.target) && event.target !== atButton) {
          menu.remove();
          document.removeEventListener("click", away);
        }
      };
      document.addEventListener("click", away);
    });

    contextBar.append(contextChips, atButton);

    input = document.createElement("textarea");
    input.rows = 1;
    input.placeholder = ui.t("web.ai.placeholder");
    input.addEventListener("input", () => {
      autoGrow();
      refreshSlash();
    });
    // 面板可能先于书架挂载：拿到真项目后，第一次聚焦时补一次文件恢复
    input.addEventListener("focus", () => void restoreSession());
    input.addEventListener("keydown", (event) => {
      if (slashMenu !== null) {
        if (event.key === "ArrowDown" || event.key === "ArrowUp") {
          event.preventDefault();
          const step = event.key === "ArrowDown" ? 1 : -1;
          slashIndex = (slashIndex + step + slashShown.length) % slashShown.length;
          paintSlash();
          return;
        }
        if (event.key === "Enter" && !event.isComposing) {
          event.preventDefault();
          runSlash(slashShown[slashIndex]);
          return;
        }
        if (event.key === "Escape") {
          event.preventDefault();
          closeSlash();
          return;
        }
      }
      if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        void sendMessage();
      }
    });

    // 模型选择：清单来自 models.json（没配就内置三条）。选完立即生效（写凭据库，不是临时态）
    const modelChip = document.createElement("button");
    modelChip.type = "button";
    modelChip.className = "ai-chip ai-chip-btn";
    const setModelLabel = (text) => {
      const name = document.createElement("span");
      name.textContent = text;
      const caret = document.createElement("span");
      caret.className = "ai-chip-caret";
      caret.innerHTML = window.TesseraIcons?.svg("chevronDown") ?? "";
      modelChip.replaceChildren(name, caret);
    };
    setModelLabel("…");
    modelChip.title = ui.t("web.ai.model");
    let modelName = (model) => model?.name || model?.id || "—";
    const refreshModelChip = async () => {
      const res = await ui.call("tessera.ai/listModels", {});
      const models = res?.models ?? [];
      const current = models.find((model) => model.id === res?.current) ?? models[0];
      setModelLabel(current === undefined ? ui.t("web.ai.noModel") : modelName(current));
      modelChip.title = current === undefined
        ? ui.t("web.ai.model")
        : `${ui.t("web.ai.model")} · ${current.vendor ?? ""}`;
      return { models, current };
    };
    modelChip.addEventListener("click", async () => {
      const { models, current } = await refreshModelChip();
      const menu = document.createElement("div");
      menu.className = "menu ai-model-menu";
      menu.setAttribute("role", "menu");
      // 按供应商分组：同一家的几个模型排在一起，比一长串 id 好扫
      const groups = new Map();
      for (const model of models) {
        const vendor = String(model.vendor ?? "");
        if (!groups.has(vendor)) groups.set(vendor, []);
        groups.get(vendor).push(model);
      }
      for (const [vendor, list] of groups) {
        if (vendor !== "") {
          const head = document.createElement("div");
          head.className = "ai-model-group";
          head.textContent = vendor;
          menu.append(head);
        }
        for (const model of list) {
          const item = document.createElement("button");
          item.type = "button";
          item.className = "ai-model-item";
          item.setAttribute("role", "menuitem");
          item.dataset.active = String(model.id === current?.id);
          const label = document.createElement("span");
          label.textContent = modelName(model);
          item.append(label);
          // 上下文窗口：选模型时"能装多少字"和"会不会用图"一样关键
          if (typeof model.contextWindow === "number" && model.contextWindow > 0) {
            const ctx = document.createElement("span");
            ctx.className = "ai-model-ctx";
            ctx.textContent = model.contextWindow >= 1000
              ? `${Math.round(model.contextWindow / 100) / 10}M`
              : `${model.contextWindow}K`;
            item.append(ctx);
          }
          // 能力位来自 models.json：有就标，没有不硬造
          for (const [flag, key] of [
            [model.supportsImages, "web.ai.cap.image"],
            [model.supportsReasoning, "web.ai.cap.reasoning"],
          ]) {
            if (flag !== true) continue;
            const cap = document.createElement("span");
            cap.className = "ai-model-cap";
            cap.textContent = ui.t(key);
            item.append(cap);
          }
          if (model.id === current?.id) {
            const mark = document.createElement("span");
            mark.className = "ai-model-check";
            mark.innerHTML = window.TesseraIcons?.svg("check") ?? "";
            item.append(mark);
          }
          item.addEventListener("click", async () => {
            menu.remove();
            const saved = await ui.call("tessera.ai/setModel", { id: model.id });
            if (saved?.ok) setModelLabel(modelName(model));
            else ui.toast("web.status.error", "bad");
          });
          menu.append(item);
        }
      }
      /* 菜单底部给一条出口：找不到想要的模型时不用先想起"设置里还有一页" */
      const foot = document.createElement("button");
      foot.type = "button";
      foot.className = "ai-model-foot";
      foot.textContent = ui.t("web.settings.addModel");
      foot.addEventListener("click", () => {
        menu.remove();
        void window.openSettings?.("ai");
      });
      menu.append(foot);

      const rect = modelChip.getBoundingClientRect();
      document.body.append(menu);
      menu.style.left = `${rect.left}px`;
      menu.style.top = `${rect.top - menu.offsetHeight - 6}px`;
      const away = (event) => {
        if (event.target instanceof Node && !menu.contains(event.target) && event.target !== modelChip) {
          menu.remove();
          document.removeEventListener("click", away);
        }
      };
      document.addEventListener("click", away);
    });
    contextBar.append(atButton);

    const tools = document.createElement("div");
    tools.className = "ai-tools";
    const toolSpacer = document.createElement("span");
    toolSpacer.className = "spacer";
    const review = document.createElement("button");
    review.type = "button";
    review.className = "ai-chip-btn";
    review.dataset.action = "review";
    review.textContent = ui.t("web.review");
    review.addEventListener("click", async () => {
      // 没有打开的文稿时审读必然失败（后端只回 params.invalid）：
      // 与其让人点了看到一行报错，不如当场说清楚
      const target = ui.getCurrentDoc();
      if (typeof target !== "string" || target === "") {
        ui.toast("web.ai.needDoc", "dirty");
        return;
      }
      // 审读走 pipeline：它会把结果写成一条助手消息（插件只负责显示）
      review.disabled = true;
      try {
        const res = await ui.call("tessera.pipeline/reviewDoc", {
          projectId: ui.getProjectId(),
          docId: ui.getCurrentDoc(),
        });
        const findings = res.ok === true && Array.isArray(res.findings) ? res.findings : [];
        /* 结构化意见才统计；拿不到统计不影响把意见交给用户 */
        let stats = null;
        if (findings.length > 0) {
          const counted = await ui.call("tessera.pipeline/reviewStats", { projectId: ui.getProjectId() }).catch(() => null);
          if (counted?.ok === true) stats = counted.stats;
        }
        const note = {
          role: "assistant",
          text: res.ok
            ? findings.length > 0
              ? (typeof res.summary === "string" ? res.summary : "")
              : res.review
            : `${ui.t("web.ai.err.provider")}${typeof res.detail === "string" && res.detail !== "" ? ` · ${res.detail}` : ""}`,
          ...(findings.length > 0 ? { findings } : {}),
          ...(stats === null ? {} : { stats }),
        };
        messages.push(note);
        if (res.ok) {
          logSession([{ type: "assistant", text: note.text, ...(findings.length > 0 ? { findings } : {}) }]);
        }
        renderLog();
      } catch {
        messages.push({ role: "assistant", text: ui.t("web.ai.err.net") });
        renderLog();
      } finally {
        review.disabled = false;
      }
    });

    send = document.createElement("button");
    send.type = "button";
    send.className = "ai-send";
    paintSend("send");
    send.addEventListener("click", () => {
      if (!streaming) {
        void sendMessage();
        return;
      }
      // 生成中：停下来。之前这里直接 return，"停止"只是个不变的图标
      void ui.stopChat(currentStreamId);
    });

    slashCommands = [
      { id: "new", label: ui.t("web.ai.new"), run: () => newChat.click() },
      { id: "review", label: ui.t("web.review"), run: () => review.click() },
      { id: "quote", label: ui.t("web.ai.useSelection"), run: () => quoteSelection() },
    ];

    /* 模式切换：放在工具行最左，和 CodeBuddy 的 Craft/Ask/Plan 同位 */
    const modeChip = document.createElement("button");
    modeChip.type = "button";
    modeChip.className = "ai-chip";
    const paintModeChip = () => {
      const current = readMode();
      modeChip.textContent = ui.t(current.labelKey);
      modeChip.title = ui.t(current.hintKey);
    };
    paintModeChip();
    modeChip.addEventListener("click", () => {
      const menu = document.createElement("div");
      menu.className = "menu ai-model-menu";
      menu.setAttribute("role", "menu");
      for (const mode of AI_MODES) {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "ai-model-item ai-mode-item";
        item.dataset.active = String(mode.id === readMode().id);
        const name = document.createElement("span");
        name.textContent = ui.t(mode.labelKey);
        const hint = document.createElement("small");
        hint.className = "ai-mode-hint";
        hint.textContent = ui.t(mode.hintKey);
        item.append(name, hint);
        item.addEventListener("click", () => {
          menu.remove();
          try {
            localStorage.setItem("tessera.aiMode", mode.id);
          } catch {
            /* 隐私模式：本次会话内不记住 */
          }
          paintModeChip();
        });
        menu.append(item);
      }
      const rect = modeChip.getBoundingClientRect();
      document.body.append(menu);
      menu.style.left = `${rect.left}px`;
      menu.style.top = `${rect.top - menu.offsetHeight - 6}px`;
      const away = (event) => {
        if (event.target instanceof Node && !menu.contains(event.target) && event.target !== modeChip) {
          menu.remove();
          document.removeEventListener("click", away);
        }
      };
      document.addEventListener("click", away);
    });

    tools.append(modeChip, modelChip, review, toolSpacer, send);
    composer.append(contextBar, input, tools);
    budget = document.createElement("div");
    budget.className = "ai-budget";
    budget.hidden = true;
    host.append(head, log, scrollBtn, composer, budget);

    loadHistory();
    renderContext();
    renderLog();
    // 芯片上要显示模型名（不是 id），清单得先取一次
    void refreshModelChip();
    void loadMemory();
    void loadCodex();
    // 书架可能还没加载完（projectId 是占位值）：轮询到真项目再恢复，别指望用户刚好点一下输入框
    kickRestore();
  };

  /** 等书架就绪再试：最多 10 秒，之后放弃（用户可能已经在打字了） */
  const kickRestore = (tries = 0) => {
    if (restoredOnce) return;
    const projectId = ui.getProjectId();
    if (typeof projectId !== "string" || projectId === "" || projectId === "main") {
      if (tries < 40) setTimeout(() => kickRestore(tries + 1), 250);
      return;
    }
    void restoreSession();
  };

  // 壳的右键菜单会把选中文字发过来：填进输入框，由用户决定发不发
  window.addEventListener("tessera:ai-ask", (event) => {
    const detail = event instanceof CustomEvent ? event.detail : null;
    const text = detail && typeof detail.text === "string" ? detail.text : "";
    if (text === "" || input === null) return;
    const prompt = ui.t("web.ai.polishPrompt");
    const NL = String.fromCharCode(10);
    input.value = `${prompt}${NL}${NL}> ${text.split(NL).join(`${NL}> `)}`;
    input.focus();
    autoGrow();
  });

  ui.registerDockView({
    id: "ai",
    titleKey: "web.ai.panel",
    render: (container) => {
      try {
        build(container);
      } catch (err) {
        console.error("ai plugin build failed", err && err.stack ? err.stack : err);
      }
    },
  });

  // 壳在打开 AI 视图时刷新上下文 chip（选区可能变了）
  window.__tesseraAiRefresh = renderContext;
}
