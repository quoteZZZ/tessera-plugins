// @bun
// plugins/ai/src/provider.ts
var MAX_DETAIL = 200;
var DEFAULT_TIMEOUT_MS = 60000;
function configFromEnv(env) {
  return {
    apiKey: env.TESSERA_AI_API_KEY ?? "",
    baseUrl: (env.TESSERA_AI_BASE_URL ?? "https://api.openai.com/v1").replace(/\/+$/, ""),
    model: env.TESSERA_AI_MODEL ?? "gpt-4o-mini"
  };
}
function statusOf(config) {
  return { configured: config.apiKey !== "", model: config.model, baseUrl: config.baseUrl };
}
function validate(request) {
  if (!Array.isArray(request.messages) || request.messages.length === 0)
    return "messages";
  for (const message of request.messages) {
    if (message.role !== "system" && message.role !== "user" && message.role !== "assistant")
      return "role";
    if (typeof message.content !== "string")
      return "content";
  }
  if (request.temperature !== undefined && (request.temperature < 0 || request.temperature > 2)) {
    return "temperature";
  }
  if (request.maxTokens !== undefined && (!Number.isInteger(request.maxTokens) || request.maxTokens <= 0)) {
    return "maxTokens";
  }
  return null;
}
function snippet(text) {
  return text.replaceAll(/\s+/g, " ").trim().slice(0, MAX_DETAIL);
}
function createProvider(resolveConfig, net) {
  const preflight = (request) => {
    const invalid = validate(request);
    if (invalid !== null)
      return { ok: false, result: { ok: false, reason: "params.invalid", detail: invalid } };
    const config = resolveConfig();
    if (config.apiKey === "")
      return { ok: false, result: { ok: false, reason: "no.key" } };
    const seam = net();
    if (seam === null)
      return { ok: false, result: { ok: false, reason: "net.failed", detail: "net seam unavailable" } };
    return { ok: true, config, seam, model: request.model ?? config.model };
  };
  const parseChunk = (raw) => {
    const line = raw.trim();
    if (!line.startsWith("data:"))
      return { done: false, text: "" };
    const payload = line.slice(5).trim();
    if (payload === "")
      return { done: false, text: "" };
    if (payload === "[DONE]")
      return { done: true, text: "" };
    try {
      const parsed = JSON.parse(payload);
      const choice = parsed.choices?.[0];
      const content = choice?.delta?.content;
      return {
        done: false,
        text: typeof content === "string" ? content : "",
        ...typeof choice?.finish_reason === "string" ? { finish: choice.finish_reason } : {},
        ...choice?.delta?.reasoning_content !== undefined ? { reasoning: true } : {},
        ...typeof parsed.model === "string" ? { model: parsed.model } : {}
      };
    } catch {
      return { done: false, text: "" };
    }
  };
  const chatStream = async (request, onDelta) => {
    const ready = preflight(request);
    if (!ready.ok)
      return ready.result;
    const { config, seam, model } = ready;
    const started = Date.now();
    let text = "";
    let modelSeen = model;
    let buffer = "";
    let finish;
    let sawReasoning = false;
    try {
      const summary = await seam.stream({
        url: `${config.baseUrl}/chat/completions`,
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${config.apiKey}` },
        body: JSON.stringify({
          model,
          messages: request.messages,
          stream: true,
          ...request.temperature === undefined ? {} : { temperature: request.temperature },
          ...request.maxTokens === undefined ? {} : { max_tokens: request.maxTokens }
        }),
        timeoutMs: request.timeoutMs ?? DEFAULT_TIMEOUT_MS,
        maxBytes: 4 * 1024 * 1024
      }, (chunk) => {
        buffer += chunk;
        for (;; ) {
          const index = buffer.indexOf(`
`);
          if (index < 0)
            break;
          const line = buffer.slice(0, index);
          buffer = buffer.slice(index + 1);
          const piece = parseChunk(line);
          if (piece.model !== undefined)
            modelSeen = piece.model;
          if (piece.finish !== undefined)
            finish = piece.finish;
          if (piece.reasoning === true)
            sawReasoning = true;
          if (piece.text !== "") {
            text += piece.text;
            onDelta(piece.text);
          }
        }
      });
      const tail = parseChunk(buffer);
      if (tail.finish !== undefined)
        finish = tail.finish;
      if (tail.reasoning === true)
        sawReasoning = true;
      if (tail.text !== "") {
        text += tail.text;
        onDelta(tail.text);
      }
      if (summary.status >= 400) {
        return { ok: false, reason: "provider.failed", detail: `${summary.status}` };
      }
      if (text === "") {
        if (finish === "length" || sawReasoning) {
          return { ok: false, reason: "provider.truncated", detail: "empty content: budget exhausted; raise maxTokens" };
        }
        return { ok: false, reason: "provider.refused" };
      }
      return { ok: true, text, model: modelSeen, ms: Date.now() - started };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (message.includes("ai.cancelled"))
        return { ok: false, reason: "cancelled" };
      if (message.includes("net.timeout"))
        return { ok: false, reason: "timeout" };
      return { ok: false, reason: "net.failed", detail: message.slice(0, MAX_DETAIL) };
    }
  };
  const chat = async (request) => {
    const ready = preflight(request);
    if (!ready.ok)
      return ready.result;
    const { config, seam, model } = ready;
    const started = Date.now();
    try {
      const res = await seam.fetch({
        url: `${config.baseUrl}/chat/completions`,
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${config.apiKey}`
        },
        body: JSON.stringify({
          model,
          messages: request.messages,
          ...request.temperature === undefined ? {} : { temperature: request.temperature },
          ...request.maxTokens === undefined ? {} : { max_tokens: request.maxTokens }
        }),
        timeoutMs: request.timeoutMs ?? DEFAULT_TIMEOUT_MS,
        maxBytes: 4 * 1024 * 1024
      });
      if (res.status >= 400) {
        return { ok: false, reason: "provider.failed", detail: `${res.status} ${snippet(res.body)}` };
      }
      let body;
      try {
        body = JSON.parse(res.body);
      } catch {
        return { ok: false, reason: "provider.failed", detail: "invalid json" };
      }
      const parsed = body;
      const choice = parsed.choices?.[0];
      const text = choice?.message?.content;
      if (typeof text !== "string" || text === "") {
        const reasoningTokens = parsed.usage?.completion_tokens_details?.reasoning_tokens;
        if (choice?.finish_reason === "length" || choice?.message?.reasoning_content !== undefined) {
          const spent = typeof reasoningTokens === "number" ? ` (reasoning used ${reasoningTokens} tokens)` : "";
          return {
            ok: false,
            reason: "provider.truncated",
            detail: `empty content: budget exhausted${spent}; raise maxTokens`
          };
        }
        return { ok: false, reason: "provider.refused", detail: snippet(res.body) };
      }
      const usage = typeof parsed.usage?.prompt_tokens === "number" && typeof parsed.usage?.completion_tokens === "number" ? { promptTokens: parsed.usage.prompt_tokens, completionTokens: parsed.usage.completion_tokens } : undefined;
      return {
        ok: true,
        text,
        model: typeof parsed.model === "string" ? parsed.model : model,
        ...usage === undefined ? {} : { usage },
        ms: Date.now() - started
      };
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (message.includes("net.timeout"))
        return { ok: false, reason: "timeout" };
      return { ok: false, reason: "net.failed", detail: snippet(message) };
    }
  };
  return {
    chat,
    chatStream,
    modelSeam: { invoke: chat },
    status: () => statusOf(resolveConfig())
  };
}

// plugins/ai/src/models.ts
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import { homedir } from "os";
import { dirname, join } from "path";
var BUILTIN_MODELS = [];
function dataRoot(home = homedir()) {
  return process.env.TESSERA_DATA_ROOT ?? join(home, "Tessera");
}
function modelsPath(home = homedir()) {
  const override = process.env.TESSERA_MODELS_PATH;
  if (typeof override === "string" && override !== "")
    return override;
  return join(dataRoot(home), "models.json");
}
var text = (value) => typeof value === "string" ? value.trim() : "";
var flag = (value) => value === true;
var count = (value) => typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.round(value) : 0;
function parseEntry(raw) {
  if (raw === null || typeof raw !== "object")
    return null;
  const item = raw;
  const id = text(item.id);
  if (id === "")
    return null;
  return {
    id,
    name: text(item.name) === "" ? id : text(item.name),
    vendor: text(item.vendor) === "" ? "custom" : text(item.vendor),
    url: text(item.url),
    apiKey: text(item.apiKey),
    supportsToolCall: flag(item.supportsToolCall),
    supportsImages: flag(item.supportsImages),
    supportsReasoning: flag(item.supportsReasoning),
    contextWindow: count(item.contextWindow)
  };
}
function parseModels(raw) {
  if (raw === null || typeof raw !== "object")
    return null;
  const list = raw.models;
  if (!Array.isArray(list))
    return null;
  const out = [];
  for (const item of list) {
    const entry = parseEntry(item);
    if (entry !== null && !out.some((known) => known.id === entry.id))
      out.push(entry);
  }
  return out;
}
function readModels(file = modelsPath()) {
  if (!existsSync(file))
    return { models: BUILTIN_MODELS, source: "builtin" };
  try {
    const parsed = parseModels(JSON.parse(readFileSync(file, "utf8")));
    if (parsed === null || parsed.length === 0)
      return { models: BUILTIN_MODELS, source: "builtin" };
    return { models: parsed, source: "file" };
  } catch {
    return { models: BUILTIN_MODELS, source: "builtin" };
  }
}
function saveModels(models, file = modelsPath()) {
  const body = JSON.stringify({
    models: models.map((model) => ({
      id: model.id,
      name: model.name,
      vendor: model.vendor,
      url: model.url,
      apiKey: model.apiKey,
      supportsToolCall: model.supportsToolCall,
      supportsImages: model.supportsImages,
      supportsReasoning: model.supportsReasoning
    }))
  }, null, 2);
  mkdirSync(dirname(file), { recursive: true });
  const temp = `${file}.tmp`;
  writeFileSync(temp, `${body}
`, "utf8");
  writeFileSync(file, readFileSync(temp));
}
function upsertModel(models, next) {
  const index = models.findIndex((model) => model.id === next.id);
  if (index < 0)
    return [...models, next];
  const copy = [...models];
  copy[index] = next;
  return copy;
}
var summarize = (models) => models.map(({ id, name, vendor, supportsToolCall, supportsImages, supportsReasoning, contextWindow }) => ({
  id,
  name,
  vendor,
  supportsToolCall,
  supportsImages,
  supportsReasoning,
  contextWindow
}));

// plugins/ai/src/memory.ts
import { existsSync as existsSync2, mkdirSync as mkdirSync2, readFileSync as readFileSync2, writeFileSync as writeFileSync2 } from "fs";
import { homedir as homedir2 } from "os";
import { dirname as dirname2, join as join2 } from "path";
var MAX_ENTRIES = 50;
var MAX_TEXT = 200;
function memoryPath(home = homedir2()) {
  const override = process.env.TESSERA_MEMORY_PATH;
  if (typeof override === "string" && override !== "")
    return override;
  const root = process.env.TESSERA_DATA_ROOT ?? join2(home, "Tessera");
  return join2(root, "memory.json");
}
function parseMemory(raw) {
  if (raw === null || typeof raw !== "object")
    return null;
  const list = raw.entries;
  if (!Array.isArray(list))
    return null;
  const out = [];
  for (const item of list) {
    if (item === null || typeof item !== "object")
      continue;
    const entry = item;
    const id = typeof entry.id === "string" ? entry.id.trim() : "";
    const text = typeof entry.text === "string" ? entry.text.trim() : "";
    if (id === "" || text === "")
      continue;
    out.push({ id, text: text.slice(0, MAX_TEXT) });
  }
  return out;
}
function readMemory(file = memoryPath()) {
  if (!existsSync2(file))
    return [];
  try {
    return parseMemory(JSON.parse(readFileSync2(file, "utf8"))) ?? [];
  } catch {
    return [];
  }
}
function saveMemory(entries, file = memoryPath()) {
  const body = JSON.stringify({ entries: entries.slice(0, MAX_ENTRIES) }, null, 2);
  mkdirSync2(dirname2(file), { recursive: true });
  writeFileSync2(`${file}.tmp`, `${body}
`, "utf8");
  writeFileSync2(file, readFileSync2(`${file}.tmp`));
}
function addMemory(entries, text, now = Date.now()) {
  const clean = text.trim().slice(0, MAX_TEXT);
  if (clean === "")
    return [...entries];
  const next = [...entries, { id: `m${now.toString(36)}`, text: clean }];
  return next.length > MAX_ENTRIES ? next.slice(next.length - MAX_ENTRIES) : next;
}
var removeMemory = (entries, id) => entries.filter((entry) => entry.id !== id);

// plugins/ai/src/sessions.ts
import { appendFileSync, closeSync, existsSync as existsSync3, mkdirSync as mkdirSync3, openSync, readFileSync as readFileSync3, readSync, readdirSync, renameSync, statSync, unlinkSync, writeFileSync as writeFileSync3 } from "fs";
import { join as join3 } from "path";
var SAFE = /^[A-Za-z0-9._-]+$/;
var MAX_LINE = 64 * 1024;
var LIMITS = { maxBytes: 1e6, keepEvents: 1000, maxSessions: 50 };
var dirFor = (projectId, sessionId, root) => join3(root, "sessions", projectId, `${sessionId}.jsonl`);
var valid = (value) => typeof value === "string" && SAFE.test(value);
function rotate(file, limits) {
  let size = 0;
  try {
    size = statSync(file).size;
  } catch {
    return;
  }
  if (size <= limits.maxBytes)
    return;
  try {
    const lines = readFileSync3(file, "utf8").split(`
`).filter((line) => line.trim() !== "");
    const kept = lines.slice(-limits.keepEvents);
    const tmp = `${file}.tmp`;
    writeFileSync3(tmp, kept.length === 0 ? "" : `${kept.join(`
`)}
`, "utf8");
    renameSync(tmp, file);
  } catch {}
}
function prune(dir, limits) {
  try {
    const files = readdirSync(dir).filter((name) => name.endsWith(".jsonl")).map((name) => ({ name, at: statSync(join3(dir, name)).mtimeMs })).sort((a, b) => b.at - a.at);
    for (const file of files.slice(limits.maxSessions))
      unlinkSync(join3(dir, file.name));
  } catch {}
}
function appendEvents(projectId, sessionId, events, root = dataRoot(), limits = LIMITS) {
  if (!valid(projectId) || !valid(sessionId) || !Array.isArray(events))
    return { ok: false, appended: 0 };
  const lines = [];
  for (const event of events) {
    if (event === null || typeof event !== "object" || Array.isArray(event))
      continue;
    const record = { ts: Date.now(), ...event };
    const line = JSON.stringify(record);
    if (line.length > MAX_LINE)
      continue;
    lines.push(line);
  }
  if (lines.length === 0)
    return { ok: false, appended: 0 };
  const dir = join3(root, "sessions", projectId);
  const file = dirFor(projectId, sessionId, root);
  try {
    mkdirSync3(dir, { recursive: true });
    appendFileSync(file, `${lines.join(`
`)}
`, "utf8");
    rotate(file, limits);
    prune(dir, limits);
    return { ok: true, appended: lines.length };
  } catch {
    return { ok: false, appended: 0 };
  }
}
function readEvents(projectId, sessionId, limit = 500, root = dataRoot()) {
  if (!valid(projectId) || !valid(sessionId))
    return [];
  const file = dirFor(projectId, sessionId, root);
  if (!existsSync3(file))
    return [];
  try {
    const lines = readFileSync3(file, "utf8").split(`
`).filter((line) => line.trim() !== "");
    const events = [];
    for (const line of lines.slice(-limit)) {
      try {
        const parsed = JSON.parse(line);
        if (parsed !== null && typeof parsed === "object" && !Array.isArray(parsed))
          events.push(parsed);
      } catch {}
    }
    return events;
  } catch {
    return [];
  }
}
function previewOf(file) {
  let head = "";
  try {
    const fd = openSync(file, "r");
    try {
      const buffer = Buffer.alloc(4096);
      const bytes = readSync(fd, buffer, 0, 4096, 0);
      head = buffer.toString("utf8", 0, bytes);
    } finally {
      closeSync(fd);
    }
  } catch {
    return "";
  }
  const lines = head.split(`
`);
  if (!head.endsWith(`
`))
    lines.pop();
  for (const line of lines) {
    if (line.trim() === "")
      continue;
    try {
      const event = JSON.parse(line);
      if (event.type === "user" && typeof event.text === "string") {
        const text = event.text.trim().replace(/\s+/g, " ");
        return [...text].slice(0, 40).join("");
      }
    } catch {}
  }
  return "";
}
function listSessions(projectId, root = dataRoot()) {
  if (!valid(projectId))
    return [];
  const dir = join3(root, "sessions", projectId);
  if (!existsSync3(dir))
    return [];
  try {
    const refs = [];
    for (const name of readdirSync(dir)) {
      if (!name.endsWith(".jsonl"))
        continue;
      const id = name.slice(0, -".jsonl".length);
      if (!valid(id))
        continue;
      const path = join3(dir, name);
      const stat = statSync(path);
      refs.push({ id, at: Math.round(stat.mtimeMs), bytes: stat.size, preview: previewOf(path) });
    }
    return refs.sort((a, b) => b.at - a.at);
  } catch {
    return [];
  }
}

// plugins/ai/locales/en.ts
var en = {
  "tessera.ai.title": "AI assistant",
  "tessera.ai.activated": "AI assistant ready, model {model}",
  "tessera.ai.setting.system-prompt": "System prompt",
  "tessera.ai.setting.insert-mode": "How results are applied",
  "tessera.ai.mode.diff": "Inline diff",
  "tessera.ai.mode.replace": "Replace selection",
  "tessera.ai.mode.append": "Append to end"
};

// plugins/ai/locales/zh-cn.ts
var zhCN = {
  "tessera.ai.title": "AI \u52A9\u624B",
  "tessera.ai.activated": "AI \u52A9\u624B\u5DF2\u5C31\u7EEA\uFF0C\u5F53\u524D\u6A21\u578B {model}",
  "tessera.ai.setting.system-prompt": "\u7CFB\u7EDF\u63D0\u793A\u8BCD",
  "tessera.ai.setting.insert-mode": "\u7ED3\u679C\u5199\u56DE\u65B9\u5F0F",
  "tessera.ai.mode.diff": "\u5185\u8054 diff",
  "tessera.ai.mode.replace": "\u76F4\u63A5\u66FF\u6362\u9009\u533A",
  "tessera.ai.mode.append": "\u8FFD\u52A0\u5230\u6587\u672B"
};

// plugins/ai/src/index.ts
function createAiPlugin(config = configFromEnv(process.env)) {
  return {
    manifest: {
      apiVersion: 2,
      id: "tessera.ai",
      kind: "official",
      version: "0.1.0",
      title: "tessera.ai.title",
      activation: ["onStartup"],
      implements: ["model"],
      requires: { services: [], plugins: ["tessera.foundation"] },
      contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] },
      settings: [
        { key: "systemPrompt", title: "tessera.ai.setting.system-prompt", type: "text", default: "" }
      ]
    },
    activate(ctx) {
      const envConfig = config;
      let secrets = null;
      try {
        secrets = ctx.services.get("secrets");
      } catch {
        secrets = null;
      }
      const pick = (name, fallback) => {
        const stored = secrets?.get(name) ?? null;
        return stored !== null && stored !== "" ? stored : fallback;
      };
      const resolveConfig = () => {
        const { models } = readModels();
        const wanted = pick("ai.model", envConfig.model);
        const entry = models.find((model) => model.id === wanted) ?? null;
        const apiKey = entry !== null && entry.apiKey !== "" ? entry.apiKey : pick("ai.apiKey", envConfig.apiKey);
        const baseUrl = (entry !== null && entry.url !== "" ? entry.url : pick("ai.baseUrl", envConfig.baseUrl)).replace(/\/+$/, "");
        return { apiKey, baseUrl, model: entry?.id ?? wanted };
      };
      const provider = createProvider(resolveConfig, () => ctx.resolve("net"));
      ctx.handle("chat", (params) => provider.chat(params ?? {}));
      ctx.handle("ping", async () => {
        const res = await provider.chat({ messages: [{ role: "user", content: "ping" }] });
        const model = resolveConfig().model;
        if (res.ok === true)
          return { ok: true, reason: `ok [${model}]` };
        const detail = typeof res.detail === "string" && res.detail !== "" ? ` \xB7 ${res.detail}` : "";
        return { ok: false, reason: `${res.reason ?? "failed"}${detail} [${model}]` };
      });
      ctx.handle("status", () => provider.status());
      ctx.handle("sessionAppend", (params) => {
        const { projectId, sessionId, events } = params ?? {};
        return appendEvents(projectId, sessionId, events);
      });
      ctx.handle("sessionRead", (params) => {
        const { projectId, sessionId, limit } = params ?? {};
        return { ok: true, events: readEvents(projectId, sessionId, typeof limit === "number" ? limit : 500) };
      });
      ctx.handle("sessionList", (params) => {
        const { projectId } = params ?? {};
        return { ok: true, sessions: listSessions(projectId) };
      });
      ctx.handle("listModels", () => {
        const { models, source } = readModels();
        const stored = pick("ai.model", envConfig.model);
        const current = models.some((model) => model.id === stored) ? stored : models[0]?.id ?? "";
        if (current !== stored && current !== "" && secrets !== null) {
          try {
            secrets.set("ai.model", current);
          } catch {}
        }
        return {
          models: summarize(models),
          current,
          source,
          path: modelsPath()
        };
      });
      ctx.handle("setModel", (params) => {
        const { id } = params ?? {};
        if (typeof id !== "string" || id === "")
          return { ok: false, reason: "params.invalid" };
        const { models } = readModels();
        if (!models.some((model) => model.id === id))
          return { ok: false, reason: "params.invalid" };
        if (secrets === null)
          return { ok: false, reason: "io.failed" };
        try {
          secrets.set("ai.model", id);
          return { ok: true, value: null };
        } catch {
          return { ok: false, reason: "io.failed" };
        }
      });
      ctx.handle("addModel", (params) => {
        const entry = parseEntry(params);
        if (entry === null || entry.url === "")
          return { ok: false, reason: "params.invalid" };
        try {
          const { models } = readModels();
          const next = upsertModel(models, entry);
          saveModels(next);
          secrets?.set("ai.model", entry.id);
          return { ok: true, value: { models: summarize(next), current: entry.id, path: modelsPath() } };
        } catch {
          return { ok: false, reason: "io.failed" };
        }
      });
      ctx.handle("memoryList", () => ({ entries: readMemory(), path: memoryPath() }));
      ctx.handle("memoryAdd", (params) => {
        const { text } = params ?? {};
        if (typeof text !== "string" || text.trim() === "")
          return { ok: false, reason: "params.invalid" };
        try {
          const next = addMemory(readMemory(), text);
          saveMemory(next);
          return { ok: true, value: next };
        } catch {
          return { ok: false, reason: "io.failed" };
        }
      });
      ctx.handle("memoryRemove", (params) => {
        const { id } = params ?? {};
        if (typeof id !== "string" || id === "")
          return { ok: false, reason: "params.invalid" };
        try {
          const next = removeMemory(readMemory(), id);
          saveMemory(next);
          return { ok: true, value: next };
        } catch {
          return { ok: false, reason: "io.failed" };
        }
      });
      const streams = new Map;
      let seq = 0;
      const COALESCE_MS = 60;
      ctx.handle("chatStream", async (params) => {
        const p = params ?? {};
        const streamId = typeof p.streamId === "string" && p.streamId !== "" ? p.streamId : `s${++seq}`;
        const state = { cancelled: false };
        streams.set(streamId, state);
        let pending = "";
        let lastEmit = 0;
        const flush = (force) => {
          if (pending === "")
            return;
          if (!force && Date.now() - lastEmit < COALESCE_MS)
            return;
          ctx.emit("tessera.ai:delta", { streamId, text: pending });
          pending = "";
          lastEmit = Date.now();
        };
        try {
          const result = await provider.chatStream(p, (delta) => {
            if (state.cancelled)
              throw new Error("ai.cancelled");
            pending += delta;
            flush(false);
          });
          flush(true);
          return result;
        } finally {
          streams.delete(streamId);
        }
      });
      ctx.handle("stopStream", (params) => {
        const { streamId } = params ?? {};
        if (typeof streamId !== "string" || streamId === "")
          return { ok: false };
        const state = streams.get(streamId);
        if (state === undefined)
          return { ok: false };
        state.cancelled = true;
        return { ok: true };
      });
      const modelSeam = provider.modelSeam;
      ctx.implement("model", modelSeam);
      ctx.log("info", "tessera.ai.activated", {
        configured: resolveConfig().apiKey === "" ? 0 : 1,
        model: envConfig.model
      });
    }
  };
}
var definition = createAiPlugin();
export {
  createAiPlugin,
  definition
};
