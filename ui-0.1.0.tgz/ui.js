/**
 * ui 插件：布局归它说，其余插件把界面挂进它声明的槽位。
 *
 * 为什么单独一个插件：别的插件只知道"我有界面"，不知道也不该知道自己在界面上排第几、
 * 放在哪条槽里——那个顺序以前由 `plugins/` 的目录名决定（ai / codex / editor …）。
 * 这里把槽位与先后写成可读的声明，壳只负责照办。
 *
 * 它不画别人的面板：面板 DOM 仍归各自插件；本插件只声明槽位与先后，贡献「当前项目」
 * 状态栏项，并自己声明一个设置分区——前端插件也能被用户配置，不用为此写后端包。
 * 没装它也不影响启动：壳退回"按注册顺序、状态栏留空"。
 */
const ui = window.TesseraUI;

if (ui !== undefined) {
  ui.defineLayout({
    /* 左栏活动条：找稿子在最前，检索其次，回收站最后（它最少点） */
    activity: ["files", "outline", "search", "trash"],
    /* 右栏：AI 常驻第一，其次是写作时真正会调的排版与统计，导出最后 */
    dock: ["ai", "paragraph", "stats", "export"],
    /* 底部面板：问题比输出有用（输出是给排查用的），插件管理排在最后 */
    panel: ["problems", "output", "log", "plugins"],
    /* 状态栏：左槽只放"你在哪儿"，右槽放"当前文档相关的读数" */
    status: ["project"],
  });

  ui.registerPrefs({
    id: "plugin.ui",
    titleKey: "tessera.ui.title",
    items: [{ key: "ui.statusProject", labelKey: "pref.ui.statusProject", type: "toggle", default: true }],
  });

  /* 左槽：当前项目名。开关归本插件自己读，壳不解释这个键是什么意思 */
  const projectItem = {
    id: "project",
    slot: "statusbar.left",
    titleKey: "web.status.project",
    render: (host) => {
      const name = ui.pref("ui.statusProject", true) === false ? "" : ui.getProjectId();
      host.textContent = name;
      host.hidden = name === "";
    },
  };
  ui.registerStatusItem(projectItem);

  // 设置改了不重启就生效：壳每次应用偏好都会发这个事件，重复注册按 id 覆盖
  document.addEventListener("tessera:prefs-applied", () => ui.registerStatusItem(projectItem));
}
