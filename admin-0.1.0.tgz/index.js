// @bun
// plugins/admin/locales/en.ts
var en = {
  "tessera.admin.title": "Settings",
  "tessera.admin.activated": "Settings ready",
  "tessera.admin.secretSet": "secret written: {name}",
  "tessera.admin.settingsChanged": "settings written: {operation} (effective after restart)",
  "tessera.admin.secretDeleted": "secret deleted: {name}"
};

// plugins/admin/locales/zh-cn.ts
var zhCN = {
  "tessera.admin.title": "\u8BBE\u7F6E",
  "tessera.admin.activated": "\u8BBE\u7F6E\u5DF2\u5C31\u7EEA",
  "tessera.admin.secretSet": "\u5DF2\u5199\u5165\u51ED\u636E\uFF1A{name}",
  "tessera.admin.settingsChanged": "\u8BBE\u7F6E\u5DF2\u5199\u5165\uFF1A{operation}\uFF08\u91CD\u542F\u540E\u751F\u6548\uFF09",
  "tessera.admin.secretDeleted": "\u5DF2\u5220\u9664\u51ED\u636E\uFF1A{name}"
};

// plugins/admin/src/index.ts
var CATALOG_LIMIT = 512 * 1024;
var PACKAGE_LIMIT = 1500000;
var safeUrl = (raw) => {
  if (typeof raw !== "string")
    return null;
  try {
    const url = new URL(raw);
    if (url.protocol === "https:")
      return url;
    if (url.protocol === "http:" && (url.hostname === "127.0.0.1" || url.hostname === "localhost"))
      return url;
  } catch {}
  return null;
};
var parseCatalogEntries = (raw) => {
  if (typeof raw !== "object" || raw === null)
    return null;
  const value = raw;
  if (value.schemaVersion !== 1 || !Array.isArray(value.plugins))
    return null;
  const out = [];
  for (const item of value.plugins) {
    if (typeof item !== "object" || item === null)
      continue;
    const row = item;
    if (typeof row.id !== "string" || typeof row.name !== "string" || typeof row.version !== "string")
      continue;
    const caps = Array.isArray(row.capabilities) ? row.capabilities.filter((c) => typeof c === "string") : [];
    const distRaw = row.dist;
    const dist = distRaw !== undefined && typeof distRaw.url === "string" && typeof distRaw.integrity === "string" ? { url: distRaw.url, integrity: distRaw.integrity } : undefined;
    out.push({
      id: row.id,
      name: row.name,
      version: row.version,
      capabilities: caps,
      ...typeof row.summary === "string" ? { summary: row.summary } : {},
      ...typeof row.author === "string" ? { author: row.author } : {},
      ...typeof row.repo === "string" ? { repo: row.repo } : {},
      ...dist !== undefined ? { dist } : {}
    });
  }
  return out;
};
var NAME_PATTERN = /^[a-zA-Z][a-zA-Z0-9._-]*$/;
var definition = {
  manifest: {
    apiVersion: 2,
    id: "tessera.admin",
    kind: "official",
    version: "0.1.0",
    title: "tessera.admin.title",
    activation: ["onStartup"],
    requires: { services: ["secrets", "settings"], plugins: [] },
    contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] }
  },
  activate(ctx) {
    const secrets = ctx.services.get("secrets");
    const settings = ctx.services.get("settings");
    ctx.handle("listSecrets", () => {
      try {
        return { ok: true, value: secrets.list() };
      } catch {
        return { ok: false, reason: "io.failed" };
      }
    });
    ctx.handle("setSecret", (params) => {
      const { name, value } = params ?? {};
      if (typeof name !== "string" || typeof value !== "string")
        return { ok: false, reason: "params.invalid" };
      if (!NAME_PATTERN.test(name))
        return { ok: false, reason: "secret.invalidName" };
      if (value === "")
        return { ok: false, reason: "params.invalid" };
      try {
        secrets.set(name, value);
        ctx.log("info", "tessera.admin.secretSet", { name });
        return { ok: true, value: null };
      } catch {
        return { ok: false, reason: "io.failed" };
      }
    });
    ctx.handle("deleteSecret", (params) => {
      const { name } = params ?? {};
      if (typeof name !== "string" || name === "")
        return { ok: false, reason: "params.invalid" };
      if (!NAME_PATTERN.test(name))
        return { ok: false, reason: "secret.invalidName" };
      try {
        secrets.remove(name);
        ctx.log("info", "tessera.admin.secretDeleted", { name });
        return { ok: true, value: null };
      } catch {
        return { ok: false, reason: "io.failed" };
      }
    });
    ctx.handle("getSettings", () => {
      const raw = settings.read();
      if (!raw)
        return { ok: false, reason: "io.failed" };
      const plugins = Array.isArray(raw.plugins) ? raw.plugins.filter((item) => typeof item?.id === "string").map((item) => ({ id: item.id, enabled: item.enabled === true })) : [];
      const grantsRaw = raw.grants ?? {};
      const grants = Object.entries(grantsRaw).filter(([, caps]) => Array.isArray(caps)).map(([pluginId, caps]) => ({
        pluginId,
        capabilities: caps.filter((c) => typeof c === "string")
      }));
      const seamsRaw = raw.seams ?? {};
      const seams = Object.entries(seamsRaw).filter(([, owner]) => typeof owner === "string").map(([seamId, owner]) => ({ seamId, owner }));
      return { ok: true, value: { path: settings.path, plugins, grants, seams } };
    });
    ctx.handle("setPluginEnabled", (params) => {
      const { id, enabled } = params ?? {};
      if (typeof id !== "string" || typeof enabled !== "boolean")
        return { ok: false, reason: "params.invalid" };
      const res = settings.setPluginEnabled(id, enabled);
      if (!res.ok)
        return { ok: false, reason: res.reason === "unknown" ? "params.invalid" : "io.failed" };
      ctx.log("info", "tessera.admin.settingsChanged", { operation: "pluginEnabled" });
      return { ok: true, value: { restartRequired: true } };
    });
    ctx.handle("setGrant", (params) => {
      const { pluginId, capabilities } = params ?? {};
      if (typeof pluginId !== "string" || !Array.isArray(capabilities))
        return { ok: false, reason: "params.invalid" };
      const caps = capabilities.filter((c) => typeof c === "string");
      const res = settings.setGrant(pluginId, caps);
      if (!res.ok)
        return { ok: false, reason: res.reason === "unknown" ? "params.invalid" : "io.failed" };
      ctx.log("info", "tessera.admin.settingsChanged", { operation: "grant" });
      return { ok: true, value: { restartRequired: true } };
    });
    ctx.handle("setSeamOwner", (params) => {
      const { seamId, pluginId } = params ?? {};
      if (typeof seamId !== "string" || typeof pluginId !== "string")
        return { ok: false, reason: "params.invalid" };
      const res = settings.setSeamOwner(seamId, pluginId);
      if (!res.ok)
        return { ok: false, reason: res.reason === "unknown" ? "params.invalid" : "io.failed" };
      ctx.log("info", "tessera.admin.settingsChanged", { operation: "seamOwner" });
      return { ok: true, value: { restartRequired: true } };
    });
    const installerOf = () => {
      try {
        return ctx.services.get("pluginInstaller");
      } catch {
        return null;
      }
    };
    ctx.handle("installPlugin", (params) => {
      const { dataBase64, integrity } = params ?? {};
      if (typeof dataBase64 !== "string" || dataBase64 === "")
        return { ok: false, reason: "params.invalid" };
      const archive = Buffer.from(dataBase64, "base64");
      if (archive.length === 0 || archive.length > PACKAGE_LIMIT)
        return { ok: false, reason: "params.invalid" };
      const installer = installerOf();
      if (installer === null)
        return { ok: false, reason: "io.failed" };
      try {
        const res = installer.install(archive, typeof integrity === "string" ? integrity : undefined);
        return { ok: true, value: { id: res.id, version: res.version, restartRequired: true } };
      } catch {
        return { ok: false, reason: "io.failed" };
      }
    });
    ctx.handle("loadCatalog", async (params) => {
      const url = safeUrl((params ?? {}).url);
      if (url === null)
        return { ok: false, reason: "params.invalid" };
      try {
        const res = await fetch(url, { redirect: "follow" });
        if (!res.ok)
          return { ok: false, reason: "io.failed" };
        const text = await res.text();
        if (text.length > CATALOG_LIMIT)
          return { ok: false, reason: "params.invalid" };
        const entries = parseCatalogEntries(JSON.parse(text));
        if (entries === null)
          return { ok: false, reason: "io.failed" };
        return { ok: true, value: entries };
      } catch {
        return { ok: false, reason: "io.failed" };
      }
    });
    ctx.handle("installFromUrl", async (params) => {
      const raw = params ?? {};
      const url = safeUrl(raw.url);
      if (url === null)
        return { ok: false, reason: "params.invalid" };
      const installer = installerOf();
      if (installer === null)
        return { ok: false, reason: "io.failed" };
      try {
        const res = await fetch(url, { redirect: "follow" });
        if (!res.ok)
          return { ok: false, reason: "io.failed" };
        const declared = Number(res.headers.get("content-length") ?? 0);
        if (Number.isFinite(declared) && declared > PACKAGE_LIMIT)
          return { ok: false, reason: "params.invalid" };
        const archive = Buffer.from(await res.arrayBuffer());
        if (archive.length === 0 || archive.length > PACKAGE_LIMIT)
          return { ok: false, reason: "params.invalid" };
        const result = installer.install(archive, typeof raw.integrity === "string" ? raw.integrity : undefined);
        return { ok: true, value: { id: result.id, version: result.version, restartRequired: true } };
      } catch {
        return { ok: false, reason: "io.failed" };
      }
    });
    ctx.log("info", "tessera.admin.activated");
  }
};
export {
  definition
};
