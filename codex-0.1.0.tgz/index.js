// @bun
// plugins/codex/src/store.ts
var INTERNAL = ".tessera/codex";
var NAME_MAX = 60;
var SUMMARY_MAX = 200;
var DETAILS_MAX = 20000;
var TAGS_MAX = 20;

class CodexError extends Error {
  reason;
  constructor(reason) {
    super(`codex.${reason}`);
    this.reason = reason;
    this.name = "CodexError";
  }
}
function slugOf(name) {
  const cleaned = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "").replace(/[.\s]+$/g, "").trim().slice(0, NAME_MAX);
  if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(cleaned))
    return `x-${cleaned}`;
  return cleaned;
}
function createCodexStore(fs) {
  const entitiesDir = (projectId) => `${projectId}/${INTERNAL}/entities`;
  const indexPath = (projectId) => `${projectId}/${INTERNAL}/index.json`;
  const entityPath = (projectId, id) => `${entitiesDir(projectId)}/${id}.json`;
  const toSummary = (entity) => ({
    id: entity.id,
    kind: entity.kind,
    name: entity.name,
    summary: entity.summary,
    updatedAt: entity.updatedAt
  });
  const isEntity = (value) => {
    const v = value;
    return typeof v === "object" && v !== null && typeof v.id === "string" && typeof v.name === "string" && (v.kind === "character" || v.kind === "place" || v.kind === "timeline") && typeof v.summary === "string" && typeof v.details === "string" && Array.isArray(v.tags) && typeof v.createdAt === "number" && typeof v.updatedAt === "number";
  };
  const readEntity = (projectId, id) => {
    const raw = fs.read(entityPath(projectId, id));
    if (raw === null)
      return null;
    try {
      const parsed = JSON.parse(raw);
      return isEntity(parsed) ? parsed : null;
    } catch {
      return null;
    }
  };
  const writeEntity = (projectId, entity) => {
    fs.write(entityPath(projectId, entity.id), `${JSON.stringify(entity, null, 2)}
`);
  };
  const scan = (projectId, kind) => {
    const dir = entitiesDir(projectId);
    if (!fs.exists(dir))
      return [];
    const out = [];
    for (const name of fs.list(dir)) {
      if (!name.endsWith(".json"))
        continue;
      const id = name.slice(0, -".json".length);
      const entity = readEntity(projectId, id);
      if (!entity)
        continue;
      if (kind !== undefined && entity.kind !== kind)
        continue;
      out.push(toSummary(entity));
    }
    return out.sort((a, b) => b.updatedAt - a.updatedAt);
  };
  const readIndex = (projectId) => {
    const raw = fs.read(indexPath(projectId));
    if (raw === null)
      return null;
    try {
      const parsed = JSON.parse(raw);
      if (parsed.version !== 1 || !Array.isArray(parsed.ids))
        return null;
      return parsed.ids.filter((id) => typeof id === "string");
    } catch {
      return null;
    }
  };
  const writeIndex = (projectId, ids) => {
    fs.write(indexPath(projectId), `${JSON.stringify({ version: 1, ids }, null, 2)}
`);
  };
  const list = (projectId, kind) => {
    const ids = readIndex(projectId);
    if (ids === null) {
      const all = scan(projectId);
      writeIndex(projectId, all.map((e) => e.id));
      return kind === undefined ? all : all.filter((e) => e.kind === kind);
    }
    const out = [];
    let missing = false;
    for (const id of ids) {
      const entity = readEntity(projectId, id);
      if (!entity) {
        missing = true;
        continue;
      }
      if (kind !== undefined && entity.kind !== kind)
        continue;
      out.push(toSummary(entity));
    }
    if (missing) {
      const all = scan(projectId);
      writeIndex(projectId, all.map((e) => e.id));
      return kind === undefined ? all : all.filter((e) => e.kind === kind);
    }
    return out.sort((a, b) => b.updatedAt - a.updatedAt);
  };
  const allocateId = (projectId, kind, name) => {
    const slug = slugOf(name);
    if (slug === "")
      throw new CodexError("params.invalid");
    const base = `${kind}-${slug}`;
    if (!fs.exists(entityPath(projectId, base)))
      return base;
    for (let i = 2;i < 500; i += 1) {
      const candidate = `${base}-${i}`;
      if (!fs.exists(entityPath(projectId, candidate)))
        return candidate;
    }
    throw new CodexError("exists");
  };
  const normalizeTags = (tags) => {
    if (tags === undefined)
      return [];
    return [...new Set(tags.map((t) => t.trim()).filter((t) => t !== ""))].slice(0, TAGS_MAX);
  };
  return {
    list,
    get(projectId, id) {
      const entity = readEntity(projectId, id);
      if (!entity)
        throw new CodexError("not.found");
      return entity;
    },
    create(input) {
      const name = input.name.trim().slice(0, NAME_MAX);
      if (name === "")
        throw new CodexError("params.invalid");
      const summary = (input.summary ?? "").trim().slice(0, SUMMARY_MAX);
      const details = (input.details ?? "").slice(0, DETAILS_MAX);
      const now = Date.now();
      const id = allocateId(input.projectId, input.kind, name);
      const entity = {
        id,
        kind: input.kind,
        name,
        summary,
        details,
        tags: normalizeTags(input.tags),
        createdAt: now,
        updatedAt: now
      };
      const ids = readIndex(input.projectId) ?? scan(input.projectId).map((e) => e.id);
      writeEntity(input.projectId, entity);
      writeIndex(input.projectId, [id, ...ids.filter((x) => x !== id)]);
      return entity;
    },
    update(projectId, id, patch) {
      const current = readEntity(projectId, id);
      if (!current)
        throw new CodexError("not.found");
      if (patch.name !== undefined && patch.name.trim() === "")
        throw new CodexError("params.invalid");
      const next = {
        ...current,
        name: patch.name === undefined ? current.name : patch.name.trim().slice(0, NAME_MAX),
        summary: patch.summary === undefined ? current.summary : patch.summary.trim().slice(0, SUMMARY_MAX),
        details: patch.details === undefined ? current.details : patch.details.slice(0, DETAILS_MAX),
        tags: patch.tags === undefined ? current.tags : normalizeTags(patch.tags),
        updatedAt: Date.now()
      };
      writeEntity(projectId, next);
      return next;
    },
    remove(projectId, id) {
      if (!fs.exists(entityPath(projectId, id)))
        throw new CodexError("not.found");
      fs.remove(entityPath(projectId, id));
      const ids = readIndex(projectId);
      if (ids !== null)
        writeIndex(projectId, ids.filter((x) => x !== id));
    }
  };
}

// plugins/codex/locales/en.ts
var en = {
  "tessera.codex.title": "Codex",
  "tessera.codex.activated": "Story bible ready",
  "tessera.codex.noFs": "codex could not resolve the fs seam; entity store unavailable"
};

// plugins/codex/locales/zh-cn.ts
var zhCN = {
  "tessera.codex.title": "\u8BBE\u5B9A\u5E93",
  "tessera.codex.activated": "\u8BBE\u5B9A\u5E93\u5DF2\u5C31\u7EEA",
  "tessera.codex.noFs": "\u8BBE\u5B9A\u53F6\u6CA1\u6709\u62FF\u5230 fs \u7F1D\uFF0C\u5B9E\u4F53\u5E93\u4E0D\u53EF\u7528"
};

// plugins/codex/src/index.ts
var KINDS = new Set(["character", "place", "timeline"]);
var MAX_MENTIONS = 50;
var SNIPPET_MAX = 200;
function reasonOf(err) {
  if (err instanceof CodexError)
    return err.reason;
  return "io.failed";
}
var definition = {
  manifest: {
    apiVersion: 2,
    id: "tessera.codex",
    kind: "official",
    version: "0.1.0",
    title: "tessera.codex.title",
    activation: ["onStartup"],
    requires: { services: [], plugins: ["tessera.manuscript"] },
    contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] }
  },
  activate(ctx) {
    const fs = ctx.resolve("fs");
    const store = fs === null ? null : createCodexStore(fs);
    const guard = (fn) => {
      try {
        return fn();
      } catch (err) {
        return { ok: false, reason: reasonOf(err) };
      }
    };
    const requireProject = (params) => {
      const { projectId } = params ?? {};
      if (typeof projectId !== "string" || projectId === "")
        throw new CodexError("params.invalid");
      return projectId;
    };
    ctx.handle("list", (params) => {
      if (store === null)
        return { ok: false, reason: "seam.missing" };
      const { kind } = params ?? {};
      if (kind !== undefined && (typeof kind !== "string" || !KINDS.has(kind))) {
        return { ok: false, reason: "seam.missing" };
      }
      const projectId = requireProject(params);
      return guard(() => ({ ok: true, entities: store.list(projectId, kind) }));
    });
    ctx.handle("get", (params) => {
      if (store === null)
        return { ok: false, reason: "seam.missing" };
      const { id } = params ?? {};
      if (typeof id !== "string" || id === "")
        return { ok: false, reason: "params.invalid" };
      return guard(() => ({ ok: true, entity: store.get(requireProject(params), id) }));
    });
    ctx.handle("create", (params) => {
      if (store === null)
        return { ok: false, reason: "seam.missing" };
      const p = params ?? {};
      if (typeof p.kind !== "string" || !KINDS.has(p.kind)) {
        return { ok: false, reason: "params.invalid" };
      }
      if (typeof p.name !== "string")
        return { ok: false, reason: "params.invalid" };
      return guard(() => ({
        ok: true,
        entity: store.create({
          projectId: requireProject(params),
          kind: p.kind,
          name: p.name,
          ...typeof p.summary === "string" ? { summary: p.summary } : {},
          ...typeof p.details === "string" ? { details: p.details } : {},
          ...Array.isArray(p.tags) ? { tags: p.tags.filter((t) => typeof t === "string") } : {}
        })
      }));
    });
    ctx.handle("update", (params) => {
      if (store === null)
        return { ok: false, reason: "seam.missing" };
      const p = params ?? {};
      if (typeof p.id !== "string" || p.id === "")
        return { ok: false, reason: "params.invalid" };
      return guard(() => ({
        ok: true,
        entity: store.update(requireProject(params), p.id, {
          ...typeof p.name === "string" ? { name: p.name } : {},
          ...typeof p.summary === "string" ? { summary: p.summary } : {},
          ...typeof p.details === "string" ? { details: p.details } : {},
          ...Array.isArray(p.tags) ? { tags: p.tags.filter((t) => typeof t === "string") } : {}
        })
      }));
    });
    ctx.handle("remove", (params) => {
      if (store === null)
        return { ok: false, reason: "seam.missing" };
      const { id } = params ?? {};
      if (typeof id !== "string" || id === "")
        return { ok: false, reason: "params.invalid" };
      return guard(() => {
        store.remove(requireProject(params), id);
        return { ok: true };
      });
    });
    ctx.handle("mentions", (params) => {
      if (store === null)
        return { ok: false, reason: "seam.missing" };
      const docs = ctx.resolve("docs");
      if (docs === null)
        return { ok: false, reason: "seam.missing" };
      const { id } = params ?? {};
      if (typeof id !== "string" || id === "")
        return { ok: false, reason: "params.invalid" };
      return guard(() => {
        const projectId = requireProject(params);
        const entity = store.get(projectId, id);
        const listed = docs.list(projectId);
        if (!("docs" in listed))
          return { ok: false, reason: "io.failed" };
        const hits = [];
        let truncated = false;
        for (const doc of listed.docs) {
          const opened = docs.open(doc.docId);
          if (!opened.ok)
            continue;
          const lines = opened.text.split(`
`);
          for (let i = 0;i < lines.length; i += 1) {
            const line = lines[i] ?? "";
            if (!line.includes(entity.name))
              continue;
            hits.push({ docId: doc.docId, title: doc.title, line: i + 1, text: line.trim().slice(0, SNIPPET_MAX) });
            if (hits.length >= MAX_MENTIONS) {
              truncated = true;
              break;
            }
          }
          if (truncated)
            break;
        }
        return { ok: true, hits, truncated };
      });
    });
    if (store === null) {
      ctx.log("warn", "tessera.codex.noFs");
    }
    ctx.log("info", "tessera.codex.activated");
  }
};
export {
  definition
};
