/**
 * codex 插件（前端）：设定库（人物 / 地点 / 时间线）。
 *
 * 判定标准：关掉它，编辑与保存不受影响；它有自己的状态（实体列表）与自己的界面。
 * 壳只提供 call / getProjectId / prompt / openModal / toast。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  const KINDS = ["character", "place", "timeline"];
  let dialog = null;
  let list = null;
  let empty = null;
  let mentions = null;
  let kind = "character";
  let entities = [];
  const tabButtons = new Map();

  const render = () => {
    list.replaceChildren();
    empty.hidden = entities.length > 0;

    for (const button of tabButtons.values()) {
      const value = button.dataset.kind;
      const count = entities.filter((entity) => entity.kind === value).length;
      button.replaceChildren(document.createTextNode(ui.t("web.codex.kind." + value)));
      button.dataset.active = String(value === kind);
      if (count > 0) {
        const badge = document.createElement("span");
        badge.className = "tab-count";
        badge.textContent = String(count);
        button.append(badge);
      }
    }

    for (const entity of entities) {
      const li = document.createElement("li");
      const name = document.createElement("span");
      name.textContent = entity.name;
      const summary = document.createElement("small");
      summary.textContent = entity.summary === undefined ? "" : entity.summary;
      const del = document.createElement("button");
      del.type = "button";
      del.className = "del";
      del.innerHTML = window.TesseraIcons?.svg("close") ?? "";
      del.title = ui.t("web.codex.delete");
      del.addEventListener("click", async (event) => {
        event.stopPropagation();
        await ui.call("tessera.codex/remove", { projectId: ui.getProjectId(), id: entity.id });
        await load();
      });
      li.append(name, summary, del);
      li.addEventListener("click", () => void showMentions(entity));
      list.append(li);
    }
  };

  const load = async () => {
    const res = await ui.call("tessera.codex/list", { projectId: ui.getProjectId(), kind });
    entities = res.ok ? res.entities : [];
    render();
  };

  const showMentions = async (entity) => {
    mentions.hidden = false;
    mentions.textContent = ui.t("web.ai.thinking");
    const res = await ui.call("tessera.codex/mentions", { projectId: ui.getProjectId(), id: entity.id });
    if (!res.ok) {
      mentions.textContent = ui.t("web.status.error");
      return;
    }
    mentions.textContent =
      res.hits.length === 0
        ? ui.t("web.codex.noMentions")
        : res.hits.map((hit) => hit.title + ":" + hit.line + "  " + hit.text).join(String.fromCharCode(10));
  };

  const build = () => {
    if (dialog !== null) return dialog;
    dialog = document.createElement("dialog");
    dialog.className = "settings sheet codex";
    dialog.id = "plugin-codex";

    const head = document.createElement("div");
    head.className = "sheet-head";
    const title = document.createElement("h2");
    title.textContent = ui.t("web.codex");
    const close = document.createElement("button");
    close.type = "button";
    close.className = "icon-btn sheet-x";
    close.innerHTML = window.TesseraIcons?.svg("close") ?? "";
    close.addEventListener("click", () => dialog.close());
    head.append(title, close);

    const tabs = document.createElement("div");
    tabs.className = "tabs";
    for (const value of KINDS) {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.kind = value;
      button.addEventListener("click", async () => {
        kind = value;
        mentions.hidden = true;
        await load();
      });
      tabButtons.set(value, button);
      tabs.append(button);
    }

    list = document.createElement("ul");

    empty = document.createElement("div");
    empty.className = "sheet-empty";
    empty.hidden = true;
    const emptyLabel = document.createElement("p");
    emptyLabel.className = "sheet-empty-title";
    emptyLabel.textContent = ui.t("web.codex.empty");
    empty.append(emptyLabel);

    mentions = document.createElement("pre");
    mentions.className = "ai-output";
    mentions.hidden = true;

    const actions = document.createElement("div");
    actions.className = "dialog-actions";
    const create = document.createElement("button");
    create.type = "button";
    create.textContent = ui.t("web.codex.new");
    create.addEventListener("click", async () => {
      const name = await ui.prompt("web.codex.prompt");
      if (name === null || name.trim() === "") return;
      await ui.call("tessera.codex/create", { projectId: ui.getProjectId(), kind, name });
      await load();
    });
    const closeFoot = document.createElement("button");
    closeFoot.type = "button";
    closeFoot.textContent = ui.t("web.close");
    closeFoot.addEventListener("click", () => dialog.close());
    actions.append(create, closeFoot);

    const body = document.createElement("div");
    body.className = "codex-body";
    body.append(list, mentions, empty);

    dialog.append(head, tabs, body, actions);
    document.body.append(dialog);
    return dialog;
  };

  const open = async () => {
    const node = build();
    ui.openModal(node);
    await load();
  };

  ui.registerCommand({ id: "codex", title: ui.t("web.codex"), run: () => void open() });
  window.__tesseraCodexOpen = open;
}
