/**
 * workbench 插件的前端部分：底部「输出」面板。
 *
 * 为什么放在这里而不是壳里：输出面板不属于内核——关掉它，编辑器照样能用。
 * 它只是"把状态写成一行行日志"，换成"问题列表"或"终端"都能替换。
 * 这正是插件的判定标准：可关闭、有自己的状态、失败不拖垮别人。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  ui.registerPanel({
    id: "output",
    titleKey: "web.panel.output",
    render: () => {
      const pre = document.createElement("pre");
      pre.className = "panel-output";
      pre.textContent = ui.getOutputLog().join(String.fromCharCode(10));
      return pre;
    },
    onMount: (body) => {
      body.scrollTop = body.scrollHeight;
    },
  });

  /* 「问题」面板：对当前正文做几条 Markdown 体检，点条目跳到对应行。
     只是"能看出问题"，不改正文——修不修由人决定。 */
  const scan = (text) => {
    const issues = [];
    const lines = text.split(String.fromCharCode(10));
    let fence = -1;
    let lastLevel = 0;

    lines.forEach((raw, index) => {
      const line = raw.trimEnd();
      if (index > 60 && issues.length > 40) return;

      if (line.startsWith("```")) {
        if (fence === -1) fence = index;
        else fence = -1;
        return;
      }
      if (fence !== -1) return;

      const heading = /^(#{1,6})\s+(.*)$/.exec(line);
      if (heading !== null) {
        const level = heading[1].length;
        if (lastLevel > 0 && level > lastLevel + 1) {
          issues.push({ line: index, key: "web.problems.headingJump" });
        }
        lastLevel = level;
      }
      if (/\]\(\s*\)/.test(line)) issues.push({ line: index, key: "web.problems.emptyLink" });
      if (raw !== line && line !== "") issues.push({ line: index, key: "web.problems.trailingSpace" });
    });

    if (fence !== -1) issues.push({ line: fence, key: "web.problems.unclosedCode" });
    return issues;
  };

  ui.registerPanel({
    id: "problems",
    titleKey: "web.panel.problems",
    render: () => {
      const text = ui.getDocText();
      const issues = text === "" ? [] : scan(text);
      const wrap = document.createElement("ul");
      wrap.className = "issue-list";

      if (issues.length === 0) {
        const ok = document.createElement("li");
        ok.className = "hint";
        // "没有问题"与"没有文稿"是两件事：前者说明检查过了，后者说明还没开始
        ok.textContent = ui.t(ui.getCurrentDoc() ? "web.problems.none" : "web.problems.noDoc");
        wrap.append(ok);
        return wrap;
      }

      for (const issue of issues.slice(0, 50)) {
        const li = document.createElement("li");
        li.className = "issue-row";
        const where = document.createElement("span");
        where.className = "issue-line";
        where.textContent = String(issue.line + 1);
        const what = document.createElement("span");
        what.textContent = ui.t(issue.key);
        li.append(where, what);
        li.addEventListener("click", () => ui.revealLine(issue.line));
        wrap.append(li);
      }
      return wrap;
    },
  });
}
