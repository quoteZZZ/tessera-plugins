// @bun
// plugins/foundation/locales/en.ts
var en = {
  "tessera.foundation.title": "Foundation",
  "tessera.foundation.activated": "Foundation services ready"
};

// plugins/foundation/locales/zh-cn.ts
var zhCN = {
  "tessera.foundation.title": "\u57FA\u7840\u670D\u52A1",
  "tessera.foundation.activated": "\u57FA\u7840\u670D\u52A1\u5DF2\u5C31\u7EEA"
};

// plugins/foundation/src/net.ts
var DEFAULT_TIMEOUT_MS = 30000;
var DEFAULT_MAX_BYTES = 1024 * 1024;
var ALLOWED_PROTOCOLS = new Set(["http:", "https:"]);
function parseUrl(raw) {
  let url;
  try {
    url = new URL(raw);
  } catch {
    throw new Error(`net.invalidUrl:${raw}`);
  }
  if (!ALLOWED_PROTOCOLS.has(url.protocol)) {
    throw new Error(`net.protocolNotAllowed:${url.protocol}`);
  }
  return url;
}
async function readCapped(res, maxBytes) {
  const declared = Number(res.headers.get("content-length") ?? "0");
  if (Number.isFinite(declared) && declared > maxBytes) {
    await res.body?.cancel().catch(() => {
      return;
    });
    return { text: "", truncated: true };
  }
  const body = res.body;
  if (!body)
    return { text: "", truncated: false };
  const reader = body.getReader();
  const decoder = new TextDecoder;
  let text = "";
  let received = 0;
  try {
    for (;; ) {
      const { value, done } = await reader.read();
      if (done)
        break;
      received += value.byteLength;
      if (received > maxBytes) {
        text += decoder.decode(value, { stream: true });
        await reader.cancel().catch(() => {
          return;
        });
        return { text: text.slice(0, maxBytes), truncated: true };
      }
      text += decoder.decode(value, { stream: true });
    }
  } finally {
    reader.releaseLock?.();
  }
  return { text: text + decoder.decode(), truncated: false };
}
var netSeam = {
  async fetch(request) {
    const url = parseUrl(request.url);
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const maxBytes = request.maxBytes ?? DEFAULT_MAX_BYTES;
    const controller = new AbortController;
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const init = {
        method: request.method ?? "GET",
        signal: controller.signal,
        redirect: "follow"
      };
      if (request.headers !== undefined)
        init.headers = { ...request.headers };
      if (request.body !== undefined)
        init.body = request.body;
      const res = await fetch(url, init);
      const { text, truncated } = await readCapped(res, maxBytes);
      const headers = {};
      res.headers.forEach((value, key) => {
        headers[key] = value;
      });
      return { status: res.status, headers, body: text, truncated };
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        throw new Error(`net.timeout:${timeoutMs}ms`);
      }
      throw err;
    } finally {
      clearTimeout(timer);
    }
  },
  async stream(request, onChunk) {
    const url = parseUrl(request.url);
    const timeoutMs = request.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const maxBytes = request.maxBytes ?? DEFAULT_MAX_BYTES;
    const controller = new AbortController;
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const init = {
        method: request.method ?? "GET",
        signal: controller.signal,
        redirect: "follow"
      };
      if (request.headers !== undefined)
        init.headers = { ...request.headers };
      if (request.body !== undefined)
        init.body = request.body;
      const res = await fetch(url, init);
      if (!res.body)
        return { status: res.status, bytes: 0, truncated: false };
      const reader = res.body.getReader();
      const decoder = new TextDecoder;
      let bytes = 0;
      let truncated = false;
      try {
        for (;; ) {
          const { value, done } = await reader.read();
          if (done)
            break;
          bytes += value.byteLength;
          if (bytes > maxBytes) {
            truncated = true;
            await reader.cancel().catch(() => {
              return;
            });
            break;
          }
          try {
            onChunk(decoder.decode(value, { stream: true }));
          } catch (err) {
            await reader.cancel().catch(() => {
              return;
            });
            throw err;
          }
        }
      } finally {
        reader.releaseLock?.();
      }
      return { status: res.status, bytes, truncated };
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") {
        throw new Error(`net.timeout:${timeoutMs}ms`);
      }
      throw err;
    } finally {
      clearTimeout(timer);
    }
  }
};

// plugins/foundation/src/index.ts
var definition = {
  manifest: {
    apiVersion: 2,
    id: "tessera.foundation",
    kind: "official",
    version: "0.1.0",
    title: "tessera.foundation.title",
    activation: ["onStartup"],
    implements: ["clock", "net", "greeter"],
    exposes: [{ id: "util", version: "1.0.0" }],
    contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] }
  },
  activate(ctx) {
    let tick = 0;
    ctx.implement("clock", {
      now: () => Date.now(),
      tick: () => ++tick
    });
    ctx.implement("net", netSeam);
    ctx.implement("greeter", {
      greet: (name) => `foundation: ${name}`
    });
    ctx.provide("util", {
      repeat: (s, n) => s.repeat(n),
      upper: (s) => s.toUpperCase()
    });
    ctx.log("info", "tessera.foundation.activated");
  }
};
export {
  definition
};
