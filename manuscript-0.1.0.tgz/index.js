// @bun
var __defProp = Object.defineProperty;
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};

// packages/base/src/path-guard.ts
import { existsSync, realpathSync } from "fs";
import { dirname, isAbsolute, relative, resolve, sep } from "path";

class PathRejected extends Error {
  reason;
  input;
  constructor(reason, input) {
    super(`path.${reason}:${input}`);
    this.reason = reason;
    this.input = input;
    this.name = "PathRejected";
  }
}
function isContained(root, target) {
  if (target === root)
    return true;
  const rel = relative(root, target);
  return rel !== "" && !rel.startsWith(`..${sep}`) && rel !== ".." && !isAbsolute(rel);
}
function resolveInsideRoot(root, input) {
  if (typeof input !== "string" || input.trim() === "")
    throw new PathRejected("empty", String(input));
  if (input.includes("\x00"))
    throw new PathRejected("nul-byte", input);
  const normalized = input.replaceAll("\\", "/");
  if (normalized.startsWith("//"))
    throw new PathRejected("unc", input);
  if (/^[a-zA-Z]:/.test(normalized))
    throw new PathRejected("drive-letter", input);
  if (normalized.startsWith("/"))
    throw new PathRejected("absolute", input);
  const rootAbs = resolve(root);
  const target = resolve(rootAbs, normalized);
  if (!isContained(rootAbs, target))
    throw new PathRejected("escape", input);
  return target;
}
function assertRealPathInside(root, target) {
  const rootReal = realpathSync(resolve(root));
  let anchor = target;
  while (!existsSync(anchor)) {
    const parent = dirname(anchor);
    if (parent === anchor)
      break;
    anchor = parent;
  }
  if (!existsSync(anchor))
    return;
  const anchorReal = realpathSync(anchor);
  if (!isContained(rootReal, anchorReal))
    throw new PathRejected("symlink-escape", target);
}
// packages/base/src/library-store.ts
import {
  closeSync,
  existsSync as existsSync2,
  fsyncSync,
  mkdirSync,
  openSync,
  readFileSync,
  readdirSync,
  renameSync,
  rmSync,
  statSync,
  writeFileSync,
  writeSync
} from "fs";
import { dirname as dirname2, join, resolve as resolve2 } from "path";
var tmpSeq = 0;
function createLibraryStore(root) {
  const rootAbs = resolve2(root);
  mkdirSync(rootAbs, { recursive: true });
  const safe = (input) => {
    const target = resolveInsideRoot(rootAbs, input);
    assertRealPathInside(rootAbs, target);
    return target;
  };
  return {
    root: rootAbs,
    exists(path) {
      return existsSync2(safe(path));
    },
    stat(path) {
      const target = safe(path);
      try {
        const st = statSync(target);
        return { size: st.size, mtimeMs: st.mtimeMs, isFile: st.isFile() };
      } catch {
        return null;
      }
    },
    list(path) {
      const target = path === "" || path === "." ? rootAbs : safe(path);
      try {
        return readdirSync(target).sort();
      } catch {
        return [];
      }
    },
    readRaw(path) {
      const target = safe(path);
      try {
        return readFileSync(target);
      } catch {
        return null;
      }
    },
    read(path) {
      const target = safe(path);
      try {
        return readFileSync(target, "utf8");
      } catch {
        return null;
      }
    },
    writeBytes(path, bytes) {
      const target = safe(path);
      mkdirSync(dirname2(target), { recursive: true });
      writeFileSync(target, bytes);
    },
    write(path, text) {
      const target = safe(path);
      mkdirSync(dirname2(target), { recursive: true });
      const tmp = `${target}.tmp-${process.pid}-${++tmpSeq}`;
      const fd = openSync(tmp, "w");
      try {
        writeSync(fd, text);
        fsyncSync(fd);
      } finally {
        closeSync(fd);
      }
      try {
        renameSync(tmp, target);
      } catch (err) {
        rmSync(tmp, { force: true });
        throw err;
      }
    },
    remove(path) {
      rmSync(safe(path), { recursive: true, force: true });
    },
    move(from, to) {
      const src = safe(from);
      const dst = safe(to);
      if (src === dst)
        return;
      mkdirSync(dirname2(dst), { recursive: true });
      renameSync(src, dst);
    },
    walk(prefix, maxDepth = 8, maxEntries = 20000) {
      const start = prefix === "" || prefix === "." ? rootAbs : safe(prefix);
      const out = [];
      const normalized = prefix === "." ? "" : prefix.replaceAll("\\", "/").replace(/\/+$/, "");
      const queue = [{ abs: start, rel: normalized, depth: 0 }];
      while (queue.length > 0 && out.length < maxEntries) {
        const frame = queue.pop();
        if (!frame)
          break;
        let entries;
        try {
          entries = readdirSync(frame.abs, { withFileTypes: true });
        } catch {
          continue;
        }
        for (const entry of entries) {
          const rel = frame.rel === "" ? entry.name : `${frame.rel}/${entry.name}`;
          const abs = join(frame.abs, entry.name);
          let st;
          try {
            st = statSync(abs);
          } catch {
            continue;
          }
          out.push({ path: rel, size: st.size, mtimeMs: st.mtimeMs, isFile: st.isFile(), isDir: st.isDirectory() });
          if (entry.isDirectory() && frame.depth + 1 < maxDepth) {
            queue.push({ abs, rel, depth: frame.depth + 1 });
          }
          if (out.length >= maxEntries)
            break;
        }
      }
      return out;
    }
  };
}
// packages/library/src/documents.ts
import { createHash } from "crypto";
// packages/schema/src/contributes.ts
var CONTRIBUTION_KEYS = {
  commands: "commands",
  menus: "menus",
  keybindings: "keybindings",
  panels: "panels",
  statusItems: "statusItems",
  views: "views",
  prompts: "prompts",
  templates: "templates",
  entityTypes: "entityTypes",
  settings: "settings",
  genres: "genres",
  seams: "seams",
  locales: "locales"
};
var CONTRIBUTION_KEY_LIST = Object.values(CONTRIBUTION_KEYS);

// packages/schema/src/seam.ts
var ROOT_SEAM_DEFS = [
  { id: "fs", overridable: false, description: "filesystem primitives" },
  { id: "net", overridable: false, description: "outbound http" },
  { id: "proc", overridable: false, description: "child process" },
  { id: "human", overridable: false, description: "human confirmation" },
  { id: "clock", overridable: false, description: "time and timers" },
  { id: "model", overridable: false, description: "model gateway" }
];
var RESERVED_ROOT_SEAMS = ROOT_SEAM_DEFS.map((s) => s.id);

// packages/schema/src/manifest.ts
var KNOWN_FIELDS = new Set([
  "apiVersion",
  "id",
  "kind",
  "version",
  "title",
  "platform",
  "activation",
  "capabilities",
  "optionalCapabilities",
  "implements",
  "requires",
  "contributes",
  "settings",
  "limits",
  "engines",
  "exposes",
  "experimental"
]);
// packages/schema/src/seam-methods.ts
var ro = (name) => ({ name, mutating: false, serializable: true });
var rw = (name) => ({ name, mutating: true, serializable: true });
var SEAM_METHODS = {
  fs: [ro("exists"), ro("stat"), ro("list"), ro("read"), rw("write"), rw("remove")],
  net: [rw("fetch"), { name: "stream", mutating: true, serializable: false }],
  proc: [rw("exec")],
  human: [rw("confirm"), rw("ask")],
  clock: [ro("now"), ro("tick")],
  model: [rw("invoke")],
  greeter: [ro("greet")],
  docs: [ro("list"), ro("open"), ro("stat")]
};
// packages/schema/src/editor-protocol.ts
var MANUSCRIPT_DIR = "manuscript";
var PROJECT_FILE = "project.json";
var MIRROR_MARK = "<!--tessera:mirror-->";
// packages/schema/src/error-payload.ts
var TRANSPORT_CODES = new Set(["TIMEOUT", "BACKPRESSURE", "IDLE"]);
// packages/api/src/paths.ts
var INTERNAL_DIR = ".tessera";
var draftsDir = (project) => `${project}/${INTERNAL_DIR}/drafts`;
var draftFile = (project, digest) => `${draftsDir(project)}/${digest}.json`;
var trashDir = (project) => `${project}/${INTERNAL_DIR}/trash`;
// node_modules/.bun/orderedmap@2.1.1/node_modules/orderedmap/dist/index.js
function OrderedMap(content) {
  this.content = content;
}
OrderedMap.prototype = {
  constructor: OrderedMap,
  find: function(key) {
    for (var i = 0;i < this.content.length; i += 2)
      if (this.content[i] === key)
        return i;
    return -1;
  },
  get: function(key) {
    var found = this.find(key);
    return found == -1 ? undefined : this.content[found + 1];
  },
  update: function(key, value, newKey) {
    var self = newKey && newKey != key ? this.remove(newKey) : this;
    var found = self.find(key), content = self.content.slice();
    if (found == -1) {
      content.push(newKey || key, value);
    } else {
      content[found + 1] = value;
      if (newKey)
        content[found] = newKey;
    }
    return new OrderedMap(content);
  },
  remove: function(key) {
    var found = this.find(key);
    if (found == -1)
      return this;
    var content = this.content.slice();
    content.splice(found, 2);
    return new OrderedMap(content);
  },
  addToStart: function(key, value) {
    return new OrderedMap([key, value].concat(this.remove(key).content));
  },
  addToEnd: function(key, value) {
    var content = this.remove(key).content.slice();
    content.push(key, value);
    return new OrderedMap(content);
  },
  addBefore: function(place, key, value) {
    var without = this.remove(key), content = without.content.slice();
    var found = without.find(place);
    content.splice(found == -1 ? content.length : found, 0, key, value);
    return new OrderedMap(content);
  },
  forEach: function(f) {
    for (var i = 0;i < this.content.length; i += 2)
      f(this.content[i], this.content[i + 1]);
  },
  prepend: function(map) {
    map = OrderedMap.from(map);
    if (!map.size)
      return this;
    return new OrderedMap(map.content.concat(this.subtract(map).content));
  },
  append: function(map) {
    map = OrderedMap.from(map);
    if (!map.size)
      return this;
    return new OrderedMap(this.subtract(map).content.concat(map.content));
  },
  subtract: function(map) {
    var result = this;
    map = OrderedMap.from(map);
    for (var i = 0;i < map.content.length; i += 2)
      result = result.remove(map.content[i]);
    return result;
  },
  toObject: function() {
    var result = {};
    this.forEach(function(key, value) {
      result[key] = value;
    });
    return result;
  },
  get size() {
    return this.content.length >> 1;
  }
};
OrderedMap.from = function(value) {
  if (value instanceof OrderedMap)
    return value;
  var content = [];
  if (value)
    for (var prop in value)
      content.push(prop, value[prop]);
  return new OrderedMap(content);
};
var dist_default = OrderedMap;

// node_modules/.bun/prosemirror-model@1.25.13/node_modules/prosemirror-model/dist/index.js
function findDiffStart(a, b, pos) {
  for (let i = 0;; i++) {
    if (i == a.childCount || i == b.childCount)
      return a.childCount == b.childCount ? null : pos;
    let childA = a.child(i), childB = b.child(i);
    if (childA == childB) {
      pos += childA.nodeSize;
      continue;
    }
    if (!childA.sameMarkup(childB))
      return pos;
    if (childA.isText && childA.text != childB.text) {
      let tA = childA.text, tB = childB.text, j = 0;
      for (;tA[j] == tB[j]; j++)
        pos++;
      if (j && j < tA.length && j < tB.length && surrogateHigh(tA.charCodeAt(j - 1)) && surrogateLow(tA.charCodeAt(j)))
        pos--;
      return pos;
    }
    if (childA.content.size || childB.content.size) {
      let inner = findDiffStart(childA.content, childB.content, pos + 1);
      if (inner != null)
        return inner;
    }
    pos += childA.nodeSize;
  }
}
function findDiffEnd(a, b, posA, posB) {
  for (let iA = a.childCount, iB = b.childCount;; ) {
    if (iA == 0 || iB == 0)
      return iA == iB ? null : { a: posA, b: posB };
    let childA = a.child(--iA), childB = b.child(--iB), size = childA.nodeSize;
    if (childA == childB) {
      posA -= size;
      posB -= size;
      continue;
    }
    if (!childA.sameMarkup(childB))
      return { a: posA, b: posB };
    if (childA.isText && childA.text != childB.text) {
      let tA = childA.text, tB = childB.text, iA = tA.length, iB = tB.length;
      while (iA > 0 && iB > 0 && tA[iA - 1] == tB[iB - 1]) {
        iA--;
        iB--;
        posA--;
        posB--;
      }
      if (iA && iB && iA < tA.length && surrogateHigh(tA.charCodeAt(iA - 1)) && surrogateLow(tA.charCodeAt(iA))) {
        posA++;
        posB++;
      }
      return { a: posA, b: posB };
    }
    if (childA.content.size || childB.content.size) {
      let inner = findDiffEnd(childA.content, childB.content, posA - 1, posB - 1);
      if (inner)
        return inner;
    }
    posA -= size;
    posB -= size;
  }
}
function surrogateLow(ch) {
  return ch >= 56320 && ch < 57344;
}
function surrogateHigh(ch) {
  return ch >= 55296 && ch < 56320;
}

class Fragment {
  constructor(content, size) {
    this.content = content;
    this.size = size || 0;
    if (size == null)
      for (let i = 0;i < content.length; i++)
        this.size += content[i].nodeSize;
  }
  nodesBetween(from, to, f, nodeStart = 0, parent) {
    for (let i = 0, pos = 0;pos < to; i++) {
      let child = this.content[i], end = pos + child.nodeSize;
      if (end > from && f(child, nodeStart + pos, parent || null, i) !== false && child.content.size) {
        let start = pos + 1;
        child.nodesBetween(Math.max(0, from - start), Math.min(child.content.size, to - start), f, nodeStart + start);
      }
      pos = end;
    }
  }
  descendants(f) {
    this.nodesBetween(0, this.size, f);
  }
  textBetween(from, to, blockSeparator, leafText) {
    let text = "", first = true;
    this.nodesBetween(from, to, (node, pos) => {
      let nodeText = node.isText ? node.text.slice(Math.max(from, pos) - pos, to - pos) : !node.isLeaf ? "" : leafText ? typeof leafText === "function" ? leafText(node) : leafText : node.type.spec.leafText ? node.type.spec.leafText(node) : "";
      if (node.isBlock && (node.isLeaf && nodeText || node.isTextblock) && blockSeparator) {
        if (first)
          first = false;
        else
          text += blockSeparator;
      }
      text += nodeText;
    }, 0);
    return text;
  }
  append(other) {
    if (!other.size)
      return this;
    if (!this.size)
      return other;
    let last = this.lastChild, first = other.firstChild, content = this.content.slice(), i = 0;
    if (last.isText && last.sameMarkup(first)) {
      content[content.length - 1] = last.withText(last.text + first.text);
      i = 1;
    }
    for (;i < other.content.length; i++)
      content.push(other.content[i]);
    return new Fragment(content, this.size + other.size);
  }
  cut(from, to = this.size) {
    if (from == 0 && to == this.size)
      return this;
    let result = [], size = 0;
    if (to > from)
      for (let i = 0, pos = 0;pos < to; i++) {
        let child = this.content[i], end = pos + child.nodeSize;
        if (end > from) {
          if (pos < from || end > to) {
            if (child.isText)
              child = child.cut(Math.max(0, from - pos), Math.min(child.text.length, to - pos));
            else
              child = child.cut(Math.max(0, from - pos - 1), Math.min(child.content.size, to - pos - 1));
          }
          result.push(child);
          size += child.nodeSize;
        }
        pos = end;
      }
    return new Fragment(result, size);
  }
  cutByIndex(from, to) {
    if (from == to)
      return Fragment.empty;
    if (from == 0 && to == this.content.length)
      return this;
    return new Fragment(this.content.slice(from, to));
  }
  replaceChild(index, node) {
    let current = this.content[index];
    if (current == node)
      return this;
    let copy = this.content.slice();
    let size = this.size + node.nodeSize - current.nodeSize;
    copy[index] = node;
    return new Fragment(copy, size);
  }
  addToStart(node) {
    return new Fragment([node].concat(this.content), this.size + node.nodeSize);
  }
  addToEnd(node) {
    return new Fragment(this.content.concat(node), this.size + node.nodeSize);
  }
  eq(other) {
    if (this.content.length != other.content.length)
      return false;
    for (let i = 0;i < this.content.length; i++)
      if (!this.content[i].eq(other.content[i]))
        return false;
    return true;
  }
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  get childCount() {
    return this.content.length;
  }
  child(index) {
    let found = this.content[index];
    if (!found)
      throw new RangeError("Index " + index + " out of range for " + this);
    return found;
  }
  maybeChild(index) {
    return this.content[index] || null;
  }
  forEach(f) {
    for (let i = 0, p = 0;i < this.content.length; i++) {
      let child = this.content[i];
      f(child, p, i);
      p += child.nodeSize;
    }
  }
  findDiffStart(other, pos = 0) {
    return findDiffStart(this, other, pos);
  }
  findDiffEnd(other, pos = this.size, otherPos = other.size) {
    return findDiffEnd(this, other, pos, otherPos);
  }
  findIndex(pos) {
    if (pos == 0)
      return retIndex(0, pos);
    if (pos == this.size)
      return retIndex(this.content.length, pos);
    if (pos > this.size || pos < 0)
      throw new RangeError(`Position ${pos} outside of fragment (${this})`);
    for (let i = 0, curPos = 0;; i++) {
      let cur = this.child(i), end = curPos + cur.nodeSize;
      if (end >= pos) {
        if (end == pos)
          return retIndex(i + 1, end);
        return retIndex(i, curPos);
      }
      curPos = end;
    }
  }
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  toStringInner() {
    return this.content.join(", ");
  }
  toJSON() {
    return this.content.length ? this.content.map((n) => n.toJSON()) : null;
  }
  static fromJSON(schema, value) {
    if (!value)
      return Fragment.empty;
    if (!Array.isArray(value))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return Fragment.fromArray(value.map(schema.nodeFromJSON));
  }
  static fromArray(array) {
    if (!array.length)
      return Fragment.empty;
    let joined, size = 0;
    for (let i = 0;i < array.length; i++) {
      let node = array[i];
      size += node.nodeSize;
      if (i && node.isText && array[i - 1].sameMarkup(node)) {
        if (!joined)
          joined = array.slice(0, i);
        joined[joined.length - 1] = node.withText(joined[joined.length - 1].text + node.text);
      } else if (joined) {
        joined.push(node);
      }
    }
    return new Fragment(joined || array, size);
  }
  static from(nodes) {
    if (!nodes)
      return Fragment.empty;
    if (nodes instanceof Fragment)
      return nodes;
    if (Array.isArray(nodes))
      return this.fromArray(nodes);
    if (nodes.attrs)
      return new Fragment([nodes], nodes.nodeSize);
    throw new RangeError("Can not convert " + nodes + " to a Fragment" + (nodes.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
Fragment.empty = new Fragment([], 0);
var found = { index: 0, offset: 0 };
function retIndex(index, offset) {
  found.index = index;
  found.offset = offset;
  return found;
}
function compareDeep(a, b) {
  if (a === b)
    return true;
  if (!(a && typeof a == "object") || !(b && typeof b == "object"))
    return false;
  let array = Array.isArray(a);
  if (Array.isArray(b) != array)
    return false;
  if (array) {
    if (a.length != b.length)
      return false;
    for (let i = 0;i < a.length; i++)
      if (!compareDeep(a[i], b[i]))
        return false;
  } else {
    for (let p in a)
      if (!(p in b) || !compareDeep(a[p], b[p]))
        return false;
    for (let p in b)
      if (!(p in a))
        return false;
  }
  return true;
}

class Mark {
  constructor(type, attrs) {
    this.type = type;
    this.attrs = attrs;
  }
  addToSet(set) {
    let copy, placed = false;
    for (let i = 0;i < set.length; i++) {
      let other = set[i];
      if (this.eq(other))
        return set;
      if (this.type.excludes(other.type)) {
        if (!copy)
          copy = set.slice(0, i);
      } else if (other.type.excludes(this.type)) {
        return set;
      } else {
        if (!placed && other.type.rank > this.type.rank) {
          if (!copy)
            copy = set.slice(0, i);
          copy.push(this);
          placed = true;
        }
        if (copy)
          copy.push(other);
      }
    }
    if (!copy)
      copy = set.slice();
    if (!placed)
      copy.push(this);
    return copy;
  }
  removeFromSet(set) {
    for (let i = 0;i < set.length; i++)
      if (this.eq(set[i]))
        return set.slice(0, i).concat(set.slice(i + 1));
    return set;
  }
  isInSet(set) {
    for (let i = 0;i < set.length; i++)
      if (this.eq(set[i]))
        return true;
    return false;
  }
  eq(other) {
    return this == other || this.type == other.type && compareDeep(this.attrs, other.attrs);
  }
  toJSON() {
    let obj = { type: this.type.name };
    for (let _ in this.attrs) {
      obj.attrs = this.attrs;
      break;
    }
    return obj;
  }
  static fromJSON(schema, json) {
    if (!json)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let type = schema.marks[json.type];
    if (!type)
      throw new RangeError(`There is no mark type ${json.type} in this schema`);
    let mark = type.create(json.attrs);
    return mark;
  }
  static sameSet(a, b) {
    if (a == b)
      return true;
    if (a.length != b.length)
      return false;
    for (let i = 0;i < a.length; i++)
      if (!a[i].eq(b[i]))
        return false;
    return true;
  }
  static setFrom(marks) {
    if (!marks || Array.isArray(marks) && marks.length == 0)
      return Mark.none;
    if (marks instanceof Mark)
      return [marks];
    let copy = marks.slice();
    copy.sort((a, b) => a.type.rank - b.type.rank);
    return copy;
  }
}
Mark.none = [];

class ReplaceError extends Error {
}

class Slice {
  constructor(content, openStart, openEnd) {
    this.content = content;
    this.openStart = openStart;
    this.openEnd = openEnd;
  }
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  insertAt(pos, fragment) {
    let content = insertInto(this.content, pos + this.openStart, fragment, this.openStart + 1, this.openEnd + 1);
    return content && new Slice(content, this.openStart, this.openEnd);
  }
  removeBetween(from, to) {
    return new Slice(removeRange(this.content, from + this.openStart, to + this.openStart), this.openStart, this.openEnd);
  }
  eq(other) {
    return this.content.eq(other.content) && this.openStart == other.openStart && this.openEnd == other.openEnd;
  }
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  toJSON() {
    if (!this.content.size)
      return null;
    let json = { content: this.content.toJSON() };
    if (this.openStart > 0)
      json.openStart = this.openStart;
    if (this.openEnd > 0)
      json.openEnd = this.openEnd;
    return json;
  }
  static fromJSON(schema, json) {
    if (!json)
      return Slice.empty;
    let openStart = json.openStart || 0, openEnd = json.openEnd || 0;
    if (typeof openStart != "number" || typeof openEnd != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new Slice(Fragment.fromJSON(schema, json.content), openStart, openEnd);
  }
  static maxOpen(fragment, openIsolating = true) {
    let openStart = 0, openEnd = 0;
    for (let n = fragment.firstChild;n && !n.isLeaf && (openIsolating || !n.type.spec.isolating); n = n.firstChild)
      openStart++;
    for (let n = fragment.lastChild;n && !n.isLeaf && (openIsolating || !n.type.spec.isolating); n = n.lastChild)
      openEnd++;
    return new Slice(fragment, openStart, openEnd);
  }
}
Slice.empty = new Slice(Fragment.empty, 0, 0);
function removeRange(content, from, to) {
  let { index, offset } = content.findIndex(from), child = content.maybeChild(index);
  let { index: indexTo, offset: offsetTo } = content.findIndex(to);
  if (offset == from || child.isText) {
    if (offsetTo != to && !content.child(indexTo).isText)
      throw new RangeError("Removing non-flat range");
    return content.cut(0, from).append(content.cut(to));
  }
  if (index != indexTo)
    throw new RangeError("Removing non-flat range");
  return content.replaceChild(index, child.copy(removeRange(child.content, from - offset - 1, to - offset - 1)));
}
function insertInto(content, dist, insert, openStart, openEnd, parent) {
  let { index, offset } = content.findIndex(dist), child = content.maybeChild(index);
  if (offset == dist || child.isText) {
    if (parent && openStart <= 0 && openEnd <= 0 && !parent.canReplace(index, index, insert))
      return null;
    return content.cut(0, dist).append(insert).append(content.cut(dist));
  }
  let inner = insertInto(child.content, dist - offset - 1, insert, index == 0 ? openStart - 1 : 0, index == content.childCount - 1 ? openEnd - 1 : 0, child);
  return inner && content.replaceChild(index, child.copy(inner));
}
function replace($from, $to, slice) {
  if (slice.openStart > $from.depth)
    throw new ReplaceError("Inserted content deeper than insertion position");
  if ($from.depth - slice.openStart != $to.depth - slice.openEnd)
    throw new ReplaceError("Inconsistent open depths");
  return replaceOuter($from, $to, slice, 0);
}
function replaceOuter($from, $to, slice, depth) {
  let index = $from.index(depth), node = $from.node(depth);
  if (index == $to.index(depth) && depth < $from.depth - slice.openStart) {
    let inner = replaceOuter($from, $to, slice, depth + 1);
    return node.copy(node.content.replaceChild(index, inner));
  } else if (!slice.content.size) {
    return close(node, replaceTwoWay($from, $to, depth));
  } else if (!slice.openStart && !slice.openEnd && $from.depth == depth && $to.depth == depth) {
    let parent = $from.parent, content = parent.content;
    return close(parent, content.cut(0, $from.parentOffset).append(slice.content).append(content.cut($to.parentOffset)));
  } else {
    let { start, end } = prepareSliceForReplace(slice, $from);
    return close(node, replaceThreeWay($from, start, end, $to, depth));
  }
}
function checkJoin(main, sub) {
  if (!sub.type.compatibleContent(main.type))
    throw new ReplaceError("Cannot join " + sub.type.name + " onto " + main.type.name);
}
function joinable($before, $after, depth) {
  let node = $before.node(depth);
  checkJoin(node, $after.node(depth));
  return node;
}
function addNode(child, target) {
  let last = target.length - 1;
  if (last >= 0 && child.isText && child.sameMarkup(target[last]))
    target[last] = child.withText(target[last].text + child.text);
  else
    target.push(child);
}
function addRange($start, $end, depth, target) {
  let node = ($end || $start).node(depth);
  let startIndex = 0, endIndex = $end ? $end.index(depth) : node.childCount;
  if ($start) {
    startIndex = $start.index(depth);
    if ($start.depth > depth) {
      startIndex++;
    } else if ($start.textOffset) {
      addNode($start.nodeAfter, target);
      startIndex++;
    }
  }
  for (let i = startIndex;i < endIndex; i++)
    addNode(node.child(i), target);
  if ($end && $end.depth == depth && $end.textOffset)
    addNode($end.nodeBefore, target);
}
function close(node, content) {
  if (!node.type.validContent(content))
    throw new ReplaceError("Invalid content for node " + node.type.name);
  return node.copy(content);
}
function replaceThreeWay($from, $start, $end, $to, depth) {
  let openStart = $from.depth > depth && joinable($from, $start, depth + 1);
  let openEnd = $to.depth > depth && joinable($end, $to, depth + 1);
  let content = [];
  addRange(null, $from, depth, content);
  if (openStart && openEnd && $start.index(depth) == $end.index(depth)) {
    checkJoin(openStart, openEnd);
    addNode(close(openStart, replaceThreeWay($from, $start, $end, $to, depth + 1)), content);
  } else {
    if (openStart)
      addNode(close(openStart, replaceTwoWay($from, $start, depth + 1)), content);
    addRange($start, $end, depth, content);
    if (openEnd)
      addNode(close(openEnd, replaceTwoWay($end, $to, depth + 1)), content);
  }
  addRange($to, null, depth, content);
  return new Fragment(content);
}
function replaceTwoWay($from, $to, depth) {
  let content = [];
  addRange(null, $from, depth, content);
  if ($from.depth > depth) {
    let type = joinable($from, $to, depth + 1);
    addNode(close(type, replaceTwoWay($from, $to, depth + 1)), content);
  }
  addRange($to, null, depth, content);
  return new Fragment(content);
}
function prepareSliceForReplace(slice, $along) {
  let extra = $along.depth - slice.openStart, parent = $along.node(extra);
  let node = parent.copy(slice.content);
  for (let i = extra - 1;i >= 0; i--)
    node = $along.node(i).copy(Fragment.from(node));
  return {
    start: node.resolveNoCache(slice.openStart + extra),
    end: node.resolveNoCache(node.content.size - slice.openEnd - extra)
  };
}

class ResolvedPos {
  constructor(pos, path, parentOffset) {
    this.pos = pos;
    this.path = path;
    this.parentOffset = parentOffset;
    this.depth = path.length / 3 - 1;
  }
  resolveDepth(val) {
    if (val == null)
      return this.depth;
    if (val < 0)
      return this.depth + val;
    return val;
  }
  get parent() {
    return this.node(this.depth);
  }
  get doc() {
    return this.node(0);
  }
  node(depth) {
    return this.path[this.resolveDepth(depth) * 3];
  }
  index(depth) {
    return this.path[this.resolveDepth(depth) * 3 + 1];
  }
  indexAfter(depth) {
    depth = this.resolveDepth(depth);
    return this.index(depth) + (depth == this.depth && !this.textOffset ? 0 : 1);
  }
  start(depth) {
    depth = this.resolveDepth(depth);
    return depth == 0 ? 0 : this.path[depth * 3 - 1] + 1;
  }
  end(depth) {
    depth = this.resolveDepth(depth);
    return this.start(depth) + this.node(depth).content.size;
  }
  before(depth) {
    depth = this.resolveDepth(depth);
    if (!depth)
      throw new RangeError("There is no position before the top-level node");
    return depth == this.depth + 1 ? this.pos : this.path[depth * 3 - 1];
  }
  after(depth) {
    depth = this.resolveDepth(depth);
    if (!depth)
      throw new RangeError("There is no position after the top-level node");
    return depth == this.depth + 1 ? this.pos : this.path[depth * 3 - 1] + this.path[depth * 3].nodeSize;
  }
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  get nodeAfter() {
    let parent = this.parent, index = this.index(this.depth);
    if (index == parent.childCount)
      return null;
    let dOff = this.pos - this.path[this.path.length - 1], child = parent.child(index);
    return dOff ? parent.child(index).cut(dOff) : child;
  }
  get nodeBefore() {
    let index = this.index(this.depth);
    let dOff = this.pos - this.path[this.path.length - 1];
    if (dOff)
      return this.parent.child(index).cut(0, dOff);
    return index == 0 ? null : this.parent.child(index - 1);
  }
  posAtIndex(index, depth) {
    depth = this.resolveDepth(depth);
    let node = this.path[depth * 3], pos = depth == 0 ? 0 : this.path[depth * 3 - 1] + 1;
    for (let i = 0;i < index; i++)
      pos += node.child(i).nodeSize;
    return pos;
  }
  marks() {
    let parent = this.parent, index = this.index();
    if (parent.content.size == 0)
      return Mark.none;
    if (this.textOffset)
      return parent.child(index).marks;
    let main = parent.maybeChild(index - 1), other = parent.maybeChild(index);
    if (!main) {
      let tmp = main;
      main = other;
      other = tmp;
    }
    let marks = main.marks;
    for (var i = 0;i < marks.length; i++)
      if (marks[i].type.spec.inclusive === false && (!other || !marks[i].isInSet(other.marks)))
        marks = marks[i--].removeFromSet(marks);
    return marks;
  }
  marksAcross($end) {
    let after = this.parent.maybeChild(this.index());
    if (!after || !after.isInline)
      return null;
    let marks = after.marks, next = $end.parent.maybeChild($end.index());
    for (var i = 0;i < marks.length; i++)
      if (marks[i].type.spec.inclusive === false && (!next || !marks[i].isInSet(next.marks)))
        marks = marks[i--].removeFromSet(marks);
    return marks;
  }
  sharedDepth(pos) {
    for (let depth = this.depth;depth > 0; depth--)
      if (this.start(depth) <= pos && this.end(depth) >= pos)
        return depth;
    return 0;
  }
  blockRange(other = this, pred) {
    if (other.pos < this.pos)
      return other.blockRange(this);
    for (let d = this.depth - (this.parent.inlineContent || this.pos == other.pos ? 1 : 0);d >= 0; d--)
      if (other.pos <= this.end(d) && (!pred || pred(this.node(d))))
        return new NodeRange(this, other, d);
    return null;
  }
  sameParent(other) {
    return this.pos - this.parentOffset == other.pos - other.parentOffset;
  }
  max(other) {
    return other.pos > this.pos ? other : this;
  }
  min(other) {
    return other.pos < this.pos ? other : this;
  }
  toString() {
    let str = "";
    for (let i = 1;i <= this.depth; i++)
      str += (str ? "/" : "") + this.node(i).type.name + "_" + this.index(i - 1);
    return str + ":" + this.parentOffset;
  }
  static resolve(doc, pos) {
    if (!(pos >= 0 && pos <= doc.content.size))
      throw new RangeError("Position " + pos + " out of range");
    let path = [];
    let start = 0, parentOffset = pos;
    for (let node = doc;; ) {
      let { index, offset } = node.content.findIndex(parentOffset);
      let rem = parentOffset - offset;
      path.push(node, index, start + offset);
      if (!rem)
        break;
      node = node.child(index);
      if (node.isText)
        break;
      parentOffset = rem - 1;
      start += offset + 1;
    }
    return new ResolvedPos(pos, path, parentOffset);
  }
  static resolveCached(doc, pos) {
    let cache = resolveCache.get(doc);
    if (cache) {
      for (let i = 0;i < cache.elts.length; i++) {
        let elt = cache.elts[i];
        if (elt.pos == pos)
          return elt;
      }
    } else {
      resolveCache.set(doc, cache = new ResolveCache);
    }
    let result = cache.elts[cache.i] = ResolvedPos.resolve(doc, pos);
    cache.i = (cache.i + 1) % resolveCacheSize;
    return result;
  }
}

class ResolveCache {
  constructor() {
    this.elts = [];
    this.i = 0;
  }
}
var resolveCacheSize = 12;
var resolveCache = new WeakMap;

class NodeRange {
  constructor($from, $to, depth) {
    this.$from = $from;
    this.$to = $to;
    this.depth = depth;
  }
  get start() {
    return this.$from.before(this.depth + 1);
  }
  get end() {
    return this.$to.after(this.depth + 1);
  }
  get parent() {
    return this.$from.node(this.depth);
  }
  get startIndex() {
    return this.$from.index(this.depth);
  }
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
var emptyAttrs = Object.create(null);

class Node {
  constructor(type, attrs, content, marks = Mark.none) {
    this.type = type;
    this.attrs = attrs;
    this.marks = marks;
    this.content = content || Fragment.empty;
  }
  get children() {
    return this.content.content;
  }
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  get childCount() {
    return this.content.childCount;
  }
  child(index) {
    return this.content.child(index);
  }
  maybeChild(index) {
    return this.content.maybeChild(index);
  }
  forEach(f) {
    this.content.forEach(f);
  }
  nodesBetween(from, to, f, startPos = 0) {
    this.content.nodesBetween(from, to, f, startPos, this);
  }
  descendants(f) {
    this.nodesBetween(0, this.content.size, f);
  }
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  textBetween(from, to, blockSeparator, leafText) {
    return this.content.textBetween(from, to, blockSeparator, leafText);
  }
  get firstChild() {
    return this.content.firstChild;
  }
  get lastChild() {
    return this.content.lastChild;
  }
  eq(other) {
    return this == other || this.sameMarkup(other) && this.content.eq(other.content);
  }
  sameMarkup(other) {
    return this.hasMarkup(other.type, other.attrs, other.marks);
  }
  hasMarkup(type, attrs, marks) {
    return this.type == type && compareDeep(this.attrs, attrs || type.defaultAttrs || emptyAttrs) && Mark.sameSet(this.marks, marks || Mark.none);
  }
  copy(content = null) {
    if (content == this.content)
      return this;
    return new Node(this.type, this.attrs, content, this.marks);
  }
  mark(marks) {
    return marks == this.marks ? this : new Node(this.type, this.attrs, this.content, marks);
  }
  cut(from, to = this.content.size) {
    if (from == 0 && to == this.content.size)
      return this;
    return this.copy(this.content.cut(from, to));
  }
  slice(from, to = this.content.size, includeParents = false) {
    if (from == to)
      return Slice.empty;
    let $from = this.resolve(from), $to = this.resolve(to);
    let depth = includeParents ? 0 : $from.sharedDepth(to);
    let start = $from.start(depth), node = $from.node(depth);
    let content = node.content.cut($from.pos - start, $to.pos - start);
    return new Slice(content, $from.depth - depth, $to.depth - depth);
  }
  replace(from, to, slice) {
    return replace(this.resolve(from), this.resolve(to), slice);
  }
  nodeAt(pos) {
    for (let node = this;; ) {
      let { index, offset } = node.content.findIndex(pos);
      node = node.maybeChild(index);
      if (!node)
        return null;
      if (offset == pos || node.isText)
        return node;
      pos -= offset + 1;
    }
  }
  childAfter(pos) {
    let { index, offset } = this.content.findIndex(pos);
    return { node: this.content.maybeChild(index), index, offset };
  }
  childBefore(pos) {
    if (pos == 0)
      return { node: null, index: 0, offset: 0 };
    let { index, offset } = this.content.findIndex(pos);
    if (offset < pos)
      return { node: this.content.child(index), index, offset };
    let node = this.content.child(index - 1);
    return { node, index: index - 1, offset: offset - node.nodeSize };
  }
  resolve(pos) {
    return ResolvedPos.resolveCached(this, pos);
  }
  resolveNoCache(pos) {
    return ResolvedPos.resolve(this, pos);
  }
  rangeHasMark(from, to, type) {
    let found = false;
    if (to > from)
      this.nodesBetween(from, to, (node) => {
        if (type.isInSet(node.marks))
          found = true;
        return !found;
      });
    return found;
  }
  get isBlock() {
    return this.type.isBlock;
  }
  get isTextblock() {
    return this.type.isTextblock;
  }
  get inlineContent() {
    return this.type.inlineContent;
  }
  get isInline() {
    return this.type.isInline;
  }
  get isText() {
    return this.type.isText;
  }
  get isLeaf() {
    return this.type.isLeaf;
  }
  get isAtom() {
    return this.type.isAtom;
  }
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let name = this.type.name;
    if (this.content.size)
      name += "(" + this.content.toStringInner() + ")";
    return wrapMarks(this.marks, name);
  }
  contentMatchAt(index) {
    let match = this.type.contentMatch.matchFragment(this.content, 0, index);
    if (!match)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return match;
  }
  canReplace(from, to, replacement = Fragment.empty, start = 0, end = replacement.childCount) {
    let one = this.contentMatchAt(from).matchFragment(replacement, start, end);
    let two = one && one.matchFragment(this.content, to);
    if (!two || !two.validEnd)
      return false;
    for (let i = start;i < end; i++)
      if (!this.type.allowsMarks(replacement.child(i).marks))
        return false;
    return true;
  }
  canReplaceWith(from, to, type, marks) {
    if (marks && !this.type.allowsMarks(marks))
      return false;
    let start = this.contentMatchAt(from).matchType(type);
    let end = start && start.matchFragment(this.content, to);
    return end ? end.validEnd : false;
  }
  canAppend(other) {
    if (other.content.size)
      return this.canReplace(this.childCount, this.childCount, other.content);
    else
      return this.type.compatibleContent(other.type);
  }
  check() {
    this.type.checkContent(this.content);
    checkAttrs(this.type.attrs, this.attrs, "node", this.type.name);
    let copy = Mark.none;
    for (let i = 0;i < this.marks.length; i++) {
      let mark = this.marks[i];
      checkAttrs(mark.type.attrs, mark.attrs, "mark", mark.type.name);
      copy = mark.addToSet(copy);
    }
    if (!Mark.sameSet(copy, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((m) => m.type.name)}`);
    this.content.forEach((node) => node.check());
  }
  toJSON() {
    let obj = { type: this.type.name };
    for (let _ in this.attrs) {
      obj.attrs = this.attrs;
      break;
    }
    if (this.content.size)
      obj.content = this.content.toJSON();
    if (this.marks.length)
      obj.marks = this.marks.map((n) => n.toJSON());
    return obj;
  }
  static fromJSON(schema, json) {
    if (!json)
      throw new RangeError("Invalid input for Node.fromJSON");
    let marks = undefined;
    if (json.marks) {
      if (!Array.isArray(json.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      marks = json.marks.map(schema.markFromJSON);
    }
    if (json.type == "text") {
      if (typeof json.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return schema.text(json.text, marks);
    }
    let content = Fragment.fromJSON(schema, json.content);
    let node = schema.nodeType(json.type).create(json.attrs, content, marks);
    return node;
  }
}
Node.prototype.text = undefined;
var v8InternHack = (() => {
  let { stack } = new Error("/");
  if (!stack || !/\n\s*at\s/.test(stack))
    return (s) => s;
  let obj = Object.create(null);
  return (s) => {
    obj[s];
    return s;
  };
})();

class TextNode extends Node {
  constructor(type, attrs, content, marks) {
    super(type, attrs, null, marks);
    if (!content)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = content;
  }
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    return wrapMarks(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(from, to) {
    return v8InternHack(this.text.slice(from, to));
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(marks) {
    return marks == this.marks ? this : new TextNode(this.type, this.attrs, this.text, marks);
  }
  withText(text) {
    if (text == this.text)
      return this;
    return new TextNode(this.type, this.attrs, text, this.marks);
  }
  cut(from = 0, to = this.text.length) {
    if (from == 0 && to == this.text.length)
      return this;
    return this.withText(v8InternHack(this.text.slice(from, to)));
  }
  eq(other) {
    return this.sameMarkup(other) && this.text == other.text;
  }
  toJSON() {
    let base = super.toJSON();
    base.text = this.text;
    return base;
  }
}
function wrapMarks(marks, str) {
  for (let i = marks.length - 1;i >= 0; i--)
    str = marks[i].type.name + "(" + str + ")";
  return str;
}
function checkAttrs(attrs, values, type, name) {
  for (let attr in values)
    if (!(attr in attrs))
      throw new RangeError(`Unsupported attribute ${attr} for ${type} of type ${name}`);
  for (let attr in attrs) {
    if (attrs[attr].validate)
      attrs[attr].validate(values[attr]);
  }
}

class ContentMatch {
  constructor(validEnd) {
    this.validEnd = validEnd;
    this.next = [];
    this.wrapCache = [];
  }
  static parse(string, nodeTypes) {
    let stream = new TokenStream(string, nodeTypes);
    if (stream.next == null)
      return ContentMatch.empty;
    let expr = parseExpr(stream);
    if (stream.next)
      stream.err("Unexpected trailing text");
    let match = dfa(nfa(expr));
    checkForDeadEnds(match, stream);
    return match;
  }
  matchType(type) {
    for (let i = 0;i < this.next.length; i++)
      if (this.next[i].type == type)
        return this.next[i].next;
    return null;
  }
  matchFragment(frag, start = 0, end = frag.childCount) {
    let cur = this;
    for (let i = start;cur && i < end; i++)
      cur = cur.matchType(frag.child(i).type);
    return cur;
  }
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  get defaultType() {
    for (let i = 0;i < this.next.length; i++) {
      let { type } = this.next[i];
      if (!(type.isText || type.hasRequiredAttrs()))
        return type;
    }
    return null;
  }
  compatible(other) {
    for (let i = 0;i < this.next.length; i++)
      for (let j = 0;j < other.next.length; j++)
        if (this.next[i].type == other.next[j].type)
          return true;
    return false;
  }
  fillBefore(after, toEnd = false, startIndex = 0) {
    let seen = [this];
    function search(match, types) {
      let finished = match.matchFragment(after, startIndex);
      if (finished && (!toEnd || finished.validEnd))
        return Fragment.from(types.map((tp) => tp.createAndFill()));
      for (let i = 0;i < match.next.length; i++) {
        let { type, next } = match.next[i];
        if (!(type.isText || type.hasRequiredAttrs()) && seen.indexOf(next) == -1) {
          seen.push(next);
          let found = search(next, types.concat(type));
          if (found)
            return found;
        }
      }
      return null;
    }
    return search(this, []);
  }
  findWrapping(target) {
    for (let i = 0;i < this.wrapCache.length; i += 2)
      if (this.wrapCache[i] == target)
        return this.wrapCache[i + 1];
    let computed = this.computeWrapping(target);
    this.wrapCache.push(target, computed);
    return computed;
  }
  computeWrapping(target) {
    let seen = Object.create(null), active = [{ match: this, type: null, via: null }];
    while (active.length) {
      let current = active.shift(), match = current.match;
      if (match.matchType(target)) {
        let result = [];
        for (let obj = current;obj.type; obj = obj.via)
          result.push(obj.type);
        return result.reverse();
      }
      for (let i = 0;i < match.next.length; i++) {
        let { type, next } = match.next[i];
        if (!type.isLeaf && !type.hasRequiredAttrs() && !(type.name in seen) && (!current.type || next.validEnd)) {
          active.push({ match: type.contentMatch, type, via: current });
          seen[type.name] = true;
        }
      }
    }
    return null;
  }
  get edgeCount() {
    return this.next.length;
  }
  edge(n) {
    if (n >= this.next.length)
      throw new RangeError(`There's no ${n}th edge in this content match`);
    return this.next[n];
  }
  toString() {
    let seen = [];
    function scan(m) {
      seen.push(m);
      for (let i = 0;i < m.next.length; i++)
        if (seen.indexOf(m.next[i].next) == -1)
          scan(m.next[i].next);
    }
    scan(this);
    return seen.map((m, i) => {
      let out = i + (m.validEnd ? "*" : " ") + " ";
      for (let i = 0;i < m.next.length; i++)
        out += (i ? ", " : "") + m.next[i].type.name + "->" + seen.indexOf(m.next[i].next);
      return out;
    }).join(`
`);
  }
}
ContentMatch.empty = new ContentMatch(true);

class TokenStream {
  constructor(string, nodeTypes) {
    this.string = string;
    this.nodeTypes = nodeTypes;
    this.inline = null;
    this.pos = 0;
    this.tokens = string.split(/\s*(?=\b|\W|$)/);
    if (this.tokens[this.tokens.length - 1] == "")
      this.tokens.pop();
    if (this.tokens[0] == "")
      this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(tok) {
    return this.next == tok && (this.pos++ || true);
  }
  err(str) {
    throw new SyntaxError(str + " (in content expression '" + this.string + "')");
  }
}
function parseExpr(stream) {
  let exprs = [];
  do {
    exprs.push(parseExprSeq(stream));
  } while (stream.eat("|"));
  return exprs.length == 1 ? exprs[0] : { type: "choice", exprs };
}
function parseExprSeq(stream) {
  let exprs = [];
  do {
    exprs.push(parseExprSubscript(stream));
  } while (stream.next && stream.next != ")" && stream.next != "|");
  return exprs.length == 1 ? exprs[0] : { type: "seq", exprs };
}
function parseExprSubscript(stream) {
  let expr = parseExprAtom(stream);
  for (;; ) {
    if (stream.eat("+"))
      expr = { type: "plus", expr };
    else if (stream.eat("*"))
      expr = { type: "star", expr };
    else if (stream.eat("?"))
      expr = { type: "opt", expr };
    else if (stream.eat("{"))
      expr = parseExprRange(stream, expr);
    else
      break;
  }
  return expr;
}
function parseNum(stream) {
  if (/\D/.test(stream.next))
    stream.err("Expected number, got '" + stream.next + "'");
  let result = Number(stream.next);
  stream.pos++;
  return result;
}
function parseExprRange(stream, expr) {
  let min = parseNum(stream), max = min;
  if (stream.eat(",")) {
    if (stream.next != "}")
      max = parseNum(stream);
    else
      max = -1;
  }
  if (!stream.eat("}"))
    stream.err("Unclosed braced range");
  return { type: "range", min, max, expr };
}
function resolveName(stream, name) {
  let types = stream.nodeTypes, type = types[name];
  if (type)
    return [type];
  let result = [];
  for (let typeName in types) {
    let type = types[typeName];
    if (type.isInGroup(name))
      result.push(type);
  }
  if (result.length == 0)
    stream.err("No node type or group '" + name + "' found");
  return result;
}
function parseExprAtom(stream) {
  if (stream.eat("(")) {
    let expr = parseExpr(stream);
    if (!stream.eat(")"))
      stream.err("Missing closing paren");
    return expr;
  } else if (!/\W/.test(stream.next)) {
    let exprs = resolveName(stream, stream.next).map((type) => {
      if (stream.inline == null)
        stream.inline = type.isInline;
      else if (stream.inline != type.isInline)
        stream.err("Mixing inline and block content");
      return { type: "name", value: type };
    });
    stream.pos++;
    return exprs.length == 1 ? exprs[0] : { type: "choice", exprs };
  } else {
    stream.err("Unexpected token '" + stream.next + "'");
  }
}
function nfa(expr) {
  let nfa = [[]];
  connect(compile(expr, 0), node());
  return nfa;
  function node() {
    return nfa.push([]) - 1;
  }
  function edge(from, to, term) {
    let edge = { term, to };
    nfa[from].push(edge);
    return edge;
  }
  function connect(edges, to) {
    edges.forEach((edge) => edge.to = to);
  }
  function compile(expr, from) {
    if (expr.type == "choice") {
      return expr.exprs.reduce((out, expr) => out.concat(compile(expr, from)), []);
    } else if (expr.type == "seq") {
      for (let i = 0;; i++) {
        let next = compile(expr.exprs[i], from);
        if (i == expr.exprs.length - 1)
          return next;
        connect(next, from = node());
      }
    } else if (expr.type == "star") {
      let loop = node();
      edge(from, loop);
      connect(compile(expr.expr, loop), loop);
      return [edge(loop)];
    } else if (expr.type == "plus") {
      let loop = node();
      connect(compile(expr.expr, from), loop);
      connect(compile(expr.expr, loop), loop);
      return [edge(loop)];
    } else if (expr.type == "opt") {
      return [edge(from)].concat(compile(expr.expr, from));
    } else if (expr.type == "range") {
      let cur = from;
      for (let i = 0;i < expr.min; i++) {
        let next = node();
        connect(compile(expr.expr, cur), next);
        cur = next;
      }
      if (expr.max == -1) {
        connect(compile(expr.expr, cur), cur);
      } else {
        for (let i = expr.min;i < expr.max; i++) {
          let next = node();
          edge(cur, next);
          connect(compile(expr.expr, cur), next);
          cur = next;
        }
      }
      return [edge(cur)];
    } else if (expr.type == "name") {
      return [edge(from, undefined, expr.value)];
    } else {
      throw new Error("Unknown expr type");
    }
  }
}
function cmp(a, b) {
  return b - a;
}
function nullFrom(nfa, node) {
  let result = [];
  scan(node);
  return result.sort(cmp);
  function scan(node) {
    let edges = nfa[node];
    if (edges.length == 1 && !edges[0].term)
      return scan(edges[0].to);
    result.push(node);
    for (let i = 0;i < edges.length; i++) {
      let { term, to } = edges[i];
      if (!term && result.indexOf(to) == -1)
        scan(to);
    }
  }
}
function dfa(nfa) {
  let labeled = Object.create(null);
  return explore(nullFrom(nfa, 0));
  function explore(states) {
    let out = [];
    states.forEach((node) => {
      nfa[node].forEach(({ term, to }) => {
        if (!term)
          return;
        let set;
        for (let i = 0;i < out.length; i++)
          if (out[i][0] == term)
            set = out[i][1];
        nullFrom(nfa, to).forEach((node) => {
          if (!set)
            out.push([term, set = []]);
          if (set.indexOf(node) == -1)
            set.push(node);
        });
      });
    });
    let state = labeled[states.join(",")] = new ContentMatch(states.indexOf(nfa.length - 1) > -1);
    for (let i = 0;i < out.length; i++) {
      let states = out[i][1].sort(cmp);
      state.next.push({ type: out[i][0], next: labeled[states.join(",")] || explore(states) });
    }
    return state;
  }
}
function checkForDeadEnds(match, stream) {
  for (let i = 0, work = [match];i < work.length; i++) {
    let state = work[i], dead = !state.validEnd, nodes = [];
    for (let j = 0;j < state.next.length; j++) {
      let { type, next } = state.next[j];
      nodes.push(type.name);
      if (dead && !(type.isText || type.hasRequiredAttrs()))
        dead = false;
      if (work.indexOf(next) == -1)
        work.push(next);
    }
    if (dead)
      stream.err("Only non-generatable nodes (" + nodes.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function defaultAttrs(attrs) {
  let defaults = Object.create(null);
  for (let attrName in attrs) {
    let attr = attrs[attrName];
    if (!attr.hasDefault)
      return null;
    defaults[attrName] = attr.default;
  }
  return defaults;
}
function computeAttrs(attrs, value) {
  let built = Object.create(null);
  for (let name in attrs) {
    let attr = attrs[name];
    let given = value && value[name];
    if (given === undefined) {
      if (attr.hasDefault)
        given = attr.default;
      else
        throw new RangeError("No value supplied for attribute " + name);
    } else if (attr.validate) {
      attr.validate(given);
    }
    built[name] = given;
  }
  return built;
}
function initAttrs(typeName, attrs) {
  let result = Object.create(null);
  if (attrs)
    for (let name in attrs)
      result[name] = new Attribute(typeName, name, attrs[name]);
  return result;
}

class NodeType {
  constructor(name, schema, spec) {
    this.name = name;
    this.schema = schema;
    this.spec = spec;
    this.markSet = null;
    this.groups = spec.group ? spec.group.split(" ") : [];
    this.attrs = initAttrs(name, spec.attrs);
    this.defaultAttrs = defaultAttrs(this.attrs);
    this.contentMatch = null;
    this.inlineContent = null;
    this.isBlock = !(spec.inline || name == "text");
    this.isText = name == "text";
  }
  get isInline() {
    return !this.isBlock;
  }
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  get isLeaf() {
    return this.contentMatch == ContentMatch.empty;
  }
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  isInGroup(group) {
    return this.groups.indexOf(group) > -1;
  }
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  hasRequiredAttrs() {
    for (let n in this.attrs)
      if (this.attrs[n].isRequired)
        return true;
    return false;
  }
  compatibleContent(other) {
    return this == other || this.contentMatch.compatible(other.contentMatch);
  }
  computeAttrs(attrs) {
    if (!attrs && this.defaultAttrs)
      return this.defaultAttrs;
    else
      return computeAttrs(this.attrs, attrs);
  }
  create(attrs = null, content, marks) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new Node(this, this.computeAttrs(attrs), Fragment.from(content), Mark.setFrom(marks));
  }
  createChecked(attrs = null, content, marks) {
    content = Fragment.from(content);
    this.checkContent(content);
    return new Node(this, this.computeAttrs(attrs), content, Mark.setFrom(marks));
  }
  createAndFill(attrs = null, content, marks) {
    attrs = this.computeAttrs(attrs);
    content = Fragment.from(content);
    if (content.size) {
      let before = this.contentMatch.fillBefore(content);
      if (!before)
        return null;
      content = before.append(content);
    }
    let matched = this.contentMatch.matchFragment(content);
    let after = matched && matched.fillBefore(Fragment.empty, true);
    if (!after)
      return null;
    return new Node(this, attrs, content.append(after), Mark.setFrom(marks));
  }
  validContent(content) {
    let result = this.contentMatch.matchFragment(content);
    if (!result || !result.validEnd)
      return false;
    for (let i = 0;i < content.childCount; i++)
      if (!this.allowsMarks(content.child(i).marks))
        return false;
    return true;
  }
  checkContent(content) {
    if (!this.validContent(content))
      throw new RangeError(`Invalid content for node ${this.name}: ${content.toString().slice(0, 50)}`);
  }
  checkAttrs(attrs) {}
  allowsMarkType(markType) {
    return this.markSet == null || this.markSet.indexOf(markType) > -1;
  }
  allowsMarks(marks) {
    if (this.markSet == null)
      return true;
    for (let i = 0;i < marks.length; i++)
      if (!this.allowsMarkType(marks[i].type))
        return false;
    return true;
  }
  allowedMarks(marks) {
    if (this.markSet == null)
      return marks;
    let copy;
    for (let i = 0;i < marks.length; i++) {
      if (!this.allowsMarkType(marks[i].type)) {
        if (!copy)
          copy = marks.slice(0, i);
      } else if (copy) {
        copy.push(marks[i]);
      }
    }
    return !copy ? marks : copy.length ? copy : Mark.none;
  }
  static compile(nodes, schema) {
    let result = Object.create(null);
    nodes.forEach((name, spec) => result[name] = new NodeType(name, schema, spec));
    let topType = schema.spec.topNode || "doc";
    if (!result[topType])
      throw new RangeError("Schema is missing its top node type ('" + topType + "')");
    if (!result.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let _ in result.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return result;
  }
}
function validateType(typeName, attrName, type) {
  let types = type.split("|");
  return (value) => {
    let name = value === null ? "null" : typeof value;
    if (types.indexOf(name) < 0)
      throw new RangeError(`Expected value of type ${types} for attribute ${attrName} on type ${typeName}, got ${name}`);
  };
}

class Attribute {
  constructor(typeName, attrName, options) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(options, "default");
    this.default = options.default;
    this.validate = typeof options.validate == "string" ? validateType(typeName, attrName, options.validate) : options.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}

class MarkType {
  constructor(name, rank, schema, spec) {
    this.name = name;
    this.rank = rank;
    this.schema = schema;
    this.spec = spec;
    this.attrs = initAttrs(name, spec.attrs);
    this.excluded = null;
    let defaults = defaultAttrs(this.attrs);
    this.instance = defaults ? new Mark(this, defaults) : null;
  }
  create(attrs = null) {
    if (!attrs && this.instance)
      return this.instance;
    return new Mark(this, computeAttrs(this.attrs, attrs));
  }
  static compile(marks, schema) {
    let result = Object.create(null), rank = 0;
    marks.forEach((name, spec) => result[name] = new MarkType(name, rank++, schema, spec));
    return result;
  }
  removeFromSet(set) {
    for (var i = 0;i < set.length; i++)
      if (set[i].type == this) {
        set = set.slice(0, i).concat(set.slice(i + 1));
        i--;
      }
    return set;
  }
  isInSet(set) {
    for (let i = 0;i < set.length; i++)
      if (set[i].type == this)
        return set[i];
  }
  excludes(other) {
    return this.excluded.indexOf(other) > -1;
  }
}

class Schema {
  constructor(spec) {
    this.linebreakReplacement = null;
    this.cached = Object.create(null);
    let instanceSpec = this.spec = {};
    for (let prop in spec)
      instanceSpec[prop] = spec[prop];
    instanceSpec.nodes = dist_default.from(spec.nodes), instanceSpec.marks = dist_default.from(spec.marks || {}), this.nodes = NodeType.compile(this.spec.nodes, this);
    this.marks = MarkType.compile(this.spec.marks, this);
    let contentExprCache = Object.create(null);
    for (let prop in this.nodes) {
      if (prop in this.marks)
        throw new RangeError(prop + " can not be both a node and a mark");
      let type = this.nodes[prop], contentExpr = type.spec.content || "", markExpr = type.spec.marks;
      type.contentMatch = contentExprCache[contentExpr] || (contentExprCache[contentExpr] = ContentMatch.parse(contentExpr, this.nodes));
      type.inlineContent = type.contentMatch.inlineContent;
      if (type.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!type.isInline || !type.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = type;
      }
      type.markSet = markExpr == "_" ? null : markExpr ? gatherMarks(this, markExpr.split(" ")) : markExpr == "" || !type.inlineContent ? [] : null;
    }
    for (let prop in this.marks) {
      let type = this.marks[prop], excl = type.spec.excludes;
      type.excluded = excl == null ? [type] : excl == "" ? [] : gatherMarks(this, excl.split(" "));
    }
    this.nodeFromJSON = (json) => Node.fromJSON(this, json);
    this.markFromJSON = (json) => Mark.fromJSON(this, json);
    this.topNodeType = this.nodes[this.spec.topNode || "doc"];
    this.cached.wrappings = Object.create(null);
  }
  node(type, attrs = null, content, marks) {
    if (typeof type == "string")
      type = this.nodeType(type);
    else if (!(type instanceof NodeType))
      throw new RangeError("Invalid node type: " + type);
    else if (type.schema != this)
      throw new RangeError("Node type from different schema used (" + type.name + ")");
    return type.createChecked(attrs, content, marks);
  }
  text(text, marks) {
    let type = this.nodes.text;
    return new TextNode(type, type.defaultAttrs, text, Mark.setFrom(marks));
  }
  mark(type, attrs) {
    if (typeof type == "string")
      type = this.marks[type];
    return type.create(attrs);
  }
  nodeType(name) {
    let found = this.nodes[name];
    if (!found)
      throw new RangeError("Unknown node type: " + name);
    return found;
  }
}
function gatherMarks(schema, marks) {
  let found = [];
  for (let i = 0;i < marks.length; i++) {
    let name = marks[i], mark = schema.marks[name], ok = mark;
    if (mark) {
      found.push(mark);
    } else {
      for (let prop in schema.marks) {
        let mark = schema.marks[prop];
        if (name == "_" || mark.spec.group && mark.spec.group.split(" ").indexOf(name) > -1)
          found.push(ok = mark);
      }
    }
    if (!ok)
      throw new SyntaxError("Unknown mark type: '" + marks[i] + "'");
  }
  return found;
}
var suspiciousAttributeCache = new WeakMap;

// packages/editor/src/schema.ts
var blockAttrs = {
  indent: { default: 0 },
  font: { default: "" },
  size: { default: 0 },
  lineHeight: { default: 0 },
  align: { default: "" }
};
var cellAttrs = { align: { default: "" } };
function alignFromDom(dom) {
  const style = typeof dom === "string" ? "" : dom.getAttribute("style") ?? "";
  return { align: /text-align:\s*(left|center|right)/.exec(style)?.[1] ?? "" };
}
function alignToDom(attrs) {
  return attrs.align ? { style: `text-align:${String(attrs.align)}` } : {};
}
var nodes = {
  doc: { content: "block*" },
  paragraph: {
    content: "inline*",
    group: "block",
    attrs: blockAttrs,
    parseDOM: [{ tag: "p" }],
    toDOM: (node) => ["p", attrsToStyle(node.attrs), 0]
  },
  heading: {
    content: "inline*",
    group: "block",
    defining: true,
    attrs: { level: { default: 1 }, ...blockAttrs },
    parseDOM: [1, 2, 3, 4, 5, 6].map((level) => ({ tag: `h${level}`, attrs: { level } })),
    toDOM: (node) => [`h${node.attrs.level}`, attrsToStyle(node.attrs), 0]
  },
  blockquote: {
    content: "block+",
    group: "block",
    defining: true,
    parseDOM: [{ tag: "blockquote" }],
    toDOM: () => ["blockquote", 0]
  },
  bullet_list: {
    content: "list_item+",
    group: "block",
    parseDOM: [{ tag: "ul" }],
    toDOM: () => ["ul", 0]
  },
  ordered_list: {
    content: "list_item+",
    group: "block",
    attrs: { order: { default: 1 } },
    parseDOM: [{ tag: "ol", getAttrs: (dom) => ({ order: Number(dom.getAttribute("start") ?? 1) }) }],
    toDOM: (node) => node.attrs.order === 1 ? ["ol", 0] : ["ol", { start: node.attrs.order }, 0]
  },
  list_item: {
    content: "paragraph block*",
    defining: true,
    parseDOM: [{ tag: "li" }],
    toDOM: () => ["li", 0]
  },
  code_block: {
    content: "text*",
    group: "block",
    marks: "",
    defining: true,
    attrs: { language: { default: "" } },
    parseDOM: [{ tag: "pre", preserveWhitespace: "full" }],
    toDOM: () => ["pre", ["code", 0]]
  },
  horizontal_rule: {
    group: "block",
    parseDOM: [{ tag: "hr" }],
    toDOM: () => ["hr"]
  },
  image: {
    inline: true,
    group: "inline",
    draggable: true,
    attrs: { src: {}, alt: { default: "" }, title: { default: "" }, width: { default: 0 } },
    parseDOM: [
      {
        tag: "img[src]",
        getAttrs: (dom) => {
          const el = dom;
          return { src: el.getAttribute("src"), alt: el.alt, title: el.title };
        }
      }
    ],
    toDOM: (node) => [
      "img",
      { src: node.attrs.src, alt: node.attrs.alt, title: node.attrs.title, style: node.attrs.width ? `width:${node.attrs.width}%` : "" }
    ]
  },
  table: { content: "table_row+", group: "block", parseDOM: [{ tag: "table" }], toDOM: () => ["table", ["tbody", 0]] },
  table_row: { content: "(table_cell | table_header)+", parseDOM: [{ tag: "tr" }], toDOM: () => ["tr", 0] },
  table_cell: {
    content: "block+",
    attrs: cellAttrs,
    parseDOM: [{ tag: "td", getAttrs: alignFromDom }],
    toDOM: (node) => ["td", alignToDom(node.attrs), 0]
  },
  table_header: {
    content: "block+",
    attrs: cellAttrs,
    parseDOM: [{ tag: "th", getAttrs: alignFromDom }],
    toDOM: (node) => ["th", alignToDom(node.attrs), 0]
  },
  raw: {
    group: "block",
    atom: true,
    attrs: { text: { default: "" } },
    toDOM: (node) => ["pre", { class: "raw-block" }, node.attrs.text]
  },
  hard_break: {
    inline: true,
    group: "inline",
    selectable: false,
    parseDOM: [{ tag: "br" }],
    toDOM: () => ["br"]
  },
  text: { group: "inline" }
};
var marks = {
  strong: { parseDOM: [{ tag: "strong" }, { tag: "b" }], toDOM: () => ["strong", 0] },
  em: { parseDOM: [{ tag: "em" }, { tag: "i" }], toDOM: () => ["em", 0] },
  code: { parseDOM: [{ tag: "code" }], toDOM: () => ["code", 0] },
  strike: { parseDOM: [{ tag: "s" }, { tag: "del" }], toDOM: () => ["s", 0] },
  link: {
    attrs: { href: {}, title: { default: null } },
    inclusive: false,
    parseDOM: [{ tag: "a[href]", getAttrs: (dom) => ({ href: dom.getAttribute("href"), title: dom.getAttribute("title") }) }],
    toDOM: (mark) => ["a", { href: mark.attrs.href, title: mark.attrs.title }, 0]
  }
};
function attrsToStyle(attrs) {
  const style = [];
  if (attrs.indent)
    style.push(`text-indent:${Number(attrs.indent)}em`);
  if (attrs.font)
    style.push(`font-family:var(--font-${String(attrs.font)})`);
  if (attrs.size)
    style.push(`font-size:${Number(attrs.size)}px`);
  if (attrs.lineHeight)
    style.push(`line-height:${Number(attrs.lineHeight)}`);
  if (attrs.align)
    style.push(`text-align:${String(attrs.align)}`);
  return style.length > 0 ? { style: style.join(";") } : {};
}
var schema2 = new Schema({ nodes, marks });
// node_modules/.bun/mdurl@2.1.0/node_modules/mdurl/index.mjs
var exports_mdurl = {};
__export(exports_mdurl, {
  decode: () => decode_default,
  encode: () => encode_default,
  format: () => format,
  parse: () => parse_default
});

// node_modules/.bun/mdurl@2.1.0/node_modules/mdurl/lib/decode.mjs
var decodeCache = {};
function getDecodeCache(exclude) {
  let cache = decodeCache[exclude];
  if (cache) {
    return cache;
  }
  cache = decodeCache[exclude] = [];
  for (let i = 0;i < 128; i++) {
    const ch = String.fromCharCode(i);
    cache.push(ch);
  }
  for (let i = 0;i < exclude.length; i++) {
    const ch = exclude.charCodeAt(i);
    cache[ch] = "%" + ("0" + ch.toString(16).toUpperCase()).slice(-2);
  }
  return cache;
}
function decode(string, exclude) {
  if (typeof exclude !== "string") {
    exclude = decode.defaultChars;
  }
  const cache = getDecodeCache(exclude);
  return string.replace(/(%[a-f0-9]{2})+/gi, function(seq) {
    let result = "";
    for (let i = 0, l = seq.length;i < l; i += 3) {
      const b1 = parseInt(seq.slice(i + 1, i + 3), 16);
      if (b1 < 128) {
        result += cache[b1];
        continue;
      }
      if ((b1 & 224) === 192 && i + 3 < l) {
        const b2 = parseInt(seq.slice(i + 4, i + 6), 16);
        if ((b2 & 192) === 128) {
          const chr = b1 << 6 & 1984 | b2 & 63;
          if (chr < 128) {
            result += "\uFFFD\uFFFD";
          } else {
            result += String.fromCharCode(chr);
          }
          i += 3;
          continue;
        }
      }
      if ((b1 & 240) === 224 && i + 6 < l) {
        const b2 = parseInt(seq.slice(i + 4, i + 6), 16);
        const b3 = parseInt(seq.slice(i + 7, i + 9), 16);
        if ((b2 & 192) === 128 && (b3 & 192) === 128) {
          const chr = b1 << 12 & 61440 | b2 << 6 & 4032 | b3 & 63;
          if (chr < 2048 || chr >= 55296 && chr <= 57343) {
            result += "\uFFFD\uFFFD\uFFFD";
          } else {
            result += String.fromCharCode(chr);
          }
          i += 6;
          continue;
        }
      }
      if ((b1 & 248) === 240 && i + 9 < l) {
        const b2 = parseInt(seq.slice(i + 4, i + 6), 16);
        const b3 = parseInt(seq.slice(i + 7, i + 9), 16);
        const b4 = parseInt(seq.slice(i + 10, i + 12), 16);
        if ((b2 & 192) === 128 && (b3 & 192) === 128 && (b4 & 192) === 128) {
          let chr = b1 << 18 & 1835008 | b2 << 12 & 258048 | b3 << 6 & 4032 | b4 & 63;
          if (chr < 65536 || chr > 1114111) {
            result += "\uFFFD\uFFFD\uFFFD\uFFFD";
          } else {
            chr -= 65536;
            result += String.fromCharCode(55296 + (chr >> 10), 56320 + (chr & 1023));
          }
          i += 9;
          continue;
        }
      }
      result += "\uFFFD";
    }
    return result;
  });
}
decode.defaultChars = ";/?:@&=+$,#";
decode.componentChars = "";
var decode_default = decode;

// node_modules/.bun/mdurl@2.1.0/node_modules/mdurl/lib/encode.mjs
var encodeCache = {};
function getEncodeCache(exclude) {
  let cache = encodeCache[exclude];
  if (cache) {
    return cache;
  }
  cache = encodeCache[exclude] = [];
  for (let i = 0;i < 128; i++) {
    const ch = String.fromCharCode(i);
    if (/^[0-9a-z]$/i.test(ch)) {
      cache.push(ch);
    } else {
      cache.push("%" + ("0" + i.toString(16).toUpperCase()).slice(-2));
    }
  }
  for (let i = 0;i < exclude.length; i++) {
    cache[exclude.charCodeAt(i)] = exclude[i];
  }
  return cache;
}
function encode(string, exclude, keepEscaped) {
  if (typeof exclude !== "string") {
    keepEscaped = exclude;
    exclude = encode.defaultChars;
  }
  if (typeof keepEscaped === "undefined") {
    keepEscaped = true;
  }
  const cache = getEncodeCache(exclude);
  let result = "";
  for (let i = 0, l = string.length;i < l; i++) {
    const code = string.charCodeAt(i);
    if (keepEscaped && code === 37 && i + 2 < l) {
      if (/^[0-9a-f]{2}$/i.test(string.slice(i + 1, i + 3))) {
        result += string.slice(i, i + 3);
        i += 2;
        continue;
      }
    }
    if (code < 128) {
      result += cache[code];
      continue;
    }
    if (code >= 55296 && code <= 57343) {
      if (code >= 55296 && code <= 56319 && i + 1 < l) {
        const nextCode = string.charCodeAt(i + 1);
        if (nextCode >= 56320 && nextCode <= 57343) {
          result += encodeURIComponent(string[i] + string[i + 1]);
          i++;
          continue;
        }
      }
      result += "%EF%BF%BD";
      continue;
    }
    result += encodeURIComponent(string[i]);
  }
  return result;
}
encode.defaultChars = ";/?:@&=+$,-_.!~*'()#";
encode.componentChars = "-_.!~*'()";
var encode_default = encode;

// node_modules/.bun/mdurl@2.1.0/node_modules/mdurl/lib/format.mjs
function format(url) {
  let result = "";
  result += url.protocol || "";
  result += url.slashes ? "//" : "";
  result += url.auth ? url.auth + "@" : "";
  if (url.hostname && url.hostname.indexOf(":") !== -1) {
    result += "[" + url.hostname + "]";
  } else {
    result += url.hostname || "";
  }
  result += url.port ? ":" + url.port : "";
  result += url.pathname || "";
  result += url.search || "";
  result += url.hash || "";
  return result;
}

// node_modules/.bun/mdurl@2.1.0/node_modules/mdurl/lib/parse.mjs
function Url() {
  this.protocol = null;
  this.slashes = null;
  this.auth = null;
  this.port = null;
  this.hostname = null;
  this.hash = null;
  this.search = null;
  this.pathname = null;
}
var protocolPattern = /^([a-z0-9.+-]+:)/i;
var portPattern = /:[0-9]*$/;
var simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/;
var delims = ["<", ">", '"', "`", " ", "\r", `
`, "\t"];
var unwise = ["{", "}", "|", "\\", "^", "`"].concat(delims);
var autoEscape = ["'"].concat(unwise);
var nonHostChars = ["%", "/", "?", ";", "#"].concat(autoEscape);
var hostEndingChars = ["/", "?", "#"];
var hostnameMaxLen = 255;
var hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/;
var hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/;
var hostlessProtocol = {
  javascript: true,
  "javascript:": true
};
var slashedProtocol = {
  http: true,
  https: true,
  ftp: true,
  gopher: true,
  file: true,
  "http:": true,
  "https:": true,
  "ftp:": true,
  "gopher:": true,
  "file:": true
};
function urlParse(url, slashesDenoteHost) {
  if (url && url instanceof Url)
    return url;
  const u = new Url;
  u.parse(url, slashesDenoteHost);
  return u;
}
Url.prototype.parse = function(url, slashesDenoteHost) {
  let lowerProto, hec, slashes;
  let rest = url;
  rest = rest.trim();
  if (!slashesDenoteHost && url.split("#").length === 1) {
    const simplePath = simplePathPattern.exec(rest);
    if (simplePath) {
      this.pathname = simplePath[1];
      if (simplePath[2]) {
        this.search = simplePath[2];
      }
      return this;
    }
  }
  let proto = protocolPattern.exec(rest);
  if (proto) {
    proto = proto[0];
    lowerProto = proto.toLowerCase();
    this.protocol = proto;
    rest = rest.substr(proto.length);
  }
  if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
    slashes = rest.substr(0, 2) === "//";
    if (slashes && !(proto && hostlessProtocol[proto])) {
      rest = rest.substr(2);
      this.slashes = true;
    }
  }
  if (!hostlessProtocol[proto] && (slashes || proto && !slashedProtocol[proto])) {
    let hostEnd = -1;
    for (let i = 0;i < hostEndingChars.length; i++) {
      hec = rest.indexOf(hostEndingChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) {
        hostEnd = hec;
      }
    }
    let auth, atSign;
    if (hostEnd === -1) {
      atSign = rest.lastIndexOf("@");
    } else {
      atSign = rest.lastIndexOf("@", hostEnd);
    }
    if (atSign !== -1) {
      auth = rest.slice(0, atSign);
      rest = rest.slice(atSign + 1);
      this.auth = auth;
    }
    hostEnd = -1;
    for (let i = 0;i < nonHostChars.length; i++) {
      hec = rest.indexOf(nonHostChars[i]);
      if (hec !== -1 && (hostEnd === -1 || hec < hostEnd)) {
        hostEnd = hec;
      }
    }
    if (hostEnd === -1) {
      hostEnd = rest.length;
    }
    if (rest[hostEnd - 1] === ":") {
      hostEnd--;
    }
    const host = rest.slice(0, hostEnd);
    rest = rest.slice(hostEnd);
    this.parseHost(host);
    this.hostname = this.hostname || "";
    const ipv6Hostname = this.hostname[0] === "[" && this.hostname[this.hostname.length - 1] === "]";
    if (!ipv6Hostname) {
      const hostparts = this.hostname.split(/\./);
      for (let i = 0, l = hostparts.length;i < l; i++) {
        const part = hostparts[i];
        if (!part) {
          continue;
        }
        if (!part.match(hostnamePartPattern)) {
          let newpart = "";
          for (let j = 0, k = part.length;j < k; j++) {
            if (part.charCodeAt(j) > 127) {
              newpart += "x";
            } else {
              newpart += part[j];
            }
          }
          if (!newpart.match(hostnamePartPattern)) {
            const validParts = hostparts.slice(0, i);
            const notHost = hostparts.slice(i + 1);
            const bit = part.match(hostnamePartStart);
            if (bit) {
              validParts.push(bit[1]);
              notHost.unshift(bit[2]);
            }
            if (notHost.length) {
              rest = notHost.join(".") + rest;
            }
            this.hostname = validParts.join(".");
            break;
          }
        }
      }
    }
    if (this.hostname.length > hostnameMaxLen) {
      this.hostname = "";
    }
    if (ipv6Hostname) {
      this.hostname = this.hostname.substr(1, this.hostname.length - 2);
    }
  }
  const hash = rest.indexOf("#");
  if (hash !== -1) {
    this.hash = rest.substr(hash);
    rest = rest.slice(0, hash);
  }
  const qm = rest.indexOf("?");
  if (qm !== -1) {
    this.search = rest.substr(qm);
    rest = rest.slice(0, qm);
  }
  if (rest) {
    this.pathname = rest;
  }
  if (slashedProtocol[lowerProto] && this.hostname && !this.pathname) {
    this.pathname = "";
  }
  return this;
};
Url.prototype.parseHost = function(host) {
  let port = portPattern.exec(host);
  if (port) {
    port = port[0];
    if (port !== ":") {
      this.port = port.substr(1);
    }
    host = host.substr(0, host.length - port.length);
  }
  if (host) {
    this.hostname = host;
  }
};
var parse_default = urlParse;

// node_modules/.bun/uc.micro@3.0.0/node_modules/uc.micro/build/index.mjs
var exports_build = {};
__export(exports_build, {
  Any: () => Any,
  Cc: () => Cc,
  Cf: () => Cf,
  P: () => P,
  S: () => S,
  Z: () => Z
});
var Any = /[\0-\uD7FF\uE000-\uFFFF]|[\uD800-\uDBFF][\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/;
var Cc = /[\0-\x1F\x7F-\x9F]/;
var Cf = /[\xAD\u0600-\u0605\u061C\u06DD\u070F\u0890\u0891\u08E2\u180E\u200B-\u200F\u202A-\u202E\u2060-\u2064\u2066-\u206F\uFEFF\uFFF9-\uFFFB]|\uD804[\uDCBD\uDCCD]|\uD80D[\uDC30-\uDC3F]|\uD82F[\uDCA0-\uDCA3]|\uD834[\uDD73-\uDD7A]|\uDB40[\uDC01\uDC20-\uDC7F]/;
var P = /[!-#%-\*,-\/:;\?@\[-\]_\{\}\xA1\xA7\xAB\xB6\xB7\xBB\xBF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061D-\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u09FD\u0A76\u0AF0\u0C77\u0C84\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B4E\u1B4F\u1B5A-\u1B60\u1B7D-\u1B7F\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E4F\u2E52-\u2E5D\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]|\uD800[\uDD00-\uDD02\uDF9F\uDFD0]|\uD801\uDD6F|\uD802[\uDC57\uDD1F\uDD3F\uDE50-\uDE58\uDE7F\uDEF0-\uDEF6\uDF39-\uDF3F\uDF99-\uDF9C]|\uD803[\uDD6E\uDEAD\uDED0\uDF55-\uDF59\uDF86-\uDF89]|\uD804[\uDC47-\uDC4D\uDCBB\uDCBC\uDCBE-\uDCC1\uDD40-\uDD43\uDD74\uDD75\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDDF\uDE38-\uDE3D\uDEA9\uDFD4\uDFD5\uDFD7\uDFD8]|\uD805[\uDC4B-\uDC4F\uDC5A\uDC5B\uDC5D\uDCC6\uDDC1-\uDDD7\uDE41-\uDE43\uDE60-\uDE6C\uDEB9\uDF3C-\uDF3E]|\uD806[\uDC3B\uDD44-\uDD46\uDDE2\uDE3F-\uDE46\uDE9A-\uDE9C\uDE9E-\uDEA2\uDF00-\uDF09\uDFE1]|\uD807[\uDC41-\uDC45\uDC70\uDC71\uDEF7\uDEF8\uDF43-\uDF4F\uDFFF]|\uD809[\uDC70-\uDC74]|\uD80B[\uDFF1\uDFF2]|\uD81A[\uDE6E\uDE6F\uDEF5\uDF37-\uDF3B\uDF44]|\uD81B[\uDD6D-\uDD6F\uDE97-\uDE9A\uDFE2]|\uD82F\uDC9F|\uD836[\uDE87-\uDE8B]|\uD839\uDDFF|\uD83A[\uDD5E\uDD5F]/;
var S = /[\$\+<->\^`\|~\xA2-\xA6\xA8\xA9\xAC\xAE-\xB1\xB4\xB8\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0384\u0385\u03F6\u0482\u058D-\u058F\u0606-\u0608\u060B\u060E\u060F\u06DE\u06E9\u06FD\u06FE\u07F6\u07FE\u07FF\u0888\u09F2\u09F3\u09FA\u09FB\u0AF1\u0B70\u0BF3-\u0BFA\u0C7F\u0D4F\u0D79\u0E3F\u0F01-\u0F03\u0F13\u0F15-\u0F17\u0F1A-\u0F1F\u0F34\u0F36\u0F38\u0FBE-\u0FC5\u0FC7-\u0FCC\u0FCE\u0FCF\u0FD5-\u0FD8\u109E\u109F\u1390-\u1399\u166D\u17DB\u1940\u19DE-\u19FF\u1B61-\u1B6A\u1B74-\u1B7C\u1FBD\u1FBF-\u1FC1\u1FCD-\u1FCF\u1FDD-\u1FDF\u1FED-\u1FEF\u1FFD\u1FFE\u2044\u2052\u207A-\u207C\u208A-\u208C\u20A0-\u20C1\u2100\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F\u218A\u218B\u2190-\u2307\u230C-\u2328\u232B-\u2429\u2440-\u244A\u249C-\u24E9\u2500-\u2767\u2794-\u27C4\u27C7-\u27E5\u27F0-\u2982\u2999-\u29D7\u29DC-\u29FB\u29FE-\u2B73\u2B76-\u2BFF\u2CE5-\u2CEA\u2E50\u2E51\u2E80-\u2E99\u2E9B-\u2EF3\u2F00-\u2FD5\u2FF0-\u2FFF\u3004\u3012\u3013\u3020\u3036\u3037\u303E\u303F\u309B\u309C\u3190\u3191\u3196-\u319F\u31C0-\u31E5\u31EF\u3200-\u321E\u322A-\u3247\u3250\u3260-\u327F\u328A-\u32B0\u32C0-\u33FF\u4DC0-\u4DFF\uA490-\uA4C6\uA700-\uA716\uA720\uA721\uA789\uA78A\uA828-\uA82B\uA836-\uA839\uAA77-\uAA79\uAB5B\uAB6A\uAB6B\uFB29\uFBB2-\uFBD2\uFD40-\uFD4F\uFD90\uFD91\uFDC8-\uFDCF\uFDFC-\uFDFF\uFE62\uFE64-\uFE66\uFE69\uFF04\uFF0B\uFF1C-\uFF1E\uFF3E\uFF40\uFF5C\uFF5E\uFFE0-\uFFE6\uFFE8-\uFFEE\uFFFC\uFFFD]|\uD800[\uDD37-\uDD3F\uDD79-\uDD89\uDD8C-\uDD8E\uDD90-\uDD9C\uDDA0\uDDD0-\uDDFC]|\uD802[\uDC77\uDC78\uDEC8]|\uD803[\uDD8E\uDD8F\uDED1-\uDED8]|\uD805\uDF3F|\uD807[\uDFD5-\uDFF1]|\uD81A[\uDF3C-\uDF3F\uDF45]|\uD82F\uDC9C|\uD833[\uDC00-\uDCEF\uDCFA-\uDCFC\uDD00-\uDEB3\uDEBA-\uDED0\uDEE0-\uDEF0\uDF50-\uDFC3]|\uD834[\uDC00-\uDCF5\uDD00-\uDD26\uDD29-\uDD64\uDD6A-\uDD6C\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDDEA\uDE00-\uDE41\uDE45\uDF00-\uDF56]|\uD835[\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85\uDE86]|\uD838[\uDD4F\uDEFF]|\uD83B[\uDCAC\uDCB0\uDD2E\uDEF0\uDEF1]|\uD83C[\uDC00-\uDC2B\uDC30-\uDC93\uDCA0-\uDCAE\uDCB1-\uDCBF\uDCC1-\uDCCF\uDCD1-\uDCF5\uDD0D-\uDDAD\uDDE6-\uDE02\uDE10-\uDE3B\uDE40-\uDE48\uDE50\uDE51\uDE60-\uDE65\uDF00-\uDFFF]|\uD83D[\uDC00-\uDED8\uDEDC-\uDEEC\uDEF0-\uDEFC\uDF00-\uDFD9\uDFE0-\uDFEB\uDFF0]|\uD83E[\uDC00-\uDC0B\uDC10-\uDC47\uDC50-\uDC59\uDC60-\uDC87\uDC90-\uDCAD\uDCB0-\uDCBB\uDCC0\uDCC1\uDCD0-\uDCD8\uDD00-\uDE57\uDE60-\uDE6D\uDE70-\uDE7C\uDE80-\uDE8A\uDE8E-\uDEC6\uDEC8\uDECD-\uDEDC\uDEDF-\uDEEA\uDEEF-\uDEF8\uDF00-\uDF92\uDF94-\uDFEF\uDFFA]/;
var Z = /[ \xA0\u1680\u2000-\u200A\u2028\u2029\u202F\u205F\u3000]/;

// node_modules/.bun/entities@8.1.0/node_modules/entities/dist/decode-codepoint.js
var c1 = [
  8364,
  0,
  8218,
  402,
  8222,
  8230,
  8224,
  8225,
  710,
  8240,
  352,
  8249,
  338,
  0,
  381,
  0,
  0,
  8216,
  8217,
  8220,
  8221,
  8226,
  8211,
  8212,
  732,
  8482,
  353,
  8250,
  339,
  0,
  382,
  376
];
function isInvalidCodePoint(codePoint) {
  return codePoint === 0 || codePoint >= 55296 && codePoint <= 57343 || codePoint > 1114111;
}
function replaceCodePoint(codePoint) {
  if (isInvalidCodePoint(codePoint)) {
    return 65533;
  }
  if (codePoint >= 128 && codePoint <= 159) {
    return c1[codePoint - 128] || codePoint;
  }
  return codePoint;
}
function codePointToString(codePoint) {
  return codePoint - 1 >>> 0 < 127 || codePoint - 160 >>> 0 < 55136 ? String.fromCharCode(codePoint) : String.fromCodePoint(replaceCodePoint(codePoint));
}

// node_modules/.bun/entities@8.1.0/node_modules/entities/dist/internal/decode-shared.js
var BASE91_INVERSE = /* @__PURE__ */ (() => {
  const table = new Uint8Array(127);
  let code = 0;
  for (let char = 33;char <= 126; char++) {
    if (char !== 34 && char !== 36 && char !== 92) {
      table[char] = code++;
    }
  }
  return table;
})();
function decodeTrieDict(input, resultLength, atomCount, dict1AtomCount, ngramCount, dictSize) {
  const base = 91;
  const inputLength = input.length;
  const twoCharBias = dictSize * (base - 1);
  let pos = 0;
  const readSlotCode = () => {
    const c1 = BASE91_INVERSE[input.charCodeAt(pos++)];
    return c1 < dictSize ? c1 : c1 * base - twoCharBias + BASE91_INVERSE[input.charCodeAt(pos++)];
  };
  const dict2AtomCount = atomCount - dict1AtomCount;
  const slotCount = atomCount + ngramCount;
  const single = new Int32Array(slotCount);
  single.fill(-1, dict1AtomCount, dictSize);
  single.fill(-1, dictSize + dict2AtomCount, slotCount);
  const start = new Int32Array(slotCount);
  const length = new Int32Array(slotCount);
  function decodeDelta(count, off) {
    let previous = 0;
    let slot = off;
    const end = off + count;
    while (slot < end) {
      const code = BASE91_INVERSE[input.charCodeAt(pos++)];
      if (code < 89) {
        previous += code;
        single[slot++] = previous;
      } else if (code === 89) {
        let runLength = BASE91_INVERSE[input.charCodeAt(pos++)] + 2;
        while (runLength--)
          single[slot++] = ++previous;
      } else {
        const next = BASE91_INVERSE[input.charCodeAt(pos++)];
        previous += 89 + (next < 90 ? next * base + BASE91_INVERSE[input.charCodeAt(pos++)] : BASE91_INVERSE[input.charCodeAt(pos++)] * 8281 + BASE91_INVERSE[input.charCodeAt(pos++)] * base + BASE91_INVERSE[input.charCodeAt(pos++)]);
        single[slot++] = previous;
      }
    }
  }
  decodeDelta(dict1AtomCount, 0);
  decodeDelta(dict2AtomCount, dictSize);
  const references = new Int32Array(ngramCount * 2);
  let poolSize = 0;
  let ngramIndex = 0;
  function readNgramReferences(count, startSlot) {
    for (let index = 0;index < count; index++) {
      const slot = startSlot + index;
      const a = readSlotCode();
      const b = readSlotCode();
      references[ngramIndex * 2] = a;
      references[ngramIndex * 2 + 1] = b;
      ngramIndex += 1;
      start[slot] = poolSize;
      const entryLength = (single[a] < 0 ? length[a] : 1) + (single[b] < 0 ? length[b] : 1);
      length[slot] = entryLength;
      poolSize += entryLength;
    }
  }
  readNgramReferences(ngramCount - dictSize + dict1AtomCount, dictSize + dict2AtomCount);
  readNgramReferences(dictSize - dict1AtomCount, dict1AtomCount);
  const pool = new Uint16Array(poolSize);
  let write = 0;
  for (let index = 0;index < ngramIndex; index++) {
    for (let half = 0;half < 2; half++) {
      const source = references[index * 2 + half];
      const value = single[source];
      if (value < 0) {
        let read = start[source];
        const readEnd = read + length[source];
        while (read < readEnd)
          pool[write++] = pool[read++];
      } else {
        pool[write++] = value;
      }
    }
  }
  const out = new Uint16Array(resultLength);
  let outIndex = 0;
  while (pos < inputLength) {
    let slot = BASE91_INVERSE[input.charCodeAt(pos++)];
    if (slot >= dictSize) {
      slot = slot * base - twoCharBias + BASE91_INVERSE[input.charCodeAt(pos++)];
    }
    const value = single[slot];
    if (value < 0) {
      let read = start[slot];
      const readEnd = read + length[slot];
      while (read < readEnd)
        out[outIndex++] = pool[read++];
    } else {
      out[outIndex++] = value;
    }
  }
  return out;
}

// node_modules/.bun/entities@8.1.0/node_modules/entities/dist/generated/decode-data-html.js
var htmlDecodeTree = /* @__PURE__ */ decodeTrieDict("!}.&u%}'&}*'~!6*)%&,~!J~!J~%L~y<~!R,~~%Lu~~#GD~~#|)1#%}^%}2%+#.##%##%}&%##%'#%##&%#%#'%#&#%#&#'#%%#&#%##%#)%''%&%#%#'%#%%#%%}%%%#%#&(23#%%#&-%0%('1#(##%#'##+%'*.:1}#%#6-+(%'%%#%%%}#L'2351&('%}&/N'(0(/*-%(%%}#'+&T%7.2}#&%&#%#36/5##%&%%#&#%%#))2%%##%&&'0~!#*+&'%1~!%).'3q?&%'1~!.##%6(~!+%%%(Gw'rT~!E#<nA%#jZ~!H%(~!42##~!*31&~!G%U~#)5~#`3~!J~!Z~%]~%Y~%C~!q~!u~#kz~%#~!6'~!D~!U~!?~#T~!c%~!G#'~%7|~!G~!J~!G&~#pb~(Df}#%}*&}#%##%##%##&#-}&'#'&%#.++}%mI,#,@&(}*%}*'%&##&#%##%}&0}#.},U},%}+%}&%}#%##&}B%(}(%}+%)})%##%#&}&%##%&}<%}>%#%&}*%}(%}9%}/%})%}*%}*%}?&}&%}3%}&*#%})%#%#)}#&#-#+*%E%%'%'#%}#*V##&##I}#&&##%&%#&&Qf%%))w/0+&%#(#.%-''''++++7}>%4'',##1,#%#&%##&#'##&#*#9)%&%}#*}%,#+P(%A&%#'&##wSD',9E00#y#@}(+}&%&>~!#~!X}#*}(&&}(&}(,%}%&#+&}#&}I%#%}%)#(},'%#*}4%%#%}(''}#/##(##),%-##%%)#&}(.}&%#&}%%}*&#%},&&}&%}#%*'#%})%}D&}&%}-&}6&#&}-,%}#%})-(~+`~,=?~I9'9%~!,#%})%})%}@%}?%}(~!?~#<~#pP~#BG~#=1#%K+~#?#~%;)~#A~#mF1~#A'~'X%'~#lR~#N~'N~#r~#m#-~#i'?%#'%~#B%##%,%#~#_%#0%~#]732~,w~2+#:&#%&'0%&>%}#>##F+)#%&&#(+_}4&}-%}(&}@&}O7Fdf0@+/v4}&WU##&/0#&'('B#%}.%}'+#%}#%%&#&%#%##+#&#)#6#'#.},%}c%},%#%##%&#&%#&~#>'*-.%##%##%}#%%}%'~#)D1}#%*&~#_%%'(~#S2%'.}#~#=##*'*-%}&'%'##&&~'E%.#&~#M4}%%##&'%#~#O1##%&#'+~#<B%##%%'%+~#;#@%}#&%#&&%#(~#H1}'%'##&&~#?A}&'~#D#%32}'&&&&~#[}'(#%}'~#;C})&}%%#%~#=&%,3}%'(#%%~#^'#&&)#%'~#Y%-~#d-%'~#^%%&#&&&}#~#b~2t*&'~&(~&@~0%~e~3}%*''0})&}+~!9##-}#%-hD*)1fC#%/&/fB#40~!+#)*4~!+~!K'&:~!/*7~!.#~!H~!L':~%x&~!H#~!*~%1~!I#~!+A~#p'~!F~~#-#~,,(~.Z~!V~%;'B'mq-W~!N~%I%#&&#&}#%},%%}'%}+X#%}#&}(%}'%}<%}#%}%%'}'%}:~![)9@~%>~#UA%-%##&~!C%~!-.9:~!1~!-^2/:a~!y,D*J#-5)/4~%23,~#G~!L1~!0X3`~!2+~!!0-~&E~!W~!o,>Y&]~%cZx_&~#O*9#A#'#+I'%#)~!0B*-5A+-((F&*M#)(-7-5+'-3a5Vi~!Y~!?+[)%3),ERHm~!+:D,VG.+)?fB%%*(%)'(#&80%1'8`K8?`+'Z#&O&'H5#*9)A%%5&3))0%39+.*7#()&&*=4@**L)<'_&*+..;(#*+)./&0#3)%')-8(4ixD(&.}%,('aI:,)%,k2231T)I'#/-W7,/'Q#.'Y24+h')37</31&83##&0#),H(?'&?/1##%#&&#%''-%&&&#(&''&#.-'%#%%(,')*'&#&#'##%(%(#%('#&##%%%%('%#%#%%#%#&%##h>w+v<ayvyvcg.uuhKr}g/v|g>u9i[~>g5uI~=RvdwEg;v/g;uk!!TTSx]@RT!U!#!@VBRUU!'UTe-d0c`e&gSdicedFcrdTaqb.kYcAohdYd@a3e+d}dMdtd.aJ#bqcK`dle/e.e'dwdPdodddjbEb}ogd^ofdpduc6j?l%d{drdqc)d7bacOdQ%T#Y)X.sR[yH>6Vyv3[xwLu>vo'!*.[yBacahoj>6Rew3[xqdZa#!a&#^(X-[yG>6Vyu3[xvg3sEr|g.u/Ri9db0T#^(Xa)!-[y;>6Vylg4wKs{JwNZt3@3r=c4Z([xlg;wKt!cpq's@v7A'*a(a+!-a#[y<3Dt?3Dt'>6Vym3[xmg9rxsNJwLZt4~?r?db1T#`-!(Xa,!0[yS>6Vz%NuQs.g4wKtnJwNZtS@3r>c4Z([y%g;wKtrdga8!a(!#&T*Y-Xa#!a0<or[yc3Dtq>6Vz43[y3JwNZtf@3s!Ju}!%Dti:pm3c_%X#tjB5pkd6q!r]u?voC'*-a.a2!0a&a+[yI3DtI3Ds~3DtH>6Vyw3[xx;:s#~<5pKJwNZtE@3r~d`a)!a2T#a.(!+U.X1[yT3Dt`3Dtv>6Vz&3[y&g9rxwzcxstPu.<rAJwLZtT~?r@dZa%!a.&^*Za(/Reu[ya>6Vz23[y1g3sEr}wkg{NuQRg{ci(U#5@b`~,cg#U(2WnH5wugcRh7dX#T(Y,a'Ta!!a,[yZ<]mj>6Vz,3[y+Pv#5ReZKu+=,%!H}7ABwkaS?Rh:BcW(X#<]mrj:ubv/ARekdg%!(!a.*Ta(Y.X1!#sP>Rl*Dt6[y>>6Vyo3Wf*jOvuumvuRgRJuq*!:9<B@bX~3jVv&v@s@5Re[d/rQt{uAvo&a&a*)a2!,0Wf!3Dt0=Bs'>6Re}3[xy~<5s%JwJZt1~Gs)c;&!#2sJkNuXvzq7rxu,Re8dka4!a8(aEZ+a@Y.X1Xa)[yd=Bs(3DtP>6Vz53[y4cX#X&Re:avRe9~<5s&JwJZtQ~Gs*i^rzvdRg+Jv{%!2sbB@bX}kdga,!Za?&^*T1/!a'Dt+[y6>6Vyf3Wf%g/u;s4hGu6?Rh-JvZ,!c%#&RoX54Rivj7uyvf8RgTKvZB%*!2sGh<vu5Rgq<=C::9bb~#dZ#T&Ta6Y.X*Dt>[y93Wf)coZ(T,6VyifluvRgC@95@B@bX~/hFu34cC#T,k/unq8w8Q5RkUklwQuzunq8w8Q5Rk8d/rJu?v8w9)-&!a0a;a&aIWejg3sEr/h1s<DtDJvyZqY5aws3Jvy!&Wei~Hr1:au5@Bag>23E~5c:Z&bX};kKv?w&unuVu5Rjc;>bs)#~@:Rh.=ay<a]C;b`}Vd6s/t{uAvoaxa()!a,a7%-a#a2Dt,[yF2Wo[>6Vyt3[xuNuPRi&NuPwpi#RoWh?vf8Ri%Jv]!%Ri:KvxD!.'2WeAjZu`q9rxu,Re7woeAg-unLq(qA_/*2Wg_g3u5q^9:4E}/jTrxrzv=Wkkd~0UX#^^Xa-a1a5T&a=U1a'*aEa]!a*aPaA-adok[y54Rn>;:p3~Dp5g9rpsFNvZqjg3uJp4~<5p0Pw;5qlJwNZt*@3p1Pw:5p/Ou!5p2JvG'!6Vye=<qnJvh_[xhg3v,Rh3kOwOw-sDuev/Re^dha[a%!%!a+#Ta7)-5TaCaO!aka!a)sf[yb2>Rl!9ARiq5E}Qg=ucRkBE|oJrJ_@Wk~@Wk{JrJ_@Wk|@WkyJrJ_@Wk}@WkzJvO_[y2g-vMRmiKuYC!)&>Ri;>Ri<@3RkNc](X#@9Rk=g5vuRmhKvDB!+'=]meg3u4Rmgd)#Y'Vz3CARmfd`a+!%T'!+#Ta1Ta6TaM-sTDt9[yA9sYd'%Y#s[[xpj:ueunaXRgEjRq,v-vuqdd2'`#6Rev<32@5>:2<E}5xIo9a*X#Y(;5RePJvD_g>vyRgNj8w)v8<wggs:RgXiZt|vjx,hSq3ah!-(~@:Ro/Ou!5RhWj^v(pyw8unRhUdx-UY#^Ua.a3a70!)%UX1TaDa)'omRiRRhE[y:3Dsz=Br,>6Vyj3[xkg6ruwjcqsrPw;5r*Ku]D'Zt-@3r(~?r.i[vwv]dU1a--U#`a4(g/vsRhPOu!5RhLj:rmu9Wo!~@:wdh@g/vsRiTjXuvvNr}:RhBj^v(pyw8unRn]dz1UYa'a+^Y(!aETZalaRY.Ta?a4[yDJw1!#qLsW>6Vyrfzq-pLflpwRe|Js>%!Dt@3Dt&Jvy_[xs~HrnjMuwpsw'RecKu+D#'!t<~Grl~?rjg5u-x,gwp{ah!-(~@:Rg~Ou!5Rh'jXuvvNr}:Rh#cW#X/c;&!#2sLi[v7u7RgpJv)(!iLrxu,Re6j7v@s@5Se[e7d`aW!Za(a`T.a#!a3!&aDa-!9)Dt_=6s+3[x~~DR|h~DS6avhGun5RkZj3w)v-]mkKunB!&*]kb97R|i<ARk<c:Z(6Vy}Juh'!wziMRoS:F|vkLuauJv5vtvQRh1d='T+Y#VyO~DR|jcF#T'7R|g97R|kJv3'!ay<Rj,Jvh&!:ReXcsa6*a+#a#_aIRf9aLRf?c,Z&Rf5Rf7c.Z&Rf;Rf>cQ#%T'p-Rf8Rf=ct#%'(*!,p,Rf4p+Rf6Rf:Rf<d~'Ua%U*^UYa(!a,-!#a4YaTalaEX0a8a<Weo3Dt/3Dsx=Br93Wen~Dr;~<5p<JwNZt2@3p=Pw:5p;Ou!5r3c7&!#:p>3Ds}KvGB)_6Vyk2sM=<r7x'eovA(!hFu1ARf}cV#X&@r5j6rvwQa^Rf3c=Za'wkghJv__g;unRggA53B9=b^}%j6uduo5Jq;!(hIv%2Re`Ou4ARe_e%a#^^^Xa&!a*a2!&a6YaP!*ad!#a:aE/5Rn?[y@>6Vyp;:pE~DrY~<5pBJwNZt8@3pCh=rt3rWPw:5pAJup_[xoNuPpF9c!#'45pD5ARn)d8#X'X*3@rU72s]h>v<<sSjJpqvewOJq/(!hNw'5ReBk0s2u3w/w'5ReE5@Jq.!a+JQ!&WeU23d(#Y&RjG5]jBk!u7w&u0udARjEe#+^^^Ub#!a2/a`Z(agT1!a-a;|@TaG!aS[yV=Re~fow'RguNuPRe?bz#'>RoUWeL>:Cbb|?JwPZtVg6ruRmzJvD'!6Vz(g/vmRh~Jvy_[y(g9voRgyx*cy(#2>Ri2B9b]~9kIw9u7rluJu3Rg]dI#a%UY'@=p%CAx.gQZ&RhwwygtRm{x5g_Z'+ABqR9Woa=Bp&dV#^*Xa'!&@o{g4v]Rk;Jv{!%Rk[wkkiA5RkiwwfUB=x,fUuqC&*!>RfTg8v0RfV~ARfSd;rJsAuAv9wR'ae+/aO!a@aza/a#[yQ@Wg!2Wemg3sEr0JvB_g>uvReWg2v+Re=KupB_+[y!2AbY~-~Hr2AJwD!(h<~El>h<~El?Kun@+_:9b`}Kg-v/Ri3g;vtwyk_9]k_d=&T#*U.6qh@Ab`|K9:H|CJv[!&3Dtex'fDwC%!Rf[9WlMd[(^X,!a%Z06Vz!@WgBg=v~Rgvg,QRe@awd,#Y+jTv|Q~EfWj]uNr|~FRfXdy#Y&^Ua%!aO.!(a)Ua;=!a@aKap!a-,a!Ta]a[rSa]p?[y82sK=Bq~;:p:~<5p8Pw:5p7d'#Y'Wf(;RnRi[u4w&RgJJvG'!6Vyh=<r#ijuuv/sIKuYD'ZtG@3p9~Gr&d2#`(g<vtRgFj`u5w&rqpxRf2CJuY!+:wfnTOu!5Rg}jNs1ucv&RfwJvA!&3@q|BDcC#T,k/unq8w8Q5RkTklwQuzunq8w8Q5Rk9dga#!a'!a=#a0!:+Tb*b@aO.a4!aba8aFJv^}?!VyR~Dr<g;u%Rn.~<5p[x'e`wNZtR@3p]Pw:5pZhNvjBp.woe_g5u-r4JwF!%DtO3:ooc7&!#:p^3DtpLuGw(!+%)Dtk6Vz#2sd=<r8d'#Y([y#<x3gJt`w@!)%}MRiowzikRij=]ilxAf3,U(#B2Rf#g0v-Rm[ck{`U#]giKv3>)!&6Ri154s,KuGB_%@r68r:dJ|t`#X(9<E|u2@H|rx3gJu?w'!+'1Nu7Reg4=H~+9<wxgY95Rm]xLggZ-`(X}U2:Ri4h<uOawRmsJv__5@bb{jbV~3dka#a'a]!,#a+U=a>b6a3b%!/aKa/)!arwve^VyJ;:pR~DpTg3uJpS~<5pOPw;5qmPw:5pNOu!5pQJvG'!6Vyx=<qoJvA!{~Jup!%@qk7Rn/KvyD!}''[xz;>wkh'?Rh,x8gyt`w5D!&),(SgyccRgztJ@3pPB5p#d'(Y#<]mmifubw&RgoJvE&!82s^JvF&!8Rf,ADb]~;x=h'rNu]vK!,%'*0RnORh)4Rh*AqQg-vaRnNg;wHwkh'ba~4cE#Ta*x3gctyw@'!+%RnFRnD<4Rn@hFvK5RnCxWg[#`&a0Ua()`1Rm75Rg[c]%X#qi8Rg^NvdRj>BwzgZauwji7Rm6A4wgg]d1#&(*,.0a#Rm;Rm<Rm=Rm>Rm?Rm@RmARmBe%#^^^Xaea?aC/b+(,!a+a#!a/!>a&Ta<aKbD!2wphBRnk[yPw}hE|.=Br-3Dtm>6Vy~g6urRf.x,hPrNav!%'RnqRo%Ro#Nu;q[Pw;5r+JwNZtM@3r)d'#Y'Weh;xChL#`&RnmRnoKu}>%(!Rne~Bs-;2wjcussJv+'!aYSO}6@B<5?ba~8LrNvj!.%*ROwungw~ng~:9;Ri^>wtnig;wHRnixDh@|(UZ.x1h@|)!#:2<H|*xHn]#-UX'3Ro)z=iT}6ARns=Bwsn_wpnaRncw]aR(#UXa&Ua*a/=]iPd'#Y&Ro'WnXf{QRm2hNvj]nZd`'T~&1`{|`#9b]{}c:'!#Wl{>@=be}]?cl{{U#:5Abb}Jds#^YaF!a*b4a#a3aPa>&Tb!bH!*a_!Eau?/a&RjY<]gj>6Vz*;:pe~DrZg,QRj1JwNZtX@wihspcJvZ&!VyX9WmOJu|!|N2WmHJvh&!]ht~Bpbcn&T(!#RmQ<s7Nu;padH#X'`+WmJ@>RmKCARhnKup=!)&Wf+:RhqNuPpf9c!#'45pd5AwghpARn(Ls@w!%,)!RmP@Wfe<E|IJva!&WmNg8vsRmLd`*.`#Y'Xa!axRn*]hrA8Rhug5s@rXg8u!RmMd8#X'X*3@rV72smdI*#UY&RmICARho~GsgxVgd)Ta'U-Y&Xa!T#RnEWnA@Wffg1uDRi0hFvK5RnBxGnG&#`%owp)@wsf+bX}Ze-*1!a*^^^Ua|!#a.aq&Ya2!a>.a6!a:aO`aJDtL[y`@Wg#>6Vz12@wzoYRoZNuPRi!NuPRhzg=ucRi,@=b`{Yg=ucRi-ACJvB!&Sh[ebSh]ebi`wUuFRm4Jw2_[y0JvB!.<Ju(!&SoG}6Shd}6<Ju(!&SoH}6She}6Kur@._g5vHRieJvx!{L2G{Kx6gd'T#?Rh82Wi5cZ#X(g1w)Rm5dW-Y(Ta#!a)!#aYa=wnfE=su2>>bU{0j9udv:<svj8uQv-7RgHdE%#^'sq9sp=>Bb_{TJv`!&g/r|snj6v(us5d,#Y(56H}[978H}]Jw5!&g1rushJvB!+j;v{u5?zDhd}6}bj;v{u5?zDhe}6}ce*#`(^^^a[aea!=!a6a*aoXb1a.!aAbL!b>,b'aL!aV@Wf|2Wlg3[y/JwNZt^@3piPw:5pgJunZou3@rsJva&!Vy_g<v~Rm#JvG'!6Vz0=<r{Ju{%!:pj@WfsiXuJu3Rm:JvZ&!WfA~Bph@c4Z&Dtwax5rubx(#:awRk1@d,#Y&RfjRfid1#,Y(@Wfp2Wlrg5s@ryKu[@!,'=]ig9wlk?Rk>g5u-rqJvy'!@9RkQcH(T#=>Ri~@<wkj(Wj(KuZB*!&<7rw@9RkRcH(T#=>Ri}@<wkj)Wj)dg(Ta2Xa9X#`-!a*CARhg@@=I}d9x;c~#X%so=<sj>2@@=aybb}XjWv0Q~EfEj3vLv;<d,#Y(56H}`978H}_dgaPaFa'a/!#a3Y0a_a;a|!1(a7-[yE3[xt;:pJNvZrrg3uJrvJwNZt=@3pIh=rt3rxPw:5pGOu!5rpJvG'!6Vys=<rz@c4Z&Dt(ax5rtJvZ!&~BpH@wsfNg-vaRlNci*U#=<wei<F}a5@Jq.!a*JQ!%@qZ23d(#Y&RjH5]jCk!u7w&u0udARjFd/prq=tyvpaEa(a:.!a1aZ(@@=I}:9wpd%=<sX55w_h}@@=I{t=ay<aU@@=I}T=ay<2@@=I})?C9:9au@9Cb]}DP~=x-fAZ(2Wl1=ay<aU@@=I}>5@d##Y+jTv|vV~EfFj]uNpn~FRfGdgaK!Z2&!a8a-Tb({E!acTbM*!a(DtY[yYd'%Y#sl[y*hHvh>Re5x2c{Z}.j4uCvcawRiMd+#X+_x&d!},<5RkX;2Hzw@x,gavfB-!{CcF&T#Roe;RodwWbBg5urRgaKvHC*_6Vz+<4opieuew&Rmq@d]&Y)X,T#X0Rh}<BqP=4qS9:ReMg/ujReNJw0!/<Jui%!bd{kawwnemRelAxUa?a3#*.&UX(Ya+a/RhvRnQ<o}9Wmtd-#Y&RgSRmw9;Rmxay=Rmyg-vaRmuxEhSrNu,v-voC!%(aR.a(a7+1Ro1>Ro5CE{A9b]{@;5x#eO{:g;urRi+KrNA!%(Ro3>Ro79;Ri_Ku@>{;&!x%gX|{KunA_+g5QRj/g3u5Rj#g>uERj%wio/xRhS&!,!#^1U}wba{8>>@=be}qC@:D5ba{7Ku+A&!}x?ba}t>>@=be}se(aA^^^Uat!b0#{pa+awUazbGa#aLb9bgaWac'a5TbS=Br!d1#`%scp_Jvl!#rT>Re0JvX&!VyN=H{Fcm#U&:pY=ReaJv2&!]h0=]nUJvG'!6Vy|=<r%JrM_=]h2@Wlud'#)U'Wf'b]{i=]h/Jvh!&~BpWg=v]RnMx+ny#'Nu;pVwjnu=]nwxJnx,T#`&Reqwjnt=]nvieu9vrRjLLuYwP(#+!th@wih5pX~Gr'g5v/Rh4KunA'!-CARnP@wwiN:Rm_9x'cvw>!|l=<saKvAA!0&3@q}>w^e1bp#&Re2Re3BDx7gH#T|f5H|eKuZ>!%(:qNAH{]Jv6!+3B2B9=b^{X<5<B92:E{ZLvhwA(a;a%!igQuyRmad+#Y}m@3Rh5d8#X'X*:AqUAHzmaxwbh<aXRnVcF}RT#Nw&cj#U(BWnug/vsRntdka)(a3+.Zb7aYYan1!bVa@Xa}[y^@b[{G=H{+hFu73Rj&Pv#5ReQcK%T#sig1v{Rj'Ku+D#'!t]~Grm~?rkKuMB!01d5#`'Vy.ta3Dtu~Hroc8#'{^45s85AwZbP&!#Rn!wghxWn#KvEA!)&2RlA2RlBx:h|#(T,=]j09Wobz>x]z/@awRoTd+#Y(az]hFhCrm4d,#Y+jTv|Q~EfMj]uNr|~FRfOdCa!Xa9_X#@<plJvf!%b`{(9;Rgwc;.!#2x7cw#T|UDb]|T5Ju={(!=@E{&Jv)&!Ab`{'awJvf!~*>>@=be{#KuY>!+&4Ezyi[ugv&RjIdea+T)#UXa&T-T&a!Rh9auRmW=]kLg5vuRn+g3u4Rn-Ow6ARn,hHus5xNk?#UX(U~)/g8v0RkD~AwkkF?Ri.OuNBwkkA?Ri/d|a2`a*^UYa.!aBTZaTa'Xa;!(!2!-a#b2[yC>6Vyq3[xr2Wi?g1rusVh%s?DtF~<5rbJs;%!DtBfswKtCj[uvuSsEu3RgVx3o:u+wN'*Zt;@3rd~Grh~?rfg8w)Lq)qE&-a%!>bI|`jWv0vV~EfCjTv|vV~Ef@j]uNpn~FRfBcK#T']gWNu7x,k7q4ai(0!hHv8<RhmkMu9vrsBuev/RhlCJvB!,g<v{wchh~@:Rhji[vrv{wchi~@:RhkdS&a5UY#Ta!RgPwwiI5BwciI~@:Rh`x'iJvj'!5]iJPu8Bwch]~@:Rhach)U#h3rp]gLh@t|Ax,hTq3ah!-(~@:Ro0Ou!5RhXj^v(pyw8unRhVd|)`,^UYas!a?/a2Z'a^Ta{Tb7Ta(a#!a,Wf&9sZ3DtAadamov=Bqt3[xig8vsRm~>waiL2b`{QJv*_Ouv2qgj<v]v2BqfdR'X*X#Y-@3qr~Gqv~?p6hHv-]glPup5Lq+q?_%*b_{qF{n9b^{rOu4ARhpKvCD!+&~Bqp:5Dbb}nwoiKl&unuTuBv]v+ueunaXRf0=Jvh!0nKufu8v1w&w7q%w&uHrz:Rgnj5w,uxDJq/(!hNw'5ReCk0s2u3w/w'5ReFd>Za&!*UaA=<wkgsRnSJv^!%Refifw3vyRgOKu_B'!,<]gkiiu:w&Rh<=C@a^<B57@2F{[<B5@aW:=3away9A5aW=<B=C@a^<B57@2F{Ie-#`(^^^bCara.b8aza6!/bZ,!adTbnTbOb+aFaS!aAT9@Wf~2Wli3Dtl2@d,#Y&RfnRfmJwJZtN~GqyJva&!VyMg<v~Rm%iXuJu3Rm9Jv[_=]ih9wlkDRkCd1#`(@Wg>2Wls3cH#T(@<Rj*=>Ri|b~'#23s9h<~El.d'#Y&Dtxi^rzvdRl#d*#U%(o|B2s`hJwSaxRmDKv4B&!1:Rmdd5#`'Vx}to~Hq{x'f1v3(!BA5ba|bJv_&!Wfug1v]ReIdO+U/Y#&G}-8wze=Rh{g1v]ReHg/uQRf/by#)ibQwERl/cH#T(@<Rj+=>Ri{cNu+vlax-!(#a0qa9<Rii2;;bU{H;x<i=&X#Rk`<4wwi=C9H~8xAI(Y#<azRi@45wXI<B9;5bb~7dL(X#Xa(+!aL6Vy{g5QqOau:5au2@ay547EzbxOcU(UX-T#Ta#:Cbb|A?wjh/b_|SOw6ARgtihr}u7Rhy<d1#T)X1@@=I|~=ay<2@@=aybb}Sj3vLv;<d,#Y(56H}A978H}@dGpvs@uAu`vcw9*!aFa+ai%(b!aXa8.a?a[ozWey=sU2@G}Nch&U#Rf_WexKu+D#'!t:~Gr`~?r^j]uNr|~FRg*j^psurwJt|RmcKv)@&!)7Rkv~Br[@wxfO:Rl3co#U'6Rezj_q#vIuavjRltwzeyh@vr5JqD0!>aY?C9:9au@9Cb]}9cl#U*5;5<H||jbuus1ucv&Rfvg1v~d/pppzqFr^a--a~!aMat1(hFv;Wiz@@=Izoj5uuv-7Rix~Cw`fk2WlVcZ#X,k)u3vWs@u2]ktg;wEx'fBq(_2Wg/jTv|vV~EfoJv]!15x'hzqG!(P~EfU~CRl_j6v(us5x4i-#T(2WmZ?C2F|d>Kq<aj1!*jTqIsBv=Wl`~Cw`fi2WlWj`v0u*~>RlR=c>Z,k#u3vWs@u2]kr<c1Z+jTqIsBv=Wla~Cw`fm2WlXdmb3!a{(arZa`bkTa%TbQTa-a9+c'!aM!/[yL=Bqug.w'RifhFvyDRj.g>vgwyk^9]k^Jv3_@WfbAARkhJw2_[x|JvB_wkoIRoKwkoJRoLd'(Y#<]gm=<9<H|yd'%_X#skDtb3awwqkgNulRkgdB#^',9:p'hJwSaxRmEBwVb8@4=H|qLu+w50&!)@3qs~?pU>Awwn;;Rn=c:Z'ARn<=<qwKvC@!/&~BqqJv6!&]eVb^z^xRge'/a%+^`#Sge}6<4Rn3=]n0Pw2>Rn8Jw0!&>Rn:>Rn6cY#a7+!a&=<wkaNw~h3z_c5Z{=wjh#=]nLKv^D!&)Vyz=bW|swYb<WetcG#T(2wxa@qVx@gD#Y&b^|V5JwG&!5bb|pg/w&RgD@x=kHs=uAvn!a%%/'+RmSRh694Ro`g-vaRmRhHv-]mlxCcS#`&ba~.5cD#Ta)P~=d,#Y(56H{>978H{Dd_#{2^Y%_+qbbb{6g3sERhsbU{?dfa.,`a(Xa<!aiX#(55RiG54RiHcI#T'WiU3RiVNvdwtfcRlKNvdd,#Y&RlHRlExQgf.1*^T'X#Sgf}6Wn4=]hfPrk>Rn7Jw0!&>Rn5>Rn9Lunw?&a2!,5<oq@@wqfdRlJj5Q~=d,#Y(~ARfcOuN]fdDKw;ay(}i!547E}j?cI#T(@5bV}iCbV}hdv(^^Tb?a40,b##Tbo!a*bR!a<b|a/!aKai!aU[yK=]o^g:v>ReGJwPZtK<7Rh+h<~El,Pv#5ReR@awwxjCg,ulRjDJv6&!]j!z?aQeeg>w=Sh<eeJw;!&axEzOg,Qosc!#*:wkeJ]eJ>x'h-u(!%Ro.w~h.zPdNZ(X,Ya![x{;9ReY;wkgxRiF:x?ap#Y&RmUg<s2Rkod]+UY0TZ'!a&A9sw<=bczLNvuw{gqzNhJwSaxRmCKuLay!#&s_Rf-55b^{uJvZa!!c%#(55Ri654wmiu5RiuawLu,vp!+}^%b_}Y9;wkgxba}o>A9:=b^}zKuh=a''!3awRk3c*'!#aHRk6c+Z&Rk5Rk4Jv)&!awRjSawd9*`#0?C2@EzMj8u<uJ5RmbjQrquJu3x,k>uq@_+=ayb^|W~ARkEOuN]k@7dhzV^X/X&a-#zRzSb`zXcJzTT#2WkVKvDBzW!%FzY9;5bbzWjQrquJu3Jw3%!b`zU=ayb^zQd:#X(T-a!6Vyywxh}=b]{Jg=u1RiAdGp~qHtzv!w(wA+a+a;<!aJaYai'anasb(=azRmV:Cbb{MLq2vb!%')RjuRjrRjtRjqx3jnqCw3!%')Rk(Rk+Rk&Rk)Lq2vb!%')Rj{RjxRjzRjwLq2vb!%')RjsRjpRjfRjex3jcqCw3!%')Rk'Rk*RjkRjl9<CbbzfOu4ARhxLq2vb!%')RjyRjvRjhRjgx=joq*uKvb!%')+-Rk.Rk%Rj~Rk-Rk#Rj}x=jdq*uKvb!%')+-Rk,Rk!Rj|RjmRjjRjidAq&qKs@uAv8Aa.'*-a@a&0!aM@a5[y73Dsy3Ds|3Dt):wxgI2sHJwJZt.~Gqxwsf0ikrzt}Rl0Jvy_[xj~HqzKv_A|D!&WfP8axRoVcf,U#k(v]v+ueunaXRf1Ju}'!g8u#Ri=jQw!sCunLprq>!,')~<5qeGzq9F{W=c##%s5au:5aU3CBE|;d4#X(D!a&6Vygx(b;#(=]ed?C2F{N<capoq2r[a&!aPa9,'Pw;5s:@@=I|,55w_h|@@=IzcP~=x'fCqB_2Wl2>aU@@=I|1OuNBc1Z+jTqIsBv=Wlc~Cw`fl2WlZ~AcTa%!Z+jTqIsBv=Wlb~Cw`fh2WlYk+uNqJsBv=WlSg,u3dca3#UXaMYa)TaB-=cM|7T#<bI}l5@B932:aV2G{BOuNBJq:|M!5Ezt=<B=C@a^<B57@2F{v>cB{/T#=ay<bI{3Jv6!a.6BKq0ah&+!5E}HP~Ef{978BaU@@=Iza<7d#.Y#978BaU@@=IzH~AJq0!(@@=IzG978BaU@@=IzFe,aU*Y&^^^bvJb,b:bFad!a,c2Ta>aL.bo6!a#CbTa'T#Re{2Wlh2@G{yg6t~Ro_NvdRfticuRQRllJv3&!x&c|zs@Jw3!%RflwpfkRlpKuL;%(!Re<@G|C2GzdhIvuBwgjAg-u0RjAKQB%!(GzZ@G|5NuuRl7d='T+Y#Vy[g<v~Rm!==G|>JvA!)@wma=]m1ifuaw&RmnLs@vT'!|/+[y,g:v>ReTJw1!#qX=x!eC{bLu+wT&)ZtZauq_~Graci&U#F|89:r_Lupvq!.)&2RlG8RfaC=x!eF{_h?rpWlmd&'!#X|&]k::xJey#`'T|+<E|&2@H|%dE#(^,g;u.RiEg6vjRiC9xCkA{O|zY#g=ucRmXKs0@!&*@G|m@awRknJuh!,3d(}gY}eJvj!%Rm):Jw3!%Rm+Rm-Ls0w(&!a(a#@b[|6cZ#X'7RkxWgAOu4ARn'dH'U#Y*Vz-Wm'CARm}d]*#a%^a*T'aK!a<9bV{PC=p*Jw4!&SgxcbB5r]idw(wBRmF7xFkt#&`(Rm/Rm8E|!JuY_9:Rl5=wrgr2:bbxd@xXfB(a*#T+!.X0X1Ta/a'T&RlDRfL>RlyARl9b[z[>RfZ:RlL:RfRwlg/ARl;9;RlxKv,A/!%7s69<74=BA5ba{-8Bde#`a<XaKYa1,a'P~=wxfB2bZ}}?C972@@=I}r8@55B9;5bb}G978B2@@=aybb}3j3vLv;<Jw3&!>Rfk=ayb^}4~Ad1#`*@@=aybb{w2@>==<bbz]dx+UY#^UaF!a9!bB'Ya1.!ajXa#%olRhD[y=3Dt#Ov5BrHKuMB%!(Rf^Wep~HrJwkiQjKr|~FRg)Ku+D#'!t5~GrF~?rDdV)UY,Z/_7RkuG{<~BrBg,rlsO:235B@bX}|d?a1!#`(6Vyn5@d##Y+jTv|vV~EfIj]uNpn~FRfH7Lq2vb1!a9-978BaU@@=Iz9978BbU}#~AJq0!(@@=Iz8978BaU@@=Iz7~AJQ|}!978BbU}!JvkaK!AdUa21-U#`a+(g/vsRn~Ou!5RPj:rmu9WhOjXuvvNr}:RhAj^v(pyw8unRn[kPr}p|u7vwv]RiSBd;pppzq@qHQa?(b.!a.a`@.|xa(hFv;Wiyj5uuv-7Riw~Cw`fg2WlU978BbU|wOuNBJqG!(P~EfD~CRlQcZ#X,k)u3vWs@u2]ksg;wEx'f@q1_2Wg.j]uNpn~FRfqJv]!15x'h{qG!(@@=IzK~CRl^j6v(us5x4i,#T(2WmY?C2F{1>Kq<aj1!*jTqIsBv=Wld~Cw`fj2Wl[j`v0u*~>RlT=c>Z,k#u3vWs@u2]kq<c1Z+jTqIsBv=Wle~Cw`fn2Wl]dn1#c(a(b^a2!b/bAT(bj!aDa7bu,a_a{c0!2T0g:v>ReD2@G{42@G{5~DpM~<5rc=Bx6i>{RT#RnI@zCx]y]z:2Jv[!zr5Awyk]9]k]dD(Y+X#6Vz.g=wKtgwhaCwgmTWj2Lu,w%_+/[y-B;b^xeg3u3Rj-2@bX{*KrJ<!+'@Wg(g?QRlC@Jv`!%b[zIwsfII}8JQ_@w|kW|=Jv(%!AqcOuNBJvEzh!bYzjLs@wP#(0!oy@>RkdJwMZtc3Dtd@BcG#T'9bWxg2@2Fznd*#Y+;2x'c}w<zizixNgwa#Z'U+!/!a'!a+w~g~z6wcn{Rn}wcnzRn|5Rh%=]nJg5vuRmvNvdRlvcprJu}w*az*a#!%.a.'Bot9qT]kj@Wg'ay2Gzv@Jv`!%b[zEwsfHI}1;ck#Ux`<Cbbx_Lu+w!a&0*!wko*wwo,So,}6Juqxf!E}PigQuyRm`d3(`#8>Rn%:A5B;bZ~%KvhCa!a2!x>k7#Uxb@b{#xaRk7Jw0!)>wwhlShl}6>wwhmShm}6CJvB!.x'hhvj{!!5Bwkhhbaz}x'hivjz~!5Bwkhibaz|xEhTrNu,v-vpD!a%&/)a3a.,%Ro2t[CE{)@3re9b]{%wjo09:rgc:Z&Ro6=<riifuaw&RmoKrNA!%(Ro4>Ro89;Ri`dSaL'UYzxZb)7Rka3xRhT&!,!#^1U}vbaz{>>@=be}yC@:D5bazzKu+A&!}{?ba}y>>@=be}wxBh[t`u~vJvr!%a!a()a,a0a4RoC=]o;Ju(!%RoGRhdwjh`=]oAg>w#Ro?g5vuRo=NvdRl|Ku]C.!&;RoEJvB!%RoORoMBx'h[v+_?w~h`}~5?w~hd~!xKh]oiptu-utv.vp!#%&a30a@a'a+(a/aOp(o~p!RoDJu(!%RoHRhewjha=]oBNvdRl}g>w#Ro@g5vuRo>c[#X']o<CauRoRAd-#Y':RkpauRoQKu]C.!&;RoFJvB!%RoNRoPBx'h]v+_?w~ha}t5?w~he}ue!/UbhYacXaW^Tc&a;b:a-c/#b&aja1(!cL+!bKbt!bmcRc9aIc?8[yW3Dtt94Rg`Jv}!&SiRMzBhEebShEMNuPRe>x7gL#TzuwjirRipc<Z&>on;>z=h-MSh.Mwqczx'a7vj&!>Re4@=ResJt__NuPRi*NuPRi)j]uNr|~FRfzKrJ>_+@Wfy@Wf]2WocKrJ<!+'@Wg%g/QRl@@Jv`!&awRl<wsfFIzgLu(w*!.*&ShBMwvhIRhI9;RhNx1hK'!#Sn]Mx1hK~0!#:2<H~7cNu+w7D*'1ZtW>Rn1~?rOc:Z&Rn2=<rQ<7wjh&=BSnLMc]#X(6Vz)w[b=a!U#9wzgMc3#&(RgMRitRis<x,gKt`ax!&+SioM=BSilMc3#&(RgKRinRimKurB,!&SiQMzBhDebShDM6BJQ!(P~Efx978B2@@=I}WLrJw!!,a*&@G}O@9wkibRid@@x'fKwC!&SlDMSfLMjUv~Q~EfKKv3@a+!(hFv-]mpx/hYZ(C5RiWz<o/MwkhY?So/M@x,gbvfB*&!SgEM:SoeeehFu3:Rgbda(,^TZa)X/7Sg[eb:2RgI~BrMC@wgkc:wwkcRerx3h(uUvK!&*,SnOM4Sh*MArRg;wHRh(x=h;rJvPwI!a4',a'0@Wg&=BSh/Mg>w=Rh=g3w*wwgGRgGcW(X#;Sg}M2Gzk@Jv`!&awRl=wsfGIz`dKZ*T'Y-:RhR7RhQg5u-p`j6v(us5d,#Y+~Awkia?RicOuNBwkibba}Ld6p~tyu_vbAa'a+!a/'a3aEa8a!>Sh,ebJv{!&Sh@ebSaReb9;SgwebNuPRi(NvdRl)NuPRi'hHu^<Rm^Jvv_@Wl(g;u1Si/ebKu'B&!*Sh?eb@Wl'z@aPeb95Si.ebcpputyvjB)!,&a+0a%ShAMWeK@G}C@WfJ9;RhMwvhH9w{ia}ix,hJvRA1(!zAn[MRhHx1hJ~*!#hFv(BSn[MBJQ!(@@=I~'978B2@@=I}2db.Ua<'X}+T#a0XaG2G}E;wkg|wuh!Rh!x,hZu,@)!&So0MVy)C5RiXACJvB!&5RiY5RiZg8w)cG}*T#2@bU}=KsA>(!a.3wkhZba~(x,h^u(A!&(SoCMRhb5Bz=h[eb?w~hb~6x,h_u(A!&(SoDMRhc5Bz=h]eb?w~hc~6e)aA1T#T,^^^c-bMb&blcPaP(a/!0!bA=b5c@a(!bfbrc#2afwmhARnjwchORnp2Wlf3DtsNvdRl-2@wpa<]m0bx(#:awRk2@Jw3!%RfhwpfgRlnKQB%!(G{V@G|'NuuRl6d='T+Y#VyUg<v~Rl~==G|<Jv+'!aYShC}6@B<5?ba~8@Jw3'!g2QRljhLrpWlOd+#Y'g.w'rIg>w*wgj@g-u0Rj@Lu+wT&)ZtUauq]~GrGci&U#F|39:rELrNvj!.%*RhCwunfw~nf~:9;Ri]>wtnhg;wHRnhx3hDs@v~!/+'@Wfr@9RkSNu&Rlo=@<5GzoKs0@_+@Wl+@awRkmJuh!-3d(}pY#qWJvj!%Rm(:Jw3!%Rm,Rm*de&!1U-U#`)Re;@G|.@9Ri82@wjfvRlq=@<5GzpLvOvr!).&2RlF8Rf`C=x!eE{.Jw3_g2QRlkhLrpWlPde(!#U{s,UXa*Ta'[y'g:v>ReS;x0PZ&RnlRnn~HrKJw1}f!=x!eB|2w]aP(#Xa&a*Ta.Ua2a7=]iOd'#Y&Ro&WnWg;u.RiDg6vjRiBNvdRlzhNvj]nYJuW_2Wm3x)kFze{9d])!a.!,Y01!#&aC!a3RndC=ox~BrC@2b^{pg,rlse7x'ksuq!%Rm.E{xidw(wBRmGx9o+)X#wwo-So-}69:Rl4@xSf@a#XZ'X)X,Ta(/ARl8b[xc>RfY:RlI:RfQwlg.ARl:9;Rlwdn'#^XafaQa1X1TaHTa)@b[{zcZ#X'7RkwWg@Ou4ARn&x)kG#{,g7u/RkGdH'U#Y*Vz'Wm&CARm|bx#(A]gUbUzJj9Q~=d,#Y(56H}l978H{U7d,0#U*2>ABb_xZ978BbU{e~AJQ{g!978BbU{hxMh?ad{oUYZ.x1h?{l!#:2<H{mx3n[t{vl!,&a%3Ro(z=iS}6ARnr=Bwsn^wvn`Rnbd`*T}B0!#^X'BG{c9b]{a>>@=be}F?JvS!&BG{d7BG}(Bde#`a1X,Ya@!a'P~=wxf@2bZ}I56B2@@=aybb}08@55B9;5bb}<j3vLv;<Jw3&!>Rfg=ayb^}&OuNBKuLA!)a!P~=x#fD{f2@>==<bbzl?C972@@=Ix^d6rSu,v7w*C(0a)a6#B+a%!sQ[y?3Dt%3[xn~<5rLOu!5p@Ku+D#'!t7~GrP~?rNKvlaya7'!h+v-5qMg=t|cd,U#5AAaa5Abb{S@52B5@a[@52B5Gx[iXueu;d<#`a(!/549C;ag>23ExY5@Dah89b^~689Jv)!~2b[~1Lv'w(%*!a#bX|aPrmawRe]keu7uhv-q6rxu,q`xTo]/a5aU!bNaDXbi!b-!ao!b<bwA!#5@B932:aV2G|:d-)Y#hJrL>RhG<7@C5<H|_=Cau:5aj5@B932:bJ|ng>vIbs)#?C2F|9jPv0w.vISh-MKvUaz(.!9ABbb|[5;5<H|Eg>unwfh;9:4E|YjQsBt|vjx'hYq3!(?C2F|J:2<BaY?C2F|GOu!5x,g|p{ah!-(?C2F|c9:4E|OjXuvvNr}:Rh&i[w*t|cd+U#jJvsu)vsSn~Mkfrmu9p}u7vwv]So!McW#Xa!ax5@A5aY:5;5<H|>kJv~vYrquJu3x4ib#T)2@SmZM?C2F|Bj:rmu9@xPhI(a*a#U#`a3-5Abb|L~@:RhK9:4E|0@52B5G|#C::aY?C2F|-:2<BaY?C2F|.5Jvk!a)javYrquJu3x4ia#T)2@SmYM?C2F|HAxPhH(!a#U#`a*-5Abb|4~@:RhJ9:4E|R@52B5G|F:2<BaY?C2F|Sc^#Xa2j=Qq5CJvB!-g<v{z;hhM?C2F|Zi[vrv{z;hiM?C2F|XKsA>!a)-g<v{z;h[eb?C2F|]i[vrv{z;h]eb?C2F|^iZu.vix,hZq3ah!.(?C2F|QOu!5ShXM:2<BaY?C2F|P", 13494, 2713, 49, 25, 61);

// node_modules/.bun/entities@8.1.0/node_modules/entities/dist/internal/bin-trie-flags.js
var BinTrieFlags;
(function(BinTrieFlags) {
  BinTrieFlags[BinTrieFlags["VALUE_LENGTH"] = 49152] = "VALUE_LENGTH";
  BinTrieFlags[BinTrieFlags["FLAG13"] = 8192] = "FLAG13";
  BinTrieFlags[BinTrieFlags["BRANCH_LENGTH"] = 8064] = "BRANCH_LENGTH";
  BinTrieFlags[BinTrieFlags["JUMP_TABLE"] = 127] = "JUMP_TABLE";
  BinTrieFlags[BinTrieFlags["VALUE_MASK"] = 8191] = "VALUE_MASK";
})(BinTrieFlags || (BinTrieFlags = {}));

// node_modules/.bun/entities@8.1.0/node_modules/entities/dist/decode.js
var CharCodes;
(function(CharCodes) {
  CharCodes[CharCodes["AMP"] = 38] = "AMP";
  CharCodes[CharCodes["NUM"] = 35] = "NUM";
  CharCodes[CharCodes["SEMI"] = 59] = "SEMI";
  CharCodes[CharCodes["EQUALS"] = 61] = "EQUALS";
  CharCodes[CharCodes["ZERO"] = 48] = "ZERO";
  CharCodes[CharCodes["NINE"] = 57] = "NINE";
  CharCodes[CharCodes["LOWER_A"] = 97] = "LOWER_A";
  CharCodes[CharCodes["LOWER_X"] = 120] = "LOWER_X";
})(CharCodes || (CharCodes = {}));
var TO_LOWER_BIT = 32;
var CONSUMED_SHIFT = 21;
var CODE_POINT_MASK = 2097151;
var CONSUMED_OVERFLOW = 2047;
var longNumericConsumed = 0;
function unpackConsumed(packed) {
  const consumed = packed >>> CONSUMED_SHIFT;
  return consumed === CONSUMED_OVERFLOW ? longNumericConsumed : consumed;
}
function isNumber(code) {
  return code - CharCodes.ZERO >>> 0 <= 9;
}
function isHexadecimalCharacter(code) {
  return (code | TO_LOWER_BIT) - CharCodes.LOWER_A >>> 0 <= 5;
}
function isAlpha(code) {
  return (code | TO_LOWER_BIT) - CharCodes.LOWER_A >>> 0 <= 25;
}
function isEntityInAttributeInvalidEnd(code) {
  return code === CharCodes.EQUALS || isAlpha(code) || isNumber(code);
}
var EntityDecoderState;
(function(EntityDecoderState) {
  EntityDecoderState[EntityDecoderState["EntityStart"] = 0] = "EntityStart";
  EntityDecoderState[EntityDecoderState["NumericStart"] = 1] = "NumericStart";
  EntityDecoderState[EntityDecoderState["NumericDecimal"] = 2] = "NumericDecimal";
  EntityDecoderState[EntityDecoderState["NumericHex"] = 3] = "NumericHex";
  EntityDecoderState[EntityDecoderState["NamedEntity"] = 4] = "NamedEntity";
})(EntityDecoderState || (EntityDecoderState = {}));
var DecodingMode;
(function(DecodingMode) {
  DecodingMode[DecodingMode["Legacy"] = 0] = "Legacy";
  DecodingMode[DecodingMode["Strict"] = 1] = "Strict";
  DecodingMode[DecodingMode["Attribute"] = 2] = "Attribute";
})(DecodingMode || (DecodingMode = {}));
function determineBranch(decodeTree, current, nodeIndex, char) {
  const branchCount = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
  const jumpOffset = current & BinTrieFlags.JUMP_TABLE;
  if (jumpOffset) {
    if (branchCount === 0) {
      return char === jumpOffset ? nodeIndex : -1;
    }
    const slot = char - jumpOffset;
    if (slot >>> 0 >= branchCount)
      return -1;
    const stored = decodeTree[nodeIndex + slot];
    return stored === 0 ? -1 : nodeIndex + branchCount + stored - 1 & 65535;
  }
  if (branchCount === 0)
    return -1;
  const packedKeySlots = branchCount + 1 >> 1;
  const branchEnd = nodeIndex + packedKeySlots + branchCount;
  for (let index = 0;index < branchCount; index++) {
    const packed = decodeTree[nodeIndex + (index >> 1)];
    const key = packed >> ((index & 1) << 3) & 255;
    if (key === char) {
      const pointerIndex = nodeIndex + packedKeySlots + index;
      return branchEnd + decodeTree[pointerIndex] & 65535;
    }
    if (key > char)
      return -1;
  }
  return -1;
}
function readTrieValue(decodeTree, nodeIndex, valueLength) {
  if (valueLength === 1) {
    return String.fromCharCode(decodeTree[nodeIndex] & BinTrieFlags.VALUE_MASK);
  }
  if (valueLength === 2) {
    return String.fromCharCode(decodeTree[nodeIndex + 1]);
  }
  return String.fromCharCode(decodeTree[nodeIndex + 1], decodeTree[nodeIndex + 2]);
}
function parseNumericEntity(input, numberStart, inputLength) {
  let offset = numberStart + 1;
  let cp = 0;
  let digitStart = offset;
  if (offset < inputLength && (input.charCodeAt(offset) | TO_LOWER_BIT) === CharCodes.LOWER_X) {
    offset += 1;
    digitStart = offset;
    while (offset < inputLength) {
      const char = input.charCodeAt(offset);
      if (isNumber(char)) {
        cp = cp * 16 + (char - CharCodes.ZERO);
      } else if (isHexadecimalCharacter(char)) {
        cp = cp * 16 + ((char | TO_LOWER_BIT) - CharCodes.LOWER_A + 10);
      } else {
        break;
      }
      offset += 1;
    }
  } else {
    while (offset < inputLength) {
      const digit = input.charCodeAt(offset) - CharCodes.ZERO;
      if (digit >>> 0 > 9)
        break;
      cp = cp * 10 + digit;
      offset += 1;
    }
  }
  if (offset === digitStart)
    return 0;
  if (offset < inputLength && input.charCodeAt(offset) === CharCodes.SEMI) {
    offset += 1;
  }
  if (cp > 1114111)
    cp = 1114112;
  let consumed = offset - numberStart;
  if (consumed >= CONSUMED_OVERFLOW) {
    longNumericConsumed = consumed;
    consumed = CONSUMED_OVERFLOW;
  }
  return consumed << CONSUMED_SHIFT | cp;
}
function decodeWithTrie(input, isStrict, isAttribute) {
  const decodeTree = htmlDecodeTree;
  let offset = input.indexOf("&");
  if (offset < 0)
    return input;
  const inputLength = input.length;
  let chunkStart = 0;
  let result = "";
  const root = decodeTree[0];
  const rootJumpOffset = root & BinTrieFlags.JUMP_TABLE;
  const rootBranchCount = (root & BinTrieFlags.BRANCH_LENGTH) >> 7;
  do {
    const entityStart = offset + 1;
    const firstChar = input.charCodeAt(entityStart);
    let consumed;
    let value;
    if (firstChar === CharCodes.NUM) {
      const packed = parseNumericEntity(input, entityStart, inputLength);
      consumed = unpackConsumed(packed);
      if (isStrict && consumed > 0 && input.charCodeAt(entityStart + consumed - 1) !== CharCodes.SEMI) {
        consumed = 0;
      }
      value = consumed === 0 ? "" : codePointToString(packed & CODE_POINT_MASK);
    } else if (isAlpha(firstChar)) {
      consumed = 0;
      value = "";
      const rootSlotIndex = firstChar - rootJumpOffset;
      let nodeIndex;
      if (rootSlotIndex >>> 0 < rootBranchCount) {
        const stored = decodeTree[1 + rootSlotIndex];
        nodeIndex = stored === 0 ? -1 : rootBranchCount + stored & 65535;
      } else {
        nodeIndex = -1;
      }
      let bestNodeIndex = 0;
      let bestValueLength = 0;
      let current = nodeIndex < 0 ? 0 : decodeTree[nodeIndex];
      let index = entityStart + 1;
      trie:
        while (index < inputLength) {
          while ((current & (BinTrieFlags.VALUE_LENGTH | BinTrieFlags.FLAG13)) === 0 && (current & BinTrieFlags.JUMP_TABLE) !== 0) {
            const jumpOffset = current & BinTrieFlags.JUMP_TABLE;
            const branchCount = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
            if (branchCount === 0) {
              if (input.charCodeAt(index) !== jumpOffset)
                break trie;
              nodeIndex += 1;
            } else {
              const slot = input.charCodeAt(index) - jumpOffset;
              if (slot >>> 0 >= branchCount)
                break trie;
              const stored = decodeTree[nodeIndex + 1 + slot];
              if (stored === 0)
                break trie;
              nodeIndex = nodeIndex + branchCount + stored & 65535;
            }
            current = decodeTree[nodeIndex];
            index += 1;
            if (index >= inputLength)
              break trie;
          }
          if ((current & (BinTrieFlags.VALUE_LENGTH | BinTrieFlags.FLAG13)) === BinTrieFlags.FLAG13) {
            const runLength = (current & BinTrieFlags.BRANCH_LENGTH) >> 7;
            if (input.charCodeAt(index) !== (current & BinTrieFlags.JUMP_TABLE)) {
              break;
            }
            index += 1;
            const remaining = runLength - 1;
            let wordIndex = nodeIndex + 1;
            let charIndexInPacked = 0;
            for (;charIndexInPacked + 1 < remaining; charIndexInPacked += 2) {
              const packed = decodeTree[wordIndex];
              if (input.charCodeAt(index) !== (packed & 255))
                break trie;
              index += 1;
              if (input.charCodeAt(index) !== (packed >> 8 & 255))
                break trie;
              index += 1;
              wordIndex += 1;
            }
            if (charIndexInPacked < remaining) {
              if (input.charCodeAt(index) !== (decodeTree[wordIndex] & 255))
                break;
              index += 1;
            }
            nodeIndex += 1 + (runLength >> 1);
            current = decodeTree[nodeIndex];
            continue;
          }
          const valueLength = current >>> 14;
          const char = input.charCodeAt(index);
          if (valueLength !== 0) {
            if (char === CharCodes.SEMI) {
              consumed = index - entityStart + 1;
              value = valueLength === 1 ? String.fromCharCode(current & BinTrieFlags.VALUE_MASK) : readTrieValue(decodeTree, nodeIndex, valueLength);
              break;
            }
            if (!isStrict && (current & BinTrieFlags.FLAG13) === 0) {
              consumed = index - entityStart;
              bestNodeIndex = nodeIndex;
              bestValueLength = valueLength;
            }
            if (valueLength === 1)
              break;
          }
          const next = determineBranch(decodeTree, current, nodeIndex + (valueLength || 1), char);
          if (next < 0)
            break;
          nodeIndex = next;
          current = decodeTree[nodeIndex];
          index += 1;
        }
      if (value === "") {
        const finalVL = current >>> 14;
        if (finalVL !== 0 && !isStrict && (current & BinTrieFlags.FLAG13) === 0) {
          consumed = index - entityStart;
          bestNodeIndex = nodeIndex;
          bestValueLength = finalVL;
        }
        if (consumed > 0) {
          value = readTrieValue(decodeTree, bestNodeIndex, bestValueLength);
        }
      }
    } else {
      consumed = 0;
      value = "";
    }
    if (consumed === 0 || isAttribute && firstChar !== CharCodes.NUM && input.charCodeAt(entityStart + consumed - 1) !== CharCodes.SEMI && entityStart + consumed < inputLength && isEntityInAttributeInvalidEnd(input.charCodeAt(entityStart + consumed))) {
      offset = entityStart;
    } else {
      if (chunkStart < offset) {
        result += input.slice(chunkStart, offset);
      }
      result += value;
      offset = chunkStart = entityStart + consumed;
    }
    if (input.charCodeAt(offset) !== CharCodes.AMP) {
      offset = input.indexOf("&", offset);
    }
  } while (offset >= 0);
  return result + input.slice(chunkStart);
}
function decodeHTMLStrict(htmlString) {
  return decodeWithTrie(htmlString, true, false);
}
// node_modules/.bun/entities@8.1.0/node_modules/entities/dist/index.js
var EntityLevel;
(function(EntityLevel) {
  EntityLevel[EntityLevel["XML"] = 0] = "XML";
  EntityLevel[EntityLevel["HTML"] = 1] = "HTML";
})(EntityLevel || (EntityLevel = {}));
var EncodingMode;
(function(EncodingMode) {
  EncodingMode[EncodingMode["UTF8"] = 0] = "UTF8";
  EncodingMode[EncodingMode["ASCII"] = 1] = "ASCII";
  EncodingMode[EncodingMode["Extensive"] = 2] = "Extensive";
  EncodingMode[EncodingMode["Attribute"] = 3] = "Attribute";
  EncodingMode[EncodingMode["Text"] = 4] = "Text";
})(EncodingMode || (EncodingMode = {}));

// node_modules/.bun/linkify-it@6.1.0/node_modules/linkify-it/build/index.mjs
var REBuilder = class {
  src_Any = Any.source;
  src_Cc = Cc.source;
  src_Z = Z.source;
  src_P = P.source;
  src_ZPCc = [
    this.src_Z,
    this.src_P,
    this.src_Cc
  ].join("|");
  src_ZCc = [this.src_Z, this.src_Cc].join("|");
  cache = {};
  opts = {
    maxLength: 1e4,
    urlAuth: false,
    schema_names: []
  };
  constructor(opts = {}) {
    this.opts = {
      ...this.opts,
      ...opts
    };
  }
  set(opts = {}) {
    this.opts = {
      ...this.opts,
      ...opts
    };
    this.cache = {};
    return this;
  }
  escapeRE(str) {
    return str.replace(/[.?*+^$[\]\\(){}|-]/g, "\\$&");
  }
  nestedPairRE(open, close, depth = 4) {
    const openRE = this.escapeRE(open);
    const closeRE = this.escapeRE(close);
    const atom = `(?:(?!${this.src_ZCc}|${openRE}|${closeRE}).)`;
    let pair = `${openRE}${atom}{0,1000}${closeRE}`;
    for (let level = 2;level <= depth; level++)
      pair = `${openRE}(?:${atom}|${pair}){0,1000}${closeRE}`;
    return pair;
  }
  get_text_separators() {
    return this.cache.text_separators ??= /[><\uff5c]/;
  }
  get_pseudo_letter() {
    return this.cache.src_pseudo_letter ??= new RegExp(`(?:(?!${this.get_text_separators().source}|${this.src_ZPCc})${this.src_Any})`);
  }
  get_ipv4_addr() {
    return this.cache.src_ip4 ??= /* @__PURE__ */ new RegExp("(?:(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])[.]){3}(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])");
  }
  get_ipv6_addr() {
    const h16 = "[0-9A-Fa-f]{1,4}";
    const ls32 = `(?:(?:${h16}:${h16})|${this.get_ipv4_addr().source})`;
    return this.cache.src_ip6_addr ??= new RegExp(`(?:(?:${h16}:){6}${ls32}|::(?:${h16}:){5}${ls32}|(?:${h16})?::(?:${h16}:){4}${ls32}|(?:(?:${h16}:){0,1}${h16})?::(?:${h16}:){3}${ls32}|(?:(?:${h16}:){0,2}${h16})?::(?:${h16}:){2}${ls32}|(?:(?:${h16}:){0,3}${h16})?::${h16}:${ls32}|(?:(?:${h16}:){0,4}${h16})?::${ls32}|(?:(?:${h16}:){0,5}${h16})?::${h16}|(?:(?:${h16}:){0,6}${h16})?::)`);
  }
  get_ipv6_url_host() {
    return this.cache.src_ip6_host ??= new RegExp(`\\[${this.get_ipv6_addr().source}\\]`);
  }
  get_ipv6_mail_host() {
    return this.cache.src_ipv6_mail_host ??= new RegExp(`\\[IPv6:${this.get_ipv6_addr().source}\\]`);
  }
  get_auth() {
    return this.cache.src_auth ??= new RegExp(`(?:(?:(?!${this.src_ZCc}|[@/\\[\\]()]).){1,50}@)?`);
  }
  get_port() {
    return this.cache.src_port ??= /* @__PURE__ */ new RegExp("(?::(?:6(?:[0-4]\\d{3}|5(?:[0-4]\\d{2}|5(?:[0-2]\\d|3[0-5])))|[1-5]?\\d{1,4}))?");
  }
  get_host_terminator() {
    return this.cache.src_host_terminator ??= new RegExp(`(?=$|${this.get_text_separators().source}|${this.src_ZPCc})(?!${this.opts["---"] ? "-(?!--)|" : "-|"}_|:\\d|\\.-|\\.(?!$|${this.src_ZPCc}))`);
  }
  get_path_terminator() {
    return this.cache.src_path_terminator ??= new RegExp(`${this.src_ZPCc}|${this.get_text_separators().source}`);
  }
  get_path() {
    return this.cache.src_path ??= new RegExp(`(?:[/?#](?:${this.nestedPairRE("[", "]")}|${this.nestedPairRE("(", ")")}|${this.nestedPairRE("{", "}")}|\\"(?:(?!${this.src_ZCc}|["]).){1,100}\\"|\\'(?:(?!${this.src_ZCc}|[']).){1,100}\\'|\\'(?=${this.get_pseudo_letter().source}|[-])|\\.{2,20}[:]?[a-zA-Z0-9%/&]|\\.(?!${this.src_ZCc}|[.]|$)|` + (this.opts["---"] ? "\\-(?!--(?:[^-]|$))(?:-{0,19})|" : "\\-{1,20}|") + `,(?!${this.src_ZCc}|$)|;(?!${this.src_ZCc}|$)|\\!{1,20}(?!${this.src_ZCc}|[!]|$)|\\?(?!${this.src_ZCc}|[?]|$)|` + this.get_path_extra().source + `[\\\\/:%@#&=_~*]|(?!${this.get_path_terminator().source}).){1,${this.opts.maxLength}}|\\/)?`);
  }
  get_mail_name() {
    return this.cache.src_mail_name ??= /* @__PURE__ */ new RegExp("[-!#$%&'*+/=?^_`{|}~a-zA-Z0-9](?:[-!#$%&'*+/=?^_`{|}~a-zA-Z0-9]|[.](?=[-!#$%&'*+/=?^_`{|}~a-zA-Z0-9])){0,63}");
  }
  get_xn() {
    return this.cache.src_xn ??= /* @__PURE__ */ new RegExp("xn--[a-z0-9\\-]{1,59}");
  }
  get_tld() {
    if (this.cache.tld)
      return this.cache.tld;
    const tlds_src = [...new Set(this.opts.tlds || [])].sort().reverse().join("|");
    this.cache.tld = new RegExp(`${tlds_src || "$#none#$"}|${this.get_xn().source}`);
    return this.cache.tld;
  }
  get_domain_root() {
    return this.cache.src_domain_root ??= new RegExp("(?:" + this.get_xn().source + `|${this.get_pseudo_letter().source}{1,63})`);
  }
  get_domain() {
    return this.cache.src_domain ??= new RegExp("(?:" + this.get_xn().source + `|(?:${this.get_pseudo_letter().source})|(?:${this.get_pseudo_letter().source}(?:-|${this.get_pseudo_letter().source}){0,61}${this.get_pseudo_letter().source}))`);
  }
  get_url_host_port() {
    return this.cache.url_host_port ??= new RegExp("(?:" + this.get_ipv6_url_host().source + `|(?:(?:(?:${this.get_domain().source})\\.){0,10}${this.get_domain().source}))` + this.get_port().source + this.get_host_terminator().source);
  }
  get_fuzzy_url_host_port() {
    return this.cache.fuzzy_url_host_port ??= new RegExp("(?:" + (this.opts.fuzzyIP ? this.get_ipv4_addr().source + "|" : "") + `(?:(?:(?:${this.get_domain().source})\\.){1,10}(?:${this.get_tld().source})))` + this.get_host_terminator().source);
  }
  get_mail_host() {
    return this.cache.src_mail_host ??= new RegExp("(?:" + this.get_ipv6_mail_host().source + `|(?:(?:(?:${this.get_domain().source})\\.){0,4}${this.get_domain().source}))` + this.get_host_terminator().source);
  }
  get_fuzzy_mail_host() {
    return this.cache.src_fuzzy_mail_host ??= new RegExp("(?:" + this.get_ipv6_mail_host().source + `|(?:(?:(?:${this.get_domain().source})[.]){1,4}${this.get_domain_root().source}))` + this.get_host_terminator().source);
  }
  get_path_extra() {
    return this.cache.src_path_extra ??= /* @__PURE__ */ new RegExp("");
  }
  get_fuzzy_mail_host_search() {
    return this.cache.mail_fuzzy_host_search ??= new RegExp(`@${this.get_fuzzy_mail_host().source}`, "ig");
  }
  get_fuzzy_link_search() {
    return this.cache.link_fuzzy_search ??= new RegExp(`(^|(?![.:/\\-_@])(?:[$+<=>^\`|\uFF5C]|${this.src_ZPCc}))(?:(?![$+<=>^\`|\uFF5C])${this.get_fuzzy_url_host_port().source}${this.get_path().source})`, "ig");
  }
  get_http_validator() {
    return this.cache.http_validator ??= new RegExp("\\/\\/" + (this.opts.urlAuth ? this.get_auth().source : "") + this.get_url_host_port().source + this.get_path().source, "iy");
  }
  get_relative_proto_validator() {
    return this.cache.relative_proto_validator ??= new RegExp((this.opts.urlAuth ? this.get_auth().source : "") + `(?:localhost|${this.get_ipv6_url_host().source}|(?:(?:${this.get_domain().source})[.]){1,10}${this.get_domain_root().source})` + this.get_port().source + this.get_host_terminator().source + this.get_path().source, "iy");
  }
  get_mail_name_validator() {
    return this.cache.mail_name_validator ??= new RegExp(`(?:^|${this.get_text_separators().source}|"|\\(|${this.src_ZCc})(${this.get_mail_name().source})$`);
  }
  get_mailto_validator() {
    return this.cache.mailto_validator ??= new RegExp(`${this.get_mail_name().source}@${this.get_mail_host().source}`, "iy");
  }
  get_schema_names() {
    return this.cache.schema_names ??= new RegExp((this.opts.schema_names || []).map((name) => this.escapeRE(name)).join("|"));
  }
  get_schema_search() {
    return this.cache.schema_search ??= new RegExp(`(^|(?!_)(?:[><\uFF5C]|${this.src_ZPCc}))(${this.get_schema_names().source})`, "ig");
  }
  get_schema_at_start() {
    return this.cache.schema_at_start ??= new RegExp(`^${this.get_schema_search().source}`, "i");
  }
};
var web_schema = {
  validate: (text, pos, self) => {
    const re = self.re.get_http_validator();
    re.lastIndex = pos;
    const m = re.exec(text);
    return m ? m[0].length : 0;
  },
  normalize: (match, self) => self.normalize(match)
};
var defaultSchemas = {
  "http:": web_schema,
  "https:": web_schema,
  "ftp:": web_schema,
  "//": {
    validate: function(text, pos, self) {
      const re = self.re.get_relative_proto_validator();
      re.lastIndex = pos;
      const m = re.exec(text);
      if (m) {
        if (pos >= 3 && text[pos - 3] === ":")
          return 0;
        if (pos >= 3 && text[pos - 3] === "/")
          return 0;
        return m[0].length;
      }
      return 0;
    },
    normalize: (match, self) => self.normalize(match)
  },
  "mailto:": {
    validate: function(text, pos, self) {
      const re = self.re.get_mailto_validator();
      re.lastIndex = pos;
      const m = re.exec(text);
      return m ? m[0].length : 0;
    },
    normalize: (match, self) => self.normalize(match)
  }
};
var tlds_2ch = "a:cdefgilmnoqrstuwxz|b:abdefghijmnorstvwyz|c:acdfghiklmnoruvwxyz|d:ejkmoz|e:cegrstu|f:ijkmor|g:abdefghilmnpqrstuwy|h:kmnrtu|i:delmnoqrst|j:emop|k:eghimnprwyz|l:abcikrstuvy|m:acdeghklmnopqrstuvwxyz|n:acefgilopruz|o:m|p:aefghklmnrstwy|q:a|r:eosuw|s:abcdeghijklmnortuvxyz|t:cdfghjklmnortvwz|u:agksyz|v:aceginu|w:fs|y:et|z:amw";
var tlds_default = "biz|com|edu|gov|net|org|pro|web|xxx|aero|asia|coop|info|museum|name|shop|\u0440\u0444";
function unpackTlds() {
  const result = tlds_default.split("|");
  tlds_2ch.split("|").forEach((item) => {
    const sep = item.indexOf(":");
    const prefix = item.slice(0, sep);
    for (const suffix of item.slice(sep + 1))
      result.push(prefix + suffix);
  });
  return result;
}
var defaultOptions = {
  fuzzyLink: false,
  fuzzyEmail: true,
  fuzzyIP: false,
  "---": false,
  tlds: unpackTlds(),
  urlAuth: false,
  maxLength: 1e4
};
var Match = class {
  schema;
  index;
  lastIndex;
  raw;
  text;
  url;
  constructor(text, schema, index, lastIndex) {
    const raw = text.slice(index, lastIndex);
    this.schema = schema.toLowerCase();
    this.index = index;
    this.lastIndex = lastIndex;
    this.raw = raw;
    this.text = raw;
    this.url = raw;
  }
};
var LinkifyIt = class {
  __opts__;
  __schemas__;
  re;
  constructor(options = {}) {
    const { rebuilder, ...linkifyOptions } = options;
    this.__opts__ = {
      ...defaultOptions,
      ...linkifyOptions
    };
    this.__schemas__ = { ...defaultSchemas };
    this.re = rebuilder || new REBuilder;
    this.re.set({
      ...this.__opts__,
      schema_names: Object.keys(this.__schemas__)
    });
  }
  add(schema, definition = null) {
    if (!definition)
      delete this.__schemas__[schema];
    else {
      const def = {
        normalize: (match, self) => self.normalize(match),
        ...definition
      };
      this.__schemas__[schema] = def;
    }
    this.re.set({
      ...this.__opts__,
      schema_names: Object.keys(this.__schemas__)
    });
    return this;
  }
  set(options = {}) {
    this.__opts__ = {
      ...this.__opts__,
      ...options
    };
    this.re.set({
      ...this.__opts__,
      schema_names: Object.keys(this.__schemas__)
    });
    return this;
  }
  test(text) {
    if (!text.length)
      return false;
    let m, re;
    re = this.re.get_schema_search();
    re.lastIndex = 0;
    while ((m = re.exec(text)) !== null)
      if (this.testSchemaAt(text, m[2], re.lastIndex))
        return true;
    if (this.__opts__.fuzzyLink && this.__schemas__["http:"]) {
      re = this.re.get_fuzzy_link_search();
      re.lastIndex = 0;
      if (re.exec(text) !== null)
        return true;
    }
    if (this.__opts__.fuzzyEmail && this.__schemas__["mailto:"]) {
      if (text.indexOf("@") >= 0) {
        const mailHostRe = this.re.get_fuzzy_mail_host_search();
        const mailNameRe = this.re.get_mail_name_validator();
        mailHostRe.lastIndex = 0;
        while ((m = mailHostRe.exec(text)) !== null) {
          const name = text.slice(Math.max(0, m.index - 65), m.index);
          if (mailNameRe.test(name))
            return true;
        }
      }
    }
    return false;
  }
  testSchemaAt(text, schema, pos) {
    if (!this.__schemas__[schema.toLowerCase()])
      return 0;
    return this.__schemas__[schema.toLowerCase()].validate(text.slice(0, pos + this.__opts__.maxLength), pos, this);
  }
  match(text) {
    const result = [];
    const schemaRe = this.re.get_schema_search();
    let fuzzyLinkRe;
    let mailHostRe;
    let mailNameRe;
    let fuzzyLinkCandidate;
    let fuzzyEmailCandidate;
    let schemaPrefix;
    let schemaDone = false;
    let fuzzyLinkDone = false;
    let fuzzyEmailDone = false;
    let pos = 0;
    if (!text.length)
      return null;
    schemaRe.lastIndex = 0;
    if (this.__opts__.fuzzyLink && this.__schemas__["http:"]) {
      fuzzyLinkRe = this.re.get_fuzzy_link_search();
      fuzzyLinkRe.lastIndex = 0;
    }
    if (this.__opts__.fuzzyEmail && this.__schemas__["mailto:"]) {
      mailHostRe = this.re.get_fuzzy_mail_host_search();
      mailHostRe.lastIndex = 0;
      mailNameRe = this.re.get_mail_name_validator();
    }
    for (;; ) {
      const scanFrom = Math.max(pos - 1, 0);
      if (mailHostRe && mailNameRe && !fuzzyEmailDone && (!fuzzyEmailCandidate || fuzzyEmailCandidate.index < pos)) {
        if (mailHostRe.lastIndex < scanFrom)
          mailHostRe.lastIndex = scanFrom;
        for (;; ) {
          const m = mailHostRe.exec(text);
          if (!m) {
            fuzzyEmailDone = true;
            fuzzyEmailCandidate = undefined;
            break;
          }
          const name = mailNameRe.exec(text.slice(Math.max(0, m.index - 65), m.index));
          if (!name)
            continue;
          fuzzyEmailCandidate = {
            schema: "mailto:",
            index: m.index - name[1].length,
            lastIndex: m.index + m[0].length
          };
          if (fuzzyEmailCandidate.index >= pos)
            break;
          if (mailHostRe.lastIndex < scanFrom)
            mailHostRe.lastIndex = scanFrom;
        }
      }
      if (fuzzyLinkRe && !fuzzyLinkDone && (!fuzzyLinkCandidate || fuzzyLinkCandidate.index < pos)) {
        if (fuzzyLinkRe.lastIndex < scanFrom)
          fuzzyLinkRe.lastIndex = scanFrom;
        for (;; ) {
          const m = fuzzyLinkRe.exec(text);
          if (!m) {
            fuzzyLinkDone = true;
            fuzzyLinkCandidate = undefined;
            break;
          }
          fuzzyLinkCandidate = {
            schema: "",
            index: m.index + m[1].length,
            lastIndex: m.index + m[0].length
          };
          if (fuzzyLinkCandidate.index >= pos)
            break;
          if (fuzzyLinkRe.lastIndex < scanFrom)
            fuzzyLinkRe.lastIndex = scanFrom;
        }
      }
      let fuzzyCandidate = fuzzyEmailCandidate;
      if (!fuzzyCandidate || fuzzyLinkCandidate && (fuzzyLinkCandidate.index < fuzzyCandidate.index || fuzzyLinkCandidate.index === fuzzyCandidate.index && fuzzyLinkCandidate.lastIndex > fuzzyCandidate.lastIndex))
        fuzzyCandidate = fuzzyLinkCandidate;
      let schemaCandidate;
      if (!schemaDone)
        for (;; ) {
          if (!schemaPrefix) {
            if (schemaRe.lastIndex < scanFrom)
              schemaRe.lastIndex = scanFrom;
            const m = schemaRe.exec(text);
            if (!m) {
              schemaDone = true;
              break;
            }
            schemaPrefix = {
              schema: m[2],
              index: m.index + m[1].length,
              lastIndex: m.index + m[0].length
            };
          }
          if (schemaPrefix.index < pos) {
            schemaPrefix = undefined;
            continue;
          }
          if (fuzzyCandidate && schemaPrefix.index > fuzzyCandidate.index)
            break;
          const prefix = schemaPrefix;
          schemaPrefix = undefined;
          const len = this.testSchemaAt(text, prefix.schema, prefix.lastIndex);
          if (len) {
            schemaCandidate = {
              schema: prefix.schema,
              index: prefix.index,
              lastIndex: prefix.lastIndex + len
            };
            break;
          }
        }
      let candidate = schemaCandidate;
      if (!candidate || fuzzyEmailCandidate && (fuzzyEmailCandidate.index < candidate.index || fuzzyEmailCandidate.index === candidate.index && fuzzyEmailCandidate.lastIndex > candidate.lastIndex))
        candidate = fuzzyEmailCandidate;
      if (!candidate || fuzzyLinkCandidate && (fuzzyLinkCandidate.index < candidate.index || fuzzyLinkCandidate.index === candidate.index && fuzzyLinkCandidate.lastIndex > candidate.lastIndex))
        candidate = fuzzyLinkCandidate;
      if (!candidate)
        break;
      if (candidate === fuzzyEmailCandidate)
        fuzzyEmailCandidate = undefined;
      else if (candidate === fuzzyLinkCandidate)
        fuzzyLinkCandidate = undefined;
      const match = new Match(text, candidate.schema, candidate.index, candidate.lastIndex);
      if (match.schema)
        this.__schemas__[match.schema].normalize(match, this);
      else
        this.normalize(match);
      result.push(match);
      pos = candidate.lastIndex;
    }
    if (result.length)
      return result;
    return null;
  }
  matchAtStart(text) {
    if (!text.length)
      return null;
    const m = this.re.get_schema_at_start().exec(text);
    if (!m)
      return null;
    const len = this.testSchemaAt(text, m[2], m[0].length);
    if (!len)
      return null;
    const match = new Match(text, m[2], m.index + m[1].length, m.index + m[0].length + len);
    this.__schemas__[match.schema].normalize(match, this);
    return match;
  }
  tlds(list, keepOld = false) {
    list = Array.isArray(list) ? list : [list];
    if (!keepOld)
      this.__opts__.tlds = list;
    else
      this.__opts__.tlds = this.__opts__.tlds.concat(list);
    this.re.set({
      ...this.__opts__,
      schema_names: Object.keys(this.__schemas__)
    });
    return this;
  }
  normalize(match) {
    if (!match.schema)
      match.url = `http://${match.url}`;
    if (match.schema === "mailto:" && !/^mailto:/i.test(match.url))
      match.url = `mailto:${match.url}`;
  }
};

// node_modules/.bun/punycode.js@2.3.1/node_modules/punycode.js/punycode.es6.js
var maxInt = 2147483647;
var base = 36;
var tMin = 1;
var tMax = 26;
var skew = 38;
var damp = 700;
var initialBias = 72;
var initialN = 128;
var delimiter = "-";
var regexPunycode = /^xn--/;
var regexNonASCII = /[^\0-\x7F]/;
var regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g;
var errors = {
  overflow: "Overflow: input needs wider integers to process",
  "not-basic": "Illegal input >= 0x80 (not a basic code point)",
  "invalid-input": "Invalid input"
};
var baseMinusTMin = base - tMin;
var floor = Math.floor;
var stringFromCharCode = String.fromCharCode;
function error(type) {
  throw new RangeError(errors[type]);
}
function map(array, callback) {
  const result = [];
  let length = array.length;
  while (length--) {
    result[length] = callback(array[length]);
  }
  return result;
}
function mapDomain(domain, callback) {
  const parts = domain.split("@");
  let result = "";
  if (parts.length > 1) {
    result = parts[0] + "@";
    domain = parts[1];
  }
  domain = domain.replace(regexSeparators, ".");
  const labels = domain.split(".");
  const encoded = map(labels, callback).join(".");
  return result + encoded;
}
function ucs2decode(string) {
  const output = [];
  let counter = 0;
  const length = string.length;
  while (counter < length) {
    const value = string.charCodeAt(counter++);
    if (value >= 55296 && value <= 56319 && counter < length) {
      const extra = string.charCodeAt(counter++);
      if ((extra & 64512) == 56320) {
        output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
      } else {
        output.push(value);
        counter--;
      }
    } else {
      output.push(value);
    }
  }
  return output;
}
var ucs2encode = (codePoints) => String.fromCodePoint(...codePoints);
var basicToDigit = function(codePoint) {
  if (codePoint >= 48 && codePoint < 58) {
    return 26 + (codePoint - 48);
  }
  if (codePoint >= 65 && codePoint < 91) {
    return codePoint - 65;
  }
  if (codePoint >= 97 && codePoint < 123) {
    return codePoint - 97;
  }
  return base;
};
var digitToBasic = function(digit, flag) {
  return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
};
var adapt = function(delta, numPoints, firstTime) {
  let k = 0;
  delta = firstTime ? floor(delta / damp) : delta >> 1;
  delta += floor(delta / numPoints);
  for (;delta > baseMinusTMin * tMax >> 1; k += base) {
    delta = floor(delta / baseMinusTMin);
  }
  return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
};
var decode2 = function(input) {
  const output = [];
  const inputLength = input.length;
  let i = 0;
  let n = initialN;
  let bias = initialBias;
  let basic = input.lastIndexOf(delimiter);
  if (basic < 0) {
    basic = 0;
  }
  for (let j = 0;j < basic; ++j) {
    if (input.charCodeAt(j) >= 128) {
      error("not-basic");
    }
    output.push(input.charCodeAt(j));
  }
  for (let index = basic > 0 ? basic + 1 : 0;index < inputLength; ) {
    const oldi = i;
    for (let w = 1, k = base;; k += base) {
      if (index >= inputLength) {
        error("invalid-input");
      }
      const digit = basicToDigit(input.charCodeAt(index++));
      if (digit >= base) {
        error("invalid-input");
      }
      if (digit > floor((maxInt - i) / w)) {
        error("overflow");
      }
      i += digit * w;
      const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
      if (digit < t) {
        break;
      }
      const baseMinusT = base - t;
      if (w > floor(maxInt / baseMinusT)) {
        error("overflow");
      }
      w *= baseMinusT;
    }
    const out = output.length + 1;
    bias = adapt(i - oldi, out, oldi == 0);
    if (floor(i / out) > maxInt - n) {
      error("overflow");
    }
    n += floor(i / out);
    i %= out;
    output.splice(i++, 0, n);
  }
  return String.fromCodePoint(...output);
};
var encode2 = function(input) {
  const output = [];
  input = ucs2decode(input);
  const inputLength = input.length;
  let n = initialN;
  let delta = 0;
  let bias = initialBias;
  for (const currentValue of input) {
    if (currentValue < 128) {
      output.push(stringFromCharCode(currentValue));
    }
  }
  const basicLength = output.length;
  let handledCPCount = basicLength;
  if (basicLength) {
    output.push(delimiter);
  }
  while (handledCPCount < inputLength) {
    let m = maxInt;
    for (const currentValue of input) {
      if (currentValue >= n && currentValue < m) {
        m = currentValue;
      }
    }
    const handledCPCountPlusOne = handledCPCount + 1;
    if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
      error("overflow");
    }
    delta += (m - n) * handledCPCountPlusOne;
    n = m;
    for (const currentValue of input) {
      if (currentValue < n && ++delta > maxInt) {
        error("overflow");
      }
      if (currentValue === n) {
        let q = delta;
        for (let k = base;; k += base) {
          const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
          if (q < t) {
            break;
          }
          const qMinusT = q - t;
          const baseMinusT = base - t;
          output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
          q = floor(qMinusT / baseMinusT);
        }
        output.push(stringFromCharCode(digitToBasic(q, 0)));
        bias = adapt(delta, handledCPCountPlusOne, handledCPCount === basicLength);
        delta = 0;
        ++handledCPCount;
      }
    }
    ++delta;
    ++n;
  }
  return output.join("");
};
var toUnicode = function(input) {
  return mapDomain(input, function(string) {
    return regexPunycode.test(string) ? decode2(string.slice(4).toLowerCase()) : string;
  });
};
var toASCII = function(input) {
  return mapDomain(input, function(string) {
    return regexNonASCII.test(string) ? "xn--" + encode2(string) : string;
  });
};
var punycode = {
  version: "2.3.1",
  ucs2: {
    decode: ucs2decode,
    encode: ucs2encode
  },
  decode: decode2,
  encode: encode2,
  toASCII,
  toUnicode
};
var punycode_es6_default = punycode;

// node_modules/.bun/markdown-it@15.0.3/node_modules/markdown-it/dist/markdown-it.mjs
/*! markdown-it 15.0.3 https://github.com/markdown-it/markdown-it @license MIT */
var __defProp2 = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
  let target = {};
  for (var name in all)
    __defProp2(target, name, {
      get: all[name],
      enumerable: true
    });
  if (!no_symbols)
    __defProp2(target, Symbol.toStringTag, { value: "Module" });
  return target;
};
var utils_exports = /* @__PURE__ */ __exportAll({
  arrayReplaceAt: () => arrayReplaceAt,
  asciiTrim: () => asciiTrim,
  callable: () => callable,
  escapeHtml: () => escapeHtml,
  escapeRE: () => escapeRE,
  fromCodePoint: () => fromCodePoint,
  isMdAsciiPunct: () => isMdAsciiPunct,
  isPunctChar: () => isPunctChar,
  isPunctCharCode: () => isPunctCharCode,
  isSpace: () => isSpace,
  isValidEntityCode: () => isValidEntityCode,
  isWhiteSpace: () => isWhiteSpace,
  lib: () => lib,
  normalizeReference: () => normalizeReference,
  unescapeAll: () => unescapeAll,
  unescapeMd: () => unescapeMd
});
function callable(cls) {
  const wrapper = function(...args) {
    return Reflect.construct(cls, args, new.target && new.target !== wrapper ? new.target : cls);
  };
  Object.defineProperty(wrapper, "name", { value: cls.name });
  Object.setPrototypeOf(wrapper, cls);
  wrapper.prototype = cls.prototype;
  return wrapper;
}
function arrayReplaceAt(src, pos, newElements) {
  return [].concat(src.slice(0, pos), newElements, src.slice(pos + 1));
}
function isValidEntityCode(c) {
  if (c >= 55296 && c <= 57343)
    return false;
  if (c >= 64976 && c <= 65007)
    return false;
  if ((c & 65535) === 65535 || (c & 65535) === 65534)
    return false;
  if (c >= 0 && c <= 8)
    return false;
  if (c === 11)
    return false;
  if (c >= 14 && c <= 31)
    return false;
  if (c >= 127 && c <= 159)
    return false;
  if (c > 1114111)
    return false;
  return true;
}
function fromCodePoint(c) {
  if (c > 65535) {
    c -= 65536;
    const surrogate1 = 55296 + (c >> 10);
    const surrogate2 = 56320 + (c & 1023);
    return String.fromCharCode(surrogate1, surrogate2);
  }
  return String.fromCharCode(c);
}
var UNESCAPE_MD_RE = /\\([!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~])/g;
var UNESCAPE_ALL_RE = new RegExp(`${UNESCAPE_MD_RE.source}|${/&([a-z#][a-z0-9]{1,31});/gi.source}`, "gi");
var DIGITAL_ENTITY_TEST_RE = /^#((?:x[a-f0-9]{1,8}|[0-9]{1,8}))$/i;
function replaceEntityPattern(match, name) {
  if (name.charCodeAt(0) === 35 && DIGITAL_ENTITY_TEST_RE.test(name)) {
    const code = name[1].toLowerCase() === "x" ? parseInt(name.slice(2), 16) : parseInt(name.slice(1), 10);
    if (isValidEntityCode(code))
      return fromCodePoint(code);
    return match;
  }
  const decoded = decodeHTMLStrict(match);
  if (decoded !== match)
    return decoded;
  return match;
}
function unescapeMd(str) {
  if (str.indexOf("\\") < 0)
    return str;
  return str.replace(UNESCAPE_MD_RE, "$1");
}
function unescapeAll(str) {
  if (str.indexOf("\\") < 0 && str.indexOf("&") < 0)
    return str;
  return str.replace(UNESCAPE_ALL_RE, function(match, escaped, entity) {
    if (escaped)
      return escaped;
    return replaceEntityPattern(match, entity);
  });
}
var HTML_ESCAPE_TEST_RE = /[&<>"]/;
var HTML_ESCAPE_REPLACE_RE = /[&<>"]/g;
var HTML_REPLACEMENTS = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;"
};
function replaceUnsafeChar(ch) {
  return HTML_REPLACEMENTS[ch];
}
function escapeHtml(str) {
  if (HTML_ESCAPE_TEST_RE.test(str))
    return str.replace(HTML_ESCAPE_REPLACE_RE, replaceUnsafeChar);
  return str;
}
var REGEXP_ESCAPE_RE = /[.?*+^$[\]\\(){}|-]/g;
function escapeRE(str) {
  return str.replace(REGEXP_ESCAPE_RE, "\\$&");
}
function isSpace(code) {
  switch (code) {
    case 9:
    case 32:
      return true;
  }
  return false;
}
function isWhiteSpace(code) {
  if (code >= 8192 && code <= 8202)
    return true;
  switch (code) {
    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 32:
    case 160:
    case 5760:
    case 8239:
    case 8287:
    case 12288:
      return true;
  }
  return false;
}
function isPunctChar(ch) {
  return P.test(ch) || S.test(ch);
}
function isPunctCharCode(code) {
  return isPunctChar(fromCodePoint(code));
}
function isMdAsciiPunct(ch) {
  switch (ch) {
    case 33:
    case 34:
    case 35:
    case 36:
    case 37:
    case 38:
    case 39:
    case 40:
    case 41:
    case 42:
    case 43:
    case 44:
    case 45:
    case 46:
    case 47:
    case 58:
    case 59:
    case 60:
    case 61:
    case 62:
    case 63:
    case 64:
    case 91:
    case 92:
    case 93:
    case 94:
    case 95:
    case 96:
    case 123:
    case 124:
    case 125:
    case 126:
      return true;
    default:
      return false;
  }
}
function normalizeReference(str) {
  str = str.trim().replace(/\s+/g, " ");
  return str.toLowerCase().toUpperCase();
}
function isAsciiTrimmable(c) {
  return c === 32 || c === 9 || c === 10 || c === 13;
}
function asciiTrim(str) {
  let start = 0;
  for (;start < str.length; start++)
    if (!isAsciiTrimmable(str.charCodeAt(start)))
      break;
  let end = str.length - 1;
  for (;end >= start; end--)
    if (!isAsciiTrimmable(str.charCodeAt(end)))
      break;
  return str.slice(start, end + 1);
}
var lib = {
  mdurl: exports_mdurl,
  ucmicro: exports_build
};
function parseLinkLabel(state, start, disableNested) {
  let level, found, marker, prevPos;
  const max = state.posMax;
  const oldPos = state.pos;
  state.pos = start + 1;
  level = 1;
  while (state.pos < max) {
    marker = state.src.charCodeAt(state.pos);
    if (marker === 93) {
      level--;
      if (level === 0) {
        found = true;
        break;
      }
    }
    prevPos = state.pos;
    state.md.inline.skipToken(state);
    if (marker === 91) {
      if (prevPos === state.pos - 1)
        level++;
      else if (disableNested) {
        state.pos = oldPos;
        return -1;
      }
    }
  }
  let labelEnd = -1;
  if (found)
    labelEnd = state.pos;
  state.pos = oldPos;
  return labelEnd;
}
function parseLinkDestination(str, start, max) {
  let code;
  let pos = start;
  const result = {
    ok: false,
    pos: 0,
    str: ""
  };
  if (str.charCodeAt(pos) === 60) {
    pos++;
    while (pos < max) {
      code = str.charCodeAt(pos);
      if (code === 10)
        return result;
      if (code === 60)
        return result;
      if (code === 62) {
        result.pos = pos + 1;
        result.str = unescapeAll(str.slice(start + 1, pos));
        result.ok = true;
        return result;
      }
      if (code === 92 && pos + 1 < max) {
        pos += 2;
        continue;
      }
      pos++;
    }
    return result;
  }
  let level = 0;
  while (pos < max) {
    code = str.charCodeAt(pos);
    if (code === 32)
      break;
    if (code < 32 || code === 127)
      break;
    if (code === 92 && pos + 1 < max) {
      if (str.charCodeAt(pos + 1) === 32) {
        pos++;
        continue;
      }
      pos += 2;
      continue;
    }
    if (code === 40) {
      level++;
      if (level > 32)
        return result;
    }
    if (code === 41) {
      if (level === 0)
        break;
      level--;
    }
    pos++;
  }
  if (start === pos)
    return result;
  if (level !== 0)
    return result;
  result.str = unescapeAll(str.slice(start, pos));
  result.pos = pos;
  result.ok = true;
  return result;
}
function parseLinkTitle(str, start, max, prev_state) {
  let code;
  let pos = start;
  const state = {
    ok: false,
    can_continue: false,
    pos: 0,
    str: "",
    marker: 0
  };
  if (prev_state) {
    state.str = prev_state.str;
    state.marker = prev_state.marker;
  } else {
    if (pos >= max)
      return state;
    let marker = str.charCodeAt(pos);
    if (marker !== 34 && marker !== 39 && marker !== 40)
      return state;
    start++;
    pos++;
    if (marker === 40)
      marker = 41;
    state.marker = marker;
  }
  while (pos < max) {
    code = str.charCodeAt(pos);
    if (code === state.marker) {
      state.pos = pos + 1;
      state.str += unescapeAll(str.slice(start, pos));
      state.ok = true;
      return state;
    } else if (code === 40 && state.marker === 41)
      return state;
    else if (code === 92 && pos + 1 < max)
      pos++;
    pos++;
  }
  state.can_continue = true;
  state.str += unescapeAll(str.slice(start, pos));
  return state;
}
var helpers_exports = /* @__PURE__ */ __exportAll({
  parseLinkDestination: () => parseLinkDestination,
  parseLinkLabel: () => parseLinkLabel,
  parseLinkTitle: () => parseLinkTitle
});
function _typeof(o) {
  "@babel/helpers - typeof";
  return _typeof = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(o) {
    return typeof o;
  } : function(o) {
    return o && typeof Symbol == "function" && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function toPrimitive(t, r) {
  if (_typeof(t) != "object" || !t)
    return t;
  var e = t[Symbol.toPrimitive];
  if (e !== undefined) {
    var i = e.call(t, r || "default");
    if (_typeof(i) != "object")
      return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (r === "string" ? String : Number)(t);
}
function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return _typeof(i) == "symbol" ? i : i + "";
}
function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: true,
    configurable: true,
    writable: true
  }) : e[r] = t, e;
}
var Token = class {
  constructor(type, tag, nesting) {
    _defineProperty(this, "map", null);
    _defineProperty(this, "level", 0);
    _defineProperty(this, "children", null);
    _defineProperty(this, "content", "");
    _defineProperty(this, "markup", "");
    _defineProperty(this, "info", "");
    _defineProperty(this, "block", false);
    _defineProperty(this, "hidden", false);
    this.type = type;
    this.tag = tag;
    this.attrs = null;
    this.nesting = nesting;
    this.meta = null;
  }
  attrIndex(name) {
    if (!this.attrs)
      return -1;
    const attrs = this.attrs;
    for (let i = 0, len = attrs.length;i < len; i++)
      if (attrs[i][0] === name)
        return i;
    return -1;
  }
  attrPush(attrData) {
    if (this.attrs)
      this.attrs.push(attrData);
    else
      this.attrs = [attrData];
  }
  attrSet(name, value) {
    const idx = this.attrIndex(name);
    const attrData = [name, value];
    if (idx < 0)
      this.attrPush(attrData);
    else
      this.attrs[idx] = attrData;
  }
  attrGet(name) {
    const idx = this.attrIndex(name);
    let value = null;
    if (idx >= 0)
      value = this.attrs[idx][1];
    return value;
  }
  attrJoin(name, value) {
    const idx = this.attrIndex(name);
    if (idx < 0)
      this.attrPush([name, value]);
    else
      this.attrs[idx][1] = `${this.attrs[idx][1]} ${value}`;
  }
};
var Ruler = class {
  constructor() {
    _defineProperty(this, "__rules__", []);
    _defineProperty(this, "__cache__", null);
  }
  __find__(name) {
    for (let i = 0;i < this.__rules__.length; i++)
      if (this.__rules__[i].name === name)
        return i;
    return -1;
  }
  __compile__() {
    const chains = /* @__PURE__ */ new Set;
    this.__rules__.forEach((rule) => {
      if (!rule.enabled)
        return;
      rule.alt.forEach((altName) => {
        if (altName)
          chains.add(altName);
      });
    });
    this.__cache__ = Object.create(null);
    this.__cache__[""] = [];
    this.__rules__.forEach((rule) => {
      if (rule.enabled)
        this.__cache__[""].push(rule.fn);
    });
    chains.forEach((chain) => {
      this.__cache__[chain] = [];
      this.__rules__.forEach((rule) => {
        if (rule.enabled && rule.alt.indexOf(chain) >= 0)
          this.__cache__[chain].push(rule.fn);
      });
    });
  }
  at(name, fn, options = {}) {
    const index = this.__find__(name);
    if (index === -1)
      throw new Error(`Parser rule not found: ${name}`);
    this.__rules__[index].fn = fn;
    this.__rules__[index].alt = options.alt || [];
    this.__cache__ = null;
  }
  before(beforeName, ruleName, fn, options = {}) {
    const index = this.__find__(beforeName);
    if (index === -1)
      throw new Error(`Parser rule not found: ${beforeName}`);
    this.__rules__.splice(index, 0, {
      name: ruleName,
      enabled: true,
      fn,
      alt: options.alt || []
    });
    this.__cache__ = null;
  }
  after(afterName, ruleName, fn, options = {}) {
    const index = this.__find__(afterName);
    if (index === -1)
      throw new Error(`Parser rule not found: ${afterName}`);
    this.__rules__.splice(index + 1, 0, {
      name: ruleName,
      enabled: true,
      fn,
      alt: options.alt || []
    });
    this.__cache__ = null;
  }
  push(ruleName, fn, options = {}) {
    this.__rules__.push({
      name: ruleName,
      enabled: true,
      fn,
      alt: options.alt || []
    });
    this.__cache__ = null;
  }
  enable(list, ignoreInvalid = false) {
    if (!Array.isArray(list))
      list = [list];
    const result = [];
    list.forEach((name) => {
      const idx = this.__find__(name);
      if (idx < 0) {
        if (ignoreInvalid)
          return;
        throw new Error(`Rules manager: invalid rule name ${name}`);
      }
      this.__rules__[idx].enabled = true;
      result.push(name);
    });
    this.__cache__ = null;
    return result;
  }
  enableOnly(list, ignoreInvalid = false) {
    if (!Array.isArray(list))
      list = [list];
    this.__rules__.forEach((rule) => {
      rule.enabled = false;
    });
    this.enable(list, ignoreInvalid);
  }
  disable(list, ignoreInvalid = false) {
    if (!Array.isArray(list))
      list = [list];
    const result = [];
    list.forEach((name) => {
      const idx = this.__find__(name);
      if (idx < 0) {
        if (ignoreInvalid)
          return;
        throw new Error(`Rules manager: invalid rule name ${name}`);
      }
      this.__rules__[idx].enabled = false;
      result.push(name);
    });
    this.__cache__ = null;
    return result;
  }
  getRules(chainName) {
    if (!this.__cache__)
      this.__compile__();
    return this.__cache__[chainName] || [];
  }
};
var default_rules = {};
default_rules.code_inline = function(tokens, idx, options, env, slf) {
  const token = tokens[idx];
  return `<code${slf.renderAttrs(token)}>${escapeHtml(token.content)}</code>`;
};
default_rules.code_block = function(tokens, idx, options, env, slf) {
  const token = tokens[idx];
  return `<pre${slf.renderAttrs(token)}><code>${escapeHtml(tokens[idx].content)}</code></pre>
`;
};
default_rules.fence = function(tokens, idx, options, env, slf) {
  const token = tokens[idx];
  const info = token.info ? unescapeAll(token.info).trim() : "";
  let langName = "";
  let langAttrs = "";
  if (info) {
    const arr = info.split(/(\s+)/g);
    langName = arr[0];
    langAttrs = arr.slice(2).join("");
  }
  let highlighted;
  if (options.highlight)
    highlighted = options.highlight(token.content, langName, langAttrs) || escapeHtml(token.content);
  else
    highlighted = escapeHtml(token.content);
  if (highlighted.indexOf("<pre") === 0)
    return highlighted + `
`;
  if (info) {
    const i = token.attrIndex("class");
    const tmpAttrs = token.attrs ? token.attrs.slice() : [];
    if (i < 0)
      tmpAttrs.push(["class", `${options.langPrefix}${langName}`]);
    else {
      tmpAttrs[i] = [tmpAttrs[i][0], tmpAttrs[i][1]];
      tmpAttrs[i][1] += ` ${options.langPrefix}${langName}`;
    }
    const tmpToken = { attrs: tmpAttrs };
    return `<pre><code${slf.renderAttrs(tmpToken)}>${highlighted}</code></pre>
`;
  }
  return `<pre><code${slf.renderAttrs(token)}>${highlighted}</code></pre>
`;
};
default_rules.image = function(tokens, idx, options, env, slf) {
  const token = tokens[idx];
  token.attrs[token.attrIndex("alt")][1] = slf.renderInlineAsText(token.children, options, env);
  return slf.renderToken(tokens, idx, options);
};
default_rules.hardbreak = function(tokens, idx, options) {
  return options.xhtmlOut ? `<br />
` : `<br>
`;
};
default_rules.softbreak = function(tokens, idx, options) {
  return options.breaks ? options.xhtmlOut ? `<br />
` : `<br>
` : `
`;
};
default_rules.text = function(tokens, idx) {
  return escapeHtml(tokens[idx].content);
};
default_rules.html_block = function(tokens, idx) {
  return tokens[idx].content;
};
default_rules.html_inline = function(tokens, idx) {
  return tokens[idx].content;
};
var Renderer = class {
  constructor() {
    _defineProperty(this, "rules", Object.assign({}, default_rules));
  }
  renderAttrs(token) {
    let i, l, result;
    if (!token.attrs)
      return "";
    result = "";
    for (i = 0, l = token.attrs.length;i < l; i++)
      result += ` ${escapeHtml(token.attrs[i][0])}="${escapeHtml(String(token.attrs[i][1]))}"`;
    return result;
  }
  renderToken(tokens, idx, options) {
    const token = tokens[idx];
    let result = "";
    if (token.hidden)
      return "";
    let prev = idx - 1;
    while (prev >= 0 && tokens[prev].hidden && tokens[prev].nesting === 0)
      prev--;
    if (token.block && token.nesting !== -1 && prev >= 0 && tokens[prev].hidden && tokens[prev].nesting === -1)
      result += `
`;
    result += (token.nesting === -1 ? "</" : "<") + token.tag;
    result += this.renderAttrs(token);
    if (token.nesting === 0 && options.xhtmlOut)
      result += " /";
    let needLf = false;
    if (token.block) {
      needLf = true;
      if (token.nesting === 1) {
        let next = idx + 1;
        while (next < tokens.length && tokens[next].hidden && tokens[next].nesting === 0)
          next++;
        if (next < tokens.length) {
          const nextToken = tokens[next];
          if (nextToken.type === "inline" || nextToken.hidden)
            needLf = false;
          else if (nextToken.nesting === -1 && nextToken.tag === token.tag)
            needLf = false;
        }
      }
    }
    result += needLf ? `>
` : ">";
    return result;
  }
  renderInline(tokens, options, env) {
    let result = "";
    const rules = this.rules;
    for (let i = 0, len = tokens.length;i < len; i++) {
      const type = tokens[i].type;
      if (typeof rules[type] !== "undefined")
        result += rules[type](tokens, i, options, env, this);
      else
        result += this.renderToken(tokens, i, options);
    }
    return result;
  }
  renderInlineAsText(tokens, options, env) {
    let result = "";
    for (let i = 0, len = tokens.length;i < len; i++)
      switch (tokens[i].type) {
        case "text":
        case "code_inline":
          result += tokens[i].content;
          break;
        case "image":
          result += this.renderInlineAsText(tokens[i].children, options, env);
          break;
        case "html_inline":
        case "html_block":
          result += tokens[i].content;
          break;
        case "softbreak":
        case "hardbreak":
          result += `
`;
      }
    return result;
  }
  render(tokens, options, env) {
    let result = "";
    const rules = this.rules;
    for (let i = 0, len = tokens.length;i < len; i++) {
      const type = tokens[i].type;
      if (type === "inline")
        result += this.renderInline(tokens[i].children, options, env);
      else if (typeof rules[type] !== "undefined")
        result += rules[type](tokens, i, options, env, this);
      else
        result += this.renderToken(tokens, i, options);
    }
    return result;
  }
};
var StateCore = class {
  constructor(src, md, env) {
    _defineProperty(this, "tokens", []);
    _defineProperty(this, "inlineMode", false);
    _defineProperty(this, "Token", Token);
    this.src = src;
    this.env = env;
    this.md = md;
  }
};
var UNNORMALIZED_NEWLINE_RE = /\r\n?/g;
var NULL_RE = /\0/g;
function normalize(state) {
  let str;
  str = state.src.replace(UNNORMALIZED_NEWLINE_RE, `
`);
  str = str.replace(NULL_RE, "\uFFFD");
  state.src = str;
}
function block(state) {
  let token;
  if (state.inlineMode) {
    token = new state.Token("inline", "", 0);
    token.content = state.src;
    token.map = [0, 1];
    token.children = [];
    state.tokens.push(token);
  } else
    state.md.block.parse(state.src, state.md, state.env, state.tokens);
}
function strip_references(state) {
  const tokens = state.tokens;
  let last = 0;
  for (let curr = 0;curr < tokens.length; curr++) {
    if (tokens[curr].type === "reference_definition")
      continue;
    if (curr !== last)
      tokens[last] = tokens[curr];
    last++;
  }
  if (tokens.length !== last)
    tokens.length = last;
}
function inline(state) {
  const tokens = state.tokens;
  for (let i = 0, l = tokens.length;i < l; i++) {
    const tok = tokens[i];
    if (tok.type === "inline")
      state.md.inline.parse(tok.content, state.md, state.env, tok.children);
  }
}
function isLinkOpen$1(str) {
  return /^<a[>\s]/i.test(str);
}
function isLinkClose$1(str) {
  return /^<\/a\s*>/i.test(str);
}
function linkify$1(state) {
  const blockTokens = state.tokens;
  if (!state.md.options.linkify)
    return;
  for (let j = 0, l = blockTokens.length;j < l; j++) {
    if (blockTokens[j].type !== "inline" || !state.md.linkify.test(blockTokens[j].content))
      continue;
    const tokens = blockTokens[j].children;
    const replacements = [];
    let htmlLinkLevel = 0;
    for (let i = tokens.length - 1;i >= 0; i--) {
      const currentToken = tokens[i];
      if (currentToken.type === "link_close") {
        i--;
        while (tokens[i].level !== currentToken.level && tokens[i].type !== "link_open")
          i--;
        continue;
      }
      if (currentToken.type === "html_inline") {
        if (isLinkOpen$1(currentToken.content) && htmlLinkLevel > 0)
          htmlLinkLevel--;
        if (isLinkClose$1(currentToken.content))
          htmlLinkLevel++;
      }
      if (htmlLinkLevel > 0)
        continue;
      if (currentToken.type === "text" && state.md.linkify.test(currentToken.content)) {
        const text = currentToken.content;
        let links = state.md.linkify.match(text);
        const nodes = [];
        let level = currentToken.level;
        let lastPos = 0;
        if (links.length > 0 && links[0].index === 0 && i > 0 && tokens[i - 1].type === "text_special")
          links = links.slice(1);
        for (let ln = 0;ln < links.length; ln++) {
          const url = links[ln].url;
          const fullUrl = state.md.normalizeLink(url);
          if (!state.md.validateLink(fullUrl))
            continue;
          let urlText = links[ln].text;
          if (!links[ln].schema)
            urlText = state.md.normalizeLinkText(`http://${urlText}`).replace(/^http:\/\//, "");
          else if (links[ln].schema === "mailto:" && !/^mailto:/i.test(urlText))
            urlText = state.md.normalizeLinkText(`mailto:${urlText}`).replace(/^mailto:/, "");
          else
            urlText = state.md.normalizeLinkText(urlText);
          const pos = links[ln].index;
          if (pos > lastPos) {
            const token = new state.Token("text", "", 0);
            token.content = text.slice(lastPos, pos);
            token.level = level;
            nodes.push(token);
          }
          const token_o = new state.Token("link_open", "a", 1);
          token_o.attrs = [["href", fullUrl]];
          token_o.level = level++;
          token_o.markup = "linkify";
          token_o.info = "auto";
          nodes.push(token_o);
          const token_t = new state.Token("text", "", 0);
          token_t.content = urlText;
          token_t.level = level;
          nodes.push(token_t);
          const token_c = new state.Token("link_close", "a", -1);
          token_c.level = --level;
          token_c.markup = "linkify";
          token_c.info = "auto";
          nodes.push(token_c);
          lastPos = links[ln].lastIndex;
        }
        if (lastPos < text.length) {
          const token = new state.Token("text", "", 0);
          token.content = text.slice(lastPos);
          token.level = level;
          nodes.push(token);
        }
        replacements.push({
          index: i,
          nodes
        });
      }
    }
    if (replacements.length > 0) {
      let newTokensLength = tokens.length;
      for (const replacement of replacements)
        newTokensLength += replacement.nodes.length - 1;
      const newTokens = new Array(newTokensLength);
      let replacementIndex = 0;
      let newTokenIndex = 0;
      replacements.reverse();
      for (let i = 0;i < tokens.length; i++) {
        const replacement = replacements[replacementIndex];
        if ((replacement === null || replacement === undefined ? undefined : replacement.index) === i) {
          for (const node of replacement.nodes)
            newTokens[newTokenIndex++] = node;
          replacementIndex++;
        } else
          newTokens[newTokenIndex++] = tokens[i];
      }
      blockTokens[j].children = newTokens;
    }
  }
}
var RARE_RE = /\+-|\.\.|\?\?\?\?|!!!!|,,|--/;
var SCOPED_ABBR_TEST_RE = /\((c|tm|r)\)/i;
var SCOPED_ABBR_RE = /\((c|tm|r)\)/gi;
var SCOPED_ABBR = {
  c: "\xA9",
  r: "\xAE",
  tm: "\u2122"
};
function replaceFn(match, name) {
  return SCOPED_ABBR[name.toLowerCase()];
}
function replace_scoped(inlineTokens) {
  let inside_autolink = 0;
  for (let i = inlineTokens.length - 1;i >= 0; i--) {
    const token = inlineTokens[i];
    if (token.type === "text" && !inside_autolink)
      token.content = token.content.replace(SCOPED_ABBR_RE, replaceFn);
    if (token.type === "link_open" && token.info === "auto")
      inside_autolink--;
    if (token.type === "link_close" && token.info === "auto")
      inside_autolink++;
  }
}
function replace_rare(inlineTokens) {
  let inside_autolink = 0;
  for (let i = inlineTokens.length - 1;i >= 0; i--) {
    const token = inlineTokens[i];
    if (token.type === "text" && !inside_autolink) {
      if (RARE_RE.test(token.content))
        token.content = token.content.replace(/\+-/g, "\xB1").replace(/\.{2,}/g, "\u2026").replace(/([?!])\u2026/g, "$1..").replace(/([?!]){4,}/g, "$1$1$1").replace(/,{2,}/g, ",").replace(/(^|[^-])---(?=[^-]|$)/gm, "$1\u2014").replace(/(^|\s)--(?=\s|$)/gm, "$1\u2013").replace(/(^|[^-\s])--(?=[^-\s]|$)/gm, "$1\u2013");
    }
    if (token.type === "link_open" && token.info === "auto")
      inside_autolink--;
    if (token.type === "link_close" && token.info === "auto")
      inside_autolink++;
  }
}
function replace2(state) {
  let blkIdx;
  if (!state.md.options.typographer)
    return;
  for (blkIdx = state.tokens.length - 1;blkIdx >= 0; blkIdx--) {
    if (state.tokens[blkIdx].type !== "inline")
      continue;
    if (SCOPED_ABBR_TEST_RE.test(state.tokens[blkIdx].content))
      replace_scoped(state.tokens[blkIdx].children);
    if (RARE_RE.test(state.tokens[blkIdx].content))
      replace_rare(state.tokens[blkIdx].children);
  }
}
var QUOTE_TEST_RE = /['"]/;
var QUOTE_RE = /['"]/g;
var APOSTROPHE = "\u2019";
var MAX_OPENERS = 1000;
function truncateStack(stack, heads, length) {
  while (stack.length > length) {
    const item = stack.pop();
    if (item.isSingleQuote)
      heads.single = item.prevSameQuoteIdx;
    else
      heads.double = item.prevSameQuoteIdx;
  }
}
function addReplacement(replacements, tokenIdx, pos, ch) {
  if (!replacements[tokenIdx])
    replacements[tokenIdx] = [];
  replacements[tokenIdx].push({
    pos,
    ch
  });
}
function applyReplacements(str, replacements) {
  let result = "";
  let lastPos = 0;
  replacements.sort((a, b) => a.pos - b.pos);
  for (let i = 0;i < replacements.length; i++) {
    const replacement = replacements[i];
    result += str.slice(lastPos, replacement.pos) + replacement.ch;
    lastPos = replacement.pos + 1;
  }
  return result + str.slice(lastPos);
}
function process_inlines(tokens, state) {
  let j;
  const stack = [];
  const heads = {
    single: -1,
    double: -1
  };
  const replacements = {};
  for (let i = 0;i < tokens.length; i++) {
    const token = tokens[i];
    const thisLevel = tokens[i].level;
    for (j = stack.length - 1;j >= 0; j--)
      if (stack[j].level <= thisLevel)
        break;
    truncateStack(stack, heads, j + 1);
    if (token.type !== "text")
      continue;
    const text = token.content;
    let pos = 0;
    const max = text.length;
    OUTER:
      while (pos < max) {
        QUOTE_RE.lastIndex = pos;
        const t = QUOTE_RE.exec(text);
        if (!t)
          break;
        let canOpen = true;
        let canClose = true;
        pos = t.index + 1;
        const isSingle = t[0] === "'";
        let lastChar = 32;
        if (t.index - 1 >= 0)
          lastChar = text.charCodeAt(t.index - 1);
        else
          for (j = i - 1;j >= 0; j--) {
            if (tokens[j].type === "softbreak" || tokens[j].type === "hardbreak")
              break;
            if (!tokens[j].content)
              continue;
            lastChar = tokens[j].content.charCodeAt(tokens[j].content.length - 1);
            break;
          }
        let nextChar = 32;
        if (pos < max)
          nextChar = text.charCodeAt(pos);
        else
          for (j = i + 1;j < tokens.length; j++) {
            if (tokens[j].type === "softbreak" || tokens[j].type === "hardbreak")
              break;
            if (!tokens[j].content)
              continue;
            nextChar = tokens[j].content.charCodeAt(0);
            break;
          }
        const isLastPunctChar = isMdAsciiPunct(lastChar) || isPunctCharCode(lastChar);
        const isNextPunctChar = isMdAsciiPunct(nextChar) || isPunctCharCode(nextChar);
        const isLastWhiteSpace = isWhiteSpace(lastChar);
        const isNextWhiteSpace = isWhiteSpace(nextChar);
        if (isNextWhiteSpace)
          canOpen = false;
        else if (isNextPunctChar) {
          if (!(isLastWhiteSpace || isLastPunctChar))
            canOpen = false;
        }
        if (isLastWhiteSpace)
          canClose = false;
        else if (isLastPunctChar) {
          if (!(isNextWhiteSpace || isNextPunctChar))
            canClose = false;
        }
        if (nextChar === 34 && t[0] === '"') {
          if (lastChar >= 48 && lastChar <= 57)
            canClose = canOpen = false;
        }
        if (canOpen && canClose) {
          canOpen = isLastPunctChar;
          canClose = isNextPunctChar;
        }
        if (!canOpen && !canClose) {
          if (isSingle)
            addReplacement(replacements, i, t.index, APOSTROPHE);
          continue;
        }
        if (canClose) {
          j = isSingle ? heads.single : heads.double;
          if (j >= 0 && stack[j].level === thisLevel) {
            const item = stack[j];
            let openQuote;
            let closeQuote;
            if (isSingle) {
              openQuote = state.md.options.quotes[2];
              closeQuote = state.md.options.quotes[3];
            } else {
              openQuote = state.md.options.quotes[0];
              closeQuote = state.md.options.quotes[1];
            }
            addReplacement(replacements, i, t.index, closeQuote);
            addReplacement(replacements, item.tokenIdx, item.contentPos, openQuote);
            truncateStack(stack, heads, j);
            continue OUTER;
          }
        }
        if (canOpen) {
          if (stack.length >= MAX_OPENERS)
            return;
          stack.push({
            tokenIdx: i,
            contentPos: t.index,
            isSingleQuote: isSingle,
            level: thisLevel,
            prevSameQuoteIdx: isSingle ? heads.single : heads.double
          });
          if (isSingle)
            heads.single = stack.length - 1;
          else
            heads.double = stack.length - 1;
        } else if (canClose && isSingle)
          addReplacement(replacements, i, t.index, APOSTROPHE);
      }
  }
  Object.keys(replacements).forEach(function(tokenIdx) {
    const idx = Number(tokenIdx);
    tokens[idx].content = applyReplacements(tokens[idx].content, replacements[tokenIdx]);
  });
}
function smartquotes(state) {
  if (!state.md.options.typographer)
    return;
  for (let blkIdx = state.tokens.length - 1;blkIdx >= 0; blkIdx--) {
    if (state.tokens[blkIdx].type !== "inline" || !QUOTE_TEST_RE.test(state.tokens[blkIdx].content))
      continue;
    process_inlines(state.tokens[blkIdx].children, state);
  }
}
function join_alt(tokens) {
  let curr, last;
  const max = tokens.length;
  for (curr = 0;curr < max; curr++)
    if (tokens[curr].type === "text_special")
      tokens[curr].type = "text";
  for (curr = last = 0;curr < max; curr++)
    if (tokens[curr].type === "text" && curr + 1 < max && tokens[curr + 1].type === "text")
      tokens[curr + 1].content = tokens[curr].content + tokens[curr + 1].content;
    else {
      if (curr !== last)
        tokens[last] = tokens[curr];
      last++;
    }
  if (curr !== last)
    tokens.length = last;
}
function text_join(state) {
  let curr, last;
  const blockTokens = state.tokens;
  const l = blockTokens.length;
  for (let j = 0;j < l; j++) {
    if (blockTokens[j].type !== "inline")
      continue;
    const tokens = blockTokens[j].children;
    const max = tokens.length;
    for (curr = 0;curr < max; curr++) {
      if (tokens[curr].type === "text_special")
        tokens[curr].type = "text";
      if (tokens[curr].children)
        join_alt(tokens[curr].children);
    }
    for (curr = last = 0;curr < max; curr++)
      if (tokens[curr].type === "text" && curr + 1 < max && tokens[curr + 1].type === "text")
        tokens[curr + 1].content = tokens[curr].content + tokens[curr + 1].content;
      else {
        if (curr !== last)
          tokens[last] = tokens[curr];
        last++;
      }
    if (curr !== last)
      tokens.length = last;
  }
}
var _rules$2 = [
  ["normalize", normalize],
  ["block", block],
  ["strip_references", strip_references],
  ["inline", inline],
  ["linkify", linkify$1],
  ["replacements", replace2],
  ["smartquotes", smartquotes],
  ["text_join", text_join]
];
var ParserCore = class {
  constructor() {
    _defineProperty(this, "ruler", new Ruler);
    _defineProperty(this, "State", StateCore);
    for (let i = 0;i < _rules$2.length; i++)
      this.ruler.push(_rules$2[i][0], _rules$2[i][1]);
  }
  process(state) {
    const rules = this.ruler.getRules("");
    for (let i = 0, l = rules.length;i < l; i++)
      rules[i](state);
  }
};
var StateBlock = class {
  constructor(src, md, env, tokens) {
    _defineProperty(this, "bMarks", []);
    _defineProperty(this, "eMarks", []);
    _defineProperty(this, "tShift", []);
    _defineProperty(this, "sCount", []);
    _defineProperty(this, "bsCount", []);
    _defineProperty(this, "blkIndent", 0);
    _defineProperty(this, "line", 0);
    _defineProperty(this, "lineMax", 0);
    _defineProperty(this, "tight", false);
    _defineProperty(this, "listIndent", -1);
    _defineProperty(this, "parentType", "root");
    _defineProperty(this, "level", 0);
    _defineProperty(this, "Token", Token);
    this.src = src;
    this.md = md;
    this.env = env;
    this.tokens = tokens;
    const s = this.src;
    for (let start = 0, pos = 0, indent = 0, offset = 0, len = s.length, indent_found = false;pos < len; pos++) {
      const ch = s.charCodeAt(pos);
      if (!indent_found) {
        if (isSpace(ch)) {
          indent++;
          if (ch === 9)
            offset += 4 - offset % 4;
          else
            offset++;
          continue;
        } else
          indent_found = true;
      }
      if (ch === 10 || pos === len - 1) {
        if (ch !== 10)
          pos++;
        this.bMarks.push(start);
        this.eMarks.push(pos);
        this.tShift.push(indent);
        this.sCount.push(offset);
        this.bsCount.push(0);
        indent_found = false;
        indent = 0;
        offset = 0;
        start = pos + 1;
      }
    }
    this.bMarks.push(s.length);
    this.eMarks.push(s.length);
    this.tShift.push(0);
    this.sCount.push(0);
    this.bsCount.push(0);
    this.lineMax = this.bMarks.length - 1;
  }
  push(type, tag, nesting) {
    const token = new Token(type, tag, nesting);
    token.block = true;
    if (nesting < 0)
      this.level--;
    token.level = this.level;
    if (nesting > 0)
      this.level++;
    this.tokens.push(token);
    return token;
  }
  isEmpty(line) {
    return this.bMarks[line] + this.tShift[line] >= this.eMarks[line];
  }
  skipEmptyLines(from) {
    for (let max = this.lineMax;from < max; from++)
      if (this.bMarks[from] + this.tShift[from] < this.eMarks[from])
        break;
    return from;
  }
  skipSpaces(pos) {
    for (let max = this.src.length;pos < max; pos++)
      if (!isSpace(this.src.charCodeAt(pos)))
        break;
    return pos;
  }
  skipSpacesBack(pos, min) {
    if (pos <= min)
      return pos;
    while (pos > min)
      if (!isSpace(this.src.charCodeAt(--pos)))
        return pos + 1;
    return pos;
  }
  skipChars(pos, code) {
    for (let max = this.src.length;pos < max; pos++)
      if (this.src.charCodeAt(pos) !== code)
        break;
    return pos;
  }
  skipCharsBack(pos, code, min) {
    if (pos <= min)
      return pos;
    while (pos > min)
      if (code !== this.src.charCodeAt(--pos))
        return pos + 1;
    return pos;
  }
  getLines(begin, end, indent, keepLastLF) {
    if (begin >= end)
      return "";
    const queue = new Array(end - begin);
    for (let i = 0, line = begin;line < end; line++, i++) {
      let lineIndent = 0;
      const lineStart = this.bMarks[line];
      let first = lineStart;
      let last;
      if (line + 1 < end || keepLastLF)
        last = this.eMarks[line] + 1;
      else
        last = this.eMarks[line];
      while (first < last && lineIndent < indent) {
        const ch = this.src.charCodeAt(first);
        if (isSpace(ch)) {
          if (ch === 9)
            lineIndent += 4 - (lineIndent + this.bsCount[line]) % 4;
          else
            lineIndent++;
        } else if (first - lineStart < this.tShift[line])
          lineIndent++;
        else
          break;
        first++;
      }
      if (lineIndent > indent)
        queue[i] = new Array(lineIndent - indent + 1).join(" ") + this.src.slice(first, last);
      else
        queue[i] = this.src.slice(first, last);
    }
    return queue.join("");
  }
};
var MAX_AUTOCOMPLETED_CELLS = 65536;
function getLine(state, line) {
  const pos = state.bMarks[line] + state.tShift[line];
  const max = state.eMarks[line];
  return state.src.slice(pos, max);
}
function escapedSplit(str) {
  const result = [];
  const max = str.length;
  let pos = 0;
  let ch = str.charCodeAt(pos);
  let isEscaped = false;
  let lastPos = 0;
  let current = "";
  while (pos < max) {
    if (ch === 124) {
      if (!isEscaped) {
        result.push(current + str.substring(lastPos, pos));
        current = "";
        lastPos = pos + 1;
      } else {
        current += str.substring(lastPos, pos - 1);
        lastPos = pos;
      }
    }
    isEscaped = ch === 92;
    pos++;
    ch = str.charCodeAt(pos);
  }
  result.push(current + str.substring(lastPos));
  return result;
}
function table(state, startLine, endLine, silent) {
  if (startLine + 2 > endLine)
    return false;
  let nextLine = startLine + 1;
  if (state.sCount[nextLine] < state.blkIndent)
    return false;
  if (state.sCount[nextLine] - state.blkIndent >= 4)
    return false;
  let pos = state.bMarks[nextLine] + state.tShift[nextLine];
  if (pos >= state.eMarks[nextLine])
    return false;
  const firstCh = state.src.charCodeAt(pos++);
  if (firstCh !== 124 && firstCh !== 45 && firstCh !== 58)
    return false;
  if (pos >= state.eMarks[nextLine])
    return false;
  const secondCh = state.src.charCodeAt(pos++);
  if (secondCh !== 124 && secondCh !== 45 && secondCh !== 58 && !isSpace(secondCh))
    return false;
  if (firstCh === 45 && isSpace(secondCh))
    return false;
  while (pos < state.eMarks[nextLine]) {
    const ch = state.src.charCodeAt(pos);
    if (ch !== 124 && ch !== 45 && ch !== 58 && !isSpace(ch))
      return false;
    pos++;
  }
  let lineText = getLine(state, startLine + 1);
  let columns = lineText.split("|");
  const aligns = [];
  for (let i = 0;i < columns.length; i++) {
    const t = columns[i].trim();
    if (!t) {
      if (i === 0 || i === columns.length - 1)
        continue;
      else
        return false;
    }
    if (!/^:?-+:?$/.test(t))
      return false;
    if (t.charCodeAt(t.length - 1) === 58)
      aligns.push(t.charCodeAt(0) === 58 ? "center" : "right");
    else if (t.charCodeAt(0) === 58)
      aligns.push("left");
    else
      aligns.push("");
  }
  lineText = getLine(state, startLine).trim();
  if (lineText.indexOf("|") === -1)
    return false;
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  columns = escapedSplit(lineText);
  if (columns.length && columns[0] === "")
    columns.shift();
  if (columns.length && columns[columns.length - 1] === "")
    columns.pop();
  const columnCount = columns.length;
  if (columnCount === 0 || columnCount !== aligns.length)
    return false;
  if (silent)
    return true;
  const oldParentType = state.parentType;
  state.parentType = "table";
  const terminatorRules = state.md.block.ruler.getRules("blockquote");
  const token_to = state.push("table_open", "table", 1);
  const tableLines = [startLine, 0];
  token_to.map = tableLines;
  const token_tho = state.push("thead_open", "thead", 1);
  token_tho.map = [startLine, startLine + 1];
  const token_htro = state.push("tr_open", "tr", 1);
  token_htro.map = [startLine, startLine + 1];
  for (let i = 0;i < columns.length; i++) {
    const token_ho = state.push("th_open", "th", 1);
    if (aligns[i])
      token_ho.attrs = [["style", `text-align:${aligns[i]}`]];
    const token_il = state.push("inline", "", 0);
    token_il.content = columns[i].trim();
    token_il.children = [];
    state.push("th_close", "th", -1);
  }
  state.push("tr_close", "tr", -1);
  state.push("thead_close", "thead", -1);
  let tbodyLines;
  let autocompletedCells = 0;
  for (nextLine = startLine + 2;nextLine < endLine; nextLine++) {
    if (state.sCount[nextLine] < state.blkIndent)
      break;
    let terminate = false;
    for (let i = 0, l = terminatorRules.length;i < l; i++)
      if (terminatorRules[i](state, nextLine, endLine, true)) {
        terminate = true;
        break;
      }
    if (terminate)
      break;
    lineText = getLine(state, nextLine).trim();
    if (!lineText)
      break;
    if (state.sCount[nextLine] - state.blkIndent >= 4)
      break;
    columns = escapedSplit(lineText);
    if (columns.length && columns[0] === "")
      columns.shift();
    if (columns.length && columns[columns.length - 1] === "")
      columns.pop();
    autocompletedCells += columnCount - columns.length;
    if (autocompletedCells > MAX_AUTOCOMPLETED_CELLS)
      break;
    if (nextLine === startLine + 2) {
      const token_tbo = state.push("tbody_open", "tbody", 1);
      token_tbo.map = tbodyLines = [startLine + 2, 0];
    }
    const token_tro = state.push("tr_open", "tr", 1);
    token_tro.map = [nextLine, nextLine + 1];
    for (let i = 0;i < columnCount; i++) {
      const token_tdo = state.push("td_open", "td", 1);
      if (aligns[i])
        token_tdo.attrs = [["style", `text-align:${aligns[i]}`]];
      const token_il = state.push("inline", "", 0);
      token_il.content = columns[i] ? columns[i].trim() : "";
      token_il.children = [];
      state.push("td_close", "td", -1);
    }
    state.push("tr_close", "tr", -1);
  }
  if (tbodyLines) {
    state.push("tbody_close", "tbody", -1);
    tbodyLines[1] = nextLine;
  }
  state.push("table_close", "table", -1);
  tableLines[1] = nextLine;
  state.parentType = oldParentType;
  state.line = nextLine;
  return true;
}
function code(state, startLine, endLine) {
  if (state.sCount[startLine] - state.blkIndent < 4)
    return false;
  let nextLine = startLine + 1;
  let last = nextLine;
  while (nextLine < endLine) {
    if (state.isEmpty(nextLine)) {
      nextLine++;
      continue;
    }
    if (state.sCount[nextLine] - state.blkIndent >= 4) {
      nextLine++;
      last = nextLine;
      continue;
    }
    break;
  }
  state.line = last;
  const token = state.push("code_block", "code", 0);
  token.content = state.getLines(startLine, last, 4 + state.blkIndent, false) + `
`;
  token.map = [startLine, state.line];
  return true;
}
function fence(state, startLine, endLine, silent) {
  let pos = state.bMarks[startLine] + state.tShift[startLine];
  let max = state.eMarks[startLine];
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  if (pos + 3 > max)
    return false;
  const marker = state.src.charCodeAt(pos);
  if (marker !== 126 && marker !== 96)
    return false;
  let mem = pos;
  pos = state.skipChars(pos, marker);
  let len = pos - mem;
  if (len < 3)
    return false;
  const markup = state.src.slice(mem, pos);
  const params = state.src.slice(pos, max);
  if (marker === 96) {
    if (params.indexOf(String.fromCharCode(marker)) >= 0)
      return false;
  }
  if (silent)
    return true;
  let nextLine = startLine;
  let haveEndMarker = false;
  for (;; ) {
    nextLine++;
    if (nextLine >= endLine)
      break;
    pos = mem = state.bMarks[nextLine] + state.tShift[nextLine];
    max = state.eMarks[nextLine];
    if (pos < max && state.sCount[nextLine] < state.blkIndent)
      break;
    if (state.src.charCodeAt(pos) !== marker)
      continue;
    if (state.sCount[nextLine] - state.blkIndent >= 4)
      continue;
    pos = state.skipChars(pos, marker);
    if (pos - mem < len)
      continue;
    pos = state.skipSpaces(pos);
    if (pos < max)
      continue;
    haveEndMarker = true;
    break;
  }
  len = state.sCount[startLine];
  state.line = nextLine + (haveEndMarker ? 1 : 0);
  const token = state.push("fence", "code", 0);
  token.info = params;
  token.content = state.getLines(startLine + 1, nextLine, len, true);
  token.markup = markup;
  token.map = [startLine, state.line];
  return true;
}
function blockquote(state, startLine, endLine, silent) {
  let pos = state.bMarks[startLine] + state.tShift[startLine];
  let max = state.eMarks[startLine];
  const oldLineMax = state.lineMax;
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  if (state.src.charCodeAt(pos) !== 62)
    return false;
  if (silent)
    return true;
  const oldBMarks = [];
  const oldBSCount = [];
  const oldSCount = [];
  const oldTShift = [];
  const terminatorRules = state.md.block.ruler.getRules("blockquote");
  const oldParentType = state.parentType;
  state.parentType = "blockquote";
  let lastLineEmpty = false;
  let nextLine;
  for (nextLine = startLine;nextLine < endLine; nextLine++) {
    const isOutdented = state.sCount[nextLine] < state.blkIndent;
    pos = state.bMarks[nextLine] + state.tShift[nextLine];
    max = state.eMarks[nextLine];
    if (pos >= max)
      break;
    if (state.src.charCodeAt(pos++) === 62 && !isOutdented) {
      let initial = state.sCount[nextLine] + 1;
      let spaceAfterMarker;
      let adjustTab;
      if (state.src.charCodeAt(pos) === 32) {
        pos++;
        initial++;
        adjustTab = false;
        spaceAfterMarker = true;
      } else if (state.src.charCodeAt(pos) === 9) {
        spaceAfterMarker = true;
        if ((state.bsCount[nextLine] + initial) % 4 === 3) {
          pos++;
          initial++;
          adjustTab = false;
        } else
          adjustTab = true;
      } else
        spaceAfterMarker = false;
      let offset = initial;
      oldBMarks.push(state.bMarks[nextLine]);
      state.bMarks[nextLine] = pos;
      while (pos < max) {
        const ch = state.src.charCodeAt(pos);
        if (isSpace(ch)) {
          if (ch === 9)
            offset += 4 - (offset + state.bsCount[nextLine] + (adjustTab ? 1 : 0)) % 4;
          else
            offset++;
        } else
          break;
        pos++;
      }
      lastLineEmpty = pos >= max;
      oldBSCount.push(state.bsCount[nextLine]);
      state.bsCount[nextLine] = state.sCount[nextLine] + 1 + (spaceAfterMarker ? 1 : 0);
      oldSCount.push(state.sCount[nextLine]);
      state.sCount[nextLine] = offset - initial;
      oldTShift.push(state.tShift[nextLine]);
      state.tShift[nextLine] = pos - state.bMarks[nextLine];
      continue;
    }
    if (lastLineEmpty)
      break;
    let terminate = false;
    for (let i = 0, l = terminatorRules.length;i < l; i++)
      if (terminatorRules[i](state, nextLine, endLine, true)) {
        terminate = true;
        break;
      }
    if (terminate) {
      state.lineMax = nextLine;
      if (state.blkIndent !== 0) {
        oldBMarks.push(state.bMarks[nextLine]);
        oldBSCount.push(state.bsCount[nextLine]);
        oldTShift.push(state.tShift[nextLine]);
        oldSCount.push(state.sCount[nextLine]);
        state.sCount[nextLine] -= state.blkIndent;
      }
      break;
    }
    oldBMarks.push(state.bMarks[nextLine]);
    oldBSCount.push(state.bsCount[nextLine]);
    oldTShift.push(state.tShift[nextLine]);
    oldSCount.push(state.sCount[nextLine]);
    state.sCount[nextLine] = -1;
  }
  const oldIndent = state.blkIndent;
  state.blkIndent = 0;
  const token_o = state.push("blockquote_open", "blockquote", 1);
  token_o.markup = ">";
  const lines = [startLine, 0];
  token_o.map = lines;
  state.md.block.tokenize(state, startLine, nextLine);
  const token_c = state.push("blockquote_close", "blockquote", -1);
  token_c.markup = ">";
  state.lineMax = oldLineMax;
  state.parentType = oldParentType;
  lines[1] = state.line;
  for (let i = 0;i < oldTShift.length; i++) {
    state.bMarks[i + startLine] = oldBMarks[i];
    state.tShift[i + startLine] = oldTShift[i];
    state.sCount[i + startLine] = oldSCount[i];
    state.bsCount[i + startLine] = oldBSCount[i];
  }
  state.blkIndent = oldIndent;
  return true;
}
function hr(state, startLine, endLine, silent) {
  const max = state.eMarks[startLine];
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  let pos = state.bMarks[startLine] + state.tShift[startLine];
  const marker = state.src.charCodeAt(pos++);
  if (marker !== 42 && marker !== 45 && marker !== 95)
    return false;
  let cnt = 1;
  while (pos < max) {
    const ch = state.src.charCodeAt(pos++);
    if (ch !== marker && !isSpace(ch))
      return false;
    if (ch === marker)
      cnt++;
  }
  if (cnt < 3)
    return false;
  if (silent)
    return true;
  state.line = startLine + 1;
  const token = state.push("hr", "hr", 0);
  token.map = [startLine, state.line];
  token.markup = Array(cnt + 1).join(String.fromCharCode(marker));
  return true;
}
function skipBulletListMarker(state, startLine) {
  const max = state.eMarks[startLine];
  let pos = state.bMarks[startLine] + state.tShift[startLine];
  const marker = state.src.charCodeAt(pos++);
  if (marker !== 42 && marker !== 45 && marker !== 43)
    return -1;
  if (pos < max) {
    if (!isSpace(state.src.charCodeAt(pos)))
      return -1;
  }
  return pos;
}
function skipOrderedListMarker(state, startLine) {
  const start = state.bMarks[startLine] + state.tShift[startLine];
  const max = state.eMarks[startLine];
  let pos = start;
  if (pos + 1 >= max)
    return -1;
  let ch = state.src.charCodeAt(pos++);
  if (ch < 48 || ch > 57)
    return -1;
  for (;; ) {
    if (pos >= max)
      return -1;
    ch = state.src.charCodeAt(pos++);
    if (ch >= 48 && ch <= 57) {
      if (pos - start >= 10)
        return -1;
      continue;
    }
    if (ch === 41 || ch === 46)
      break;
    return -1;
  }
  if (pos < max) {
    ch = state.src.charCodeAt(pos);
    if (!isSpace(ch))
      return -1;
  }
  return pos;
}
function markTightParagraphs(state, idx) {
  const level = state.level + 2;
  for (let i = idx + 2, l = state.tokens.length - 2;i < l; i++)
    if (state.tokens[i].level === level && state.tokens[i].type === "paragraph_open") {
      state.tokens[i + 2].hidden = true;
      state.tokens[i].hidden = true;
      i += 2;
    }
}
function list(state, startLine, endLine, silent) {
  let max, pos, start, token;
  let nextLine = startLine;
  let tight = true;
  if (state.sCount[nextLine] - state.blkIndent >= 4)
    return false;
  if (state.listIndent >= 0 && state.sCount[nextLine] - state.listIndent >= 4 && state.sCount[nextLine] < state.blkIndent)
    return false;
  let isTerminatingParagraph = false;
  if (silent && state.parentType === "paragraph") {
    if (state.sCount[nextLine] >= state.blkIndent)
      isTerminatingParagraph = true;
  }
  let isOrdered;
  let markerValue;
  let posAfterMarker;
  if ((posAfterMarker = skipOrderedListMarker(state, nextLine)) >= 0) {
    isOrdered = true;
    start = state.bMarks[nextLine] + state.tShift[nextLine];
    markerValue = Number(state.src.slice(start, posAfterMarker - 1));
    if (isTerminatingParagraph && markerValue !== 1)
      return false;
  } else if ((posAfterMarker = skipBulletListMarker(state, nextLine)) >= 0)
    isOrdered = false;
  else
    return false;
  if (isTerminatingParagraph) {
    if (state.skipSpaces(posAfterMarker) >= state.eMarks[nextLine])
      return false;
  }
  if (silent)
    return true;
  const markerCharCode = state.src.charCodeAt(posAfterMarker - 1);
  const listTokIdx = state.tokens.length;
  if (isOrdered) {
    token = state.push("ordered_list_open", "ol", 1);
    if (markerValue !== 1)
      token.attrs = [["start", markerValue]];
  } else
    token = state.push("bullet_list_open", "ul", 1);
  const listLines = [nextLine, 0];
  token.map = listLines;
  token.markup = String.fromCharCode(markerCharCode);
  let prevEmptyEnd = false;
  const terminatorRules = state.md.block.ruler.getRules("list");
  const oldParentType = state.parentType;
  state.parentType = "list";
  while (nextLine < endLine) {
    pos = posAfterMarker;
    max = state.eMarks[nextLine];
    const initial = state.sCount[nextLine] + posAfterMarker - (state.bMarks[nextLine] + state.tShift[nextLine]);
    let offset = initial;
    while (pos < max) {
      const ch = state.src.charCodeAt(pos);
      if (ch === 9)
        offset += 4 - (offset + state.bsCount[nextLine]) % 4;
      else if (ch === 32)
        offset++;
      else
        break;
      pos++;
    }
    const contentStart = pos;
    let indentAfterMarker;
    if (contentStart >= max)
      indentAfterMarker = 1;
    else
      indentAfterMarker = offset - initial;
    if (indentAfterMarker > 4)
      indentAfterMarker = 1;
    const indent = initial + indentAfterMarker;
    token = state.push("list_item_open", "li", 1);
    token.markup = String.fromCharCode(markerCharCode);
    const itemLines = [nextLine, 0];
    token.map = itemLines;
    if (isOrdered)
      token.info = state.src.slice(start, posAfterMarker - 1);
    const oldTight = state.tight;
    const oldTShift = state.tShift[nextLine];
    const oldSCount = state.sCount[nextLine];
    const oldListIndent = state.listIndent;
    state.listIndent = state.blkIndent;
    state.blkIndent = indent;
    state.tight = true;
    state.tShift[nextLine] = contentStart - state.bMarks[nextLine];
    state.sCount[nextLine] = offset;
    if (contentStart >= max && state.isEmpty(nextLine + 1))
      state.line = Math.min(state.line + 2, endLine);
    else
      state.md.block.tokenize(state, nextLine, endLine);
    if (!state.tight || prevEmptyEnd)
      tight = false;
    prevEmptyEnd = state.line - nextLine > 1 && state.isEmpty(state.line - 1);
    state.blkIndent = state.listIndent;
    state.listIndent = oldListIndent;
    state.tShift[nextLine] = oldTShift;
    state.sCount[nextLine] = oldSCount;
    state.tight = oldTight;
    token = state.push("list_item_close", "li", -1);
    token.markup = String.fromCharCode(markerCharCode);
    nextLine = state.line;
    itemLines[1] = nextLine;
    if (nextLine >= endLine)
      break;
    if (state.sCount[nextLine] < state.blkIndent)
      break;
    if (state.sCount[nextLine] - state.blkIndent >= 4)
      break;
    let terminate = false;
    for (let i = 0, l = terminatorRules.length;i < l; i++)
      if (terminatorRules[i](state, nextLine, endLine, true)) {
        terminate = true;
        break;
      }
    if (terminate)
      break;
    if (isOrdered) {
      posAfterMarker = skipOrderedListMarker(state, nextLine);
      if (posAfterMarker < 0)
        break;
      start = state.bMarks[nextLine] + state.tShift[nextLine];
    } else {
      posAfterMarker = skipBulletListMarker(state, nextLine);
      if (posAfterMarker < 0)
        break;
    }
    if (markerCharCode !== state.src.charCodeAt(posAfterMarker - 1))
      break;
  }
  if (isOrdered)
    token = state.push("ordered_list_close", "ol", -1);
  else
    token = state.push("bullet_list_close", "ul", -1);
  token.markup = String.fromCharCode(markerCharCode);
  listLines[1] = nextLine;
  state.line = nextLine;
  state.parentType = oldParentType;
  if (tight)
    markTightParagraphs(state, listTokIdx);
  return true;
}
var MAX_LABEL_LENGTH = 999;
function countCodePoints(str) {
  let length = str.length;
  for (let i = 0;i < str.length - 1; i++) {
    const high = str.charCodeAt(i);
    if (high < 55296 || high > 56319)
      continue;
    const low = str.charCodeAt(i + 1);
    if (low >= 56320 && low <= 57343) {
      length--;
      i++;
    }
  }
  return length;
}
function lineEnd(state, line) {
  return Math.min(state.eMarks[line] + 1, state.src.length);
}
function getNextLinePos(state, nextLine) {
  const endLine = state.lineMax;
  if (nextLine >= endLine || state.isEmpty(nextLine))
    return -1;
  let isContinuation = false;
  if (state.sCount[nextLine] - state.blkIndent > 3)
    isContinuation = true;
  if (state.sCount[nextLine] < 0)
    isContinuation = true;
  if (!isContinuation) {
    const terminatorRules = state.md.block.ruler.getRules("reference");
    const oldParentType = state.parentType;
    state.parentType = "reference";
    let terminate = false;
    for (let i = 0, l = terminatorRules.length;i < l; i++)
      if (terminatorRules[i](state, nextLine, endLine, true)) {
        terminate = true;
        break;
      }
    state.parentType = oldParentType;
    if (terminate)
      return -1;
  }
  return state.bMarks[nextLine] + state.tShift[nextLine];
}
function reference(state, startLine, _endLine, silent) {
  const src = state.src;
  let pos = state.bMarks[startLine] + state.tShift[startLine];
  let nextLine = startLine + 1;
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  if (src.charCodeAt(pos) !== 91)
    return false;
  let max = lineEnd(state, startLine);
  let rawLabel = "";
  let labelEnd = -1;
  let segmentStart = ++pos;
  while (pos < max) {
    if (rawLabel.length + pos - segmentStart > MAX_LABEL_LENGTH * 2)
      return false;
    let ch = src.charCodeAt(pos);
    if (ch === 91)
      return false;
    if (ch === 93) {
      labelEnd = pos;
      break;
    }
    if (ch === 92)
      ch = src.charCodeAt(++pos);
    if (ch === 10 && pos < max) {
      const nextPos = getNextLinePos(state, nextLine);
      if (nextPos < 0)
        return false;
      rawLabel += src.slice(segmentStart, max);
      pos = segmentStart = nextPos;
      max = lineEnd(state, nextLine++);
      continue;
    }
    pos++;
  }
  if (labelEnd < 0 || src.charCodeAt(labelEnd + 1) !== 58)
    return false;
  rawLabel += src.slice(segmentStart, labelEnd);
  if (rawLabel.length > MAX_LABEL_LENGTH && countCodePoints(rawLabel) > MAX_LABEL_LENGTH)
    return false;
  pos = labelEnd + 2;
  while (pos < max) {
    const ch = src.charCodeAt(pos);
    if (ch === 10) {
      const nextPos = getNextLinePos(state, nextLine);
      if (nextPos < 0)
        break;
      pos = nextPos;
      max = lineEnd(state, nextLine++);
    } else if (isSpace(ch))
      pos++;
    else
      break;
  }
  const destRes = state.md.helpers.parseLinkDestination(src, pos, max);
  if (!destRes.ok)
    return false;
  const href = state.md.normalizeLink(destRes.str);
  if (!state.md.validateLink(href))
    return false;
  pos = destRes.pos;
  const destEndPos = pos;
  const destEndMax = max;
  const destEndLineNo = nextLine;
  while (pos < max) {
    const ch = src.charCodeAt(pos);
    if (ch === 10) {
      const nextPos = getNextLinePos(state, nextLine);
      if (nextPos < 0)
        break;
      pos = nextPos;
      max = lineEnd(state, nextLine++);
    } else if (isSpace(ch))
      pos++;
    else
      break;
  }
  const titleStart = pos;
  let titleRes = state.md.helpers.parseLinkTitle(src, pos, max);
  while (titleRes.can_continue) {
    const nextPos = getNextLinePos(state, nextLine);
    if (nextPos < 0)
      break;
    pos = nextPos;
    max = lineEnd(state, nextLine++);
    titleRes = state.md.helpers.parseLinkTitle(src, pos, max, titleRes);
  }
  let title;
  if (titleStart !== destEndPos && titleRes.ok) {
    title = titleRes.str;
    pos = titleRes.pos;
  } else {
    title = "";
    pos = destEndPos;
    max = destEndMax;
    nextLine = destEndLineNo;
  }
  while (pos < max) {
    if (!isSpace(src.charCodeAt(pos)))
      break;
    pos++;
  }
  if (pos < max && src.charCodeAt(pos) !== 10) {
    if (title) {
      title = "";
      pos = destEndPos;
      max = destEndMax;
      nextLine = destEndLineNo;
      while (pos < max) {
        if (!isSpace(src.charCodeAt(pos)))
          break;
        pos++;
      }
    }
  }
  if (pos < max && src.charCodeAt(pos) !== 10)
    return false;
  const label = normalizeReference(rawLabel);
  if (!label)
    return false;
  if (silent)
    return true;
  if (typeof state.env.references === "undefined")
    state.env.references = {};
  if (typeof state.env.references[label] === "undefined")
    state.env.references[label] = {
      title,
      href
    };
  const token = state.push("reference_definition", "", 0);
  token.map = [startLine, nextLine];
  token.hidden = true;
  const meta = Object.create(null);
  meta.label = label;
  token.meta = meta;
  state.line = nextLine;
  return true;
}
var html_blocks_default = [
  "address",
  "article",
  "aside",
  "base",
  "basefont",
  "blockquote",
  "body",
  "caption",
  "center",
  "col",
  "colgroup",
  "dd",
  "details",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hr",
  "html",
  "iframe",
  "legend",
  "li",
  "link",
  "main",
  "menu",
  "menuitem",
  "nav",
  "noframes",
  "ol",
  "optgroup",
  "option",
  "p",
  "param",
  "search",
  "section",
  "summary",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "title",
  "tr",
  "track",
  "ul"
];
var open_tag = `<[A-Za-z][A-Za-z0-9\\-]*(?:\\s+[a-zA-Z_:][a-zA-Z0-9:._-]*(?:\\s*=\\s*(?:[^"'=<>\`\\x00-\\x20]+|'[^']*'|"[^"]*"))?)*\\s*\\/?>`;
var close_tag = "<\\/[A-Za-z][A-Za-z0-9\\-]*\\s*>";
new RegExp(`^(?:${open_tag}|${close_tag}|<!---?>|<!--(?:[^-]|-[^-]|--[^>])*-->|<[?][\\s\\S]*?[?]>|<![A-Za-z][^>]*>|<!\\[CDATA\\[[\\s\\S]*?\\]\\]>)`);
var HTML_OPEN_CLOSE_TAG_RE = new RegExp(`^(?:${open_tag}|${close_tag})`);
var HTML_SEQUENCES = [
  [
    /^<(script|pre|style|textarea)(?=(\s|>|$))/i,
    /<\/(script|pre|style|textarea)>/i,
    true
  ],
  [
    /^<!--/,
    /-->/,
    true
  ],
  [
    /^<\?/,
    /\?>/,
    true
  ],
  [
    /^<![A-Za-z]/,
    />/,
    true
  ],
  [
    /^<!\[CDATA\[/,
    /\]\]>/,
    true
  ],
  [
    new RegExp(`^</?(${html_blocks_default.join("|")})(?=(\\s|/?>|$))`, "i"),
    /^$/,
    true
  ],
  [
    new RegExp(`${HTML_OPEN_CLOSE_TAG_RE.source}\\s*$`),
    /^$/,
    false
  ]
];
function html_block(state, startLine, endLine, silent) {
  let pos = state.bMarks[startLine] + state.tShift[startLine];
  let max = state.eMarks[startLine];
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  if (!state.md.options.html)
    return false;
  if (state.src.charCodeAt(pos) !== 60)
    return false;
  let lineText = state.src.slice(pos, max);
  let i = 0;
  for (;i < HTML_SEQUENCES.length; i++)
    if (HTML_SEQUENCES[i][0].test(lineText))
      break;
  if (i === HTML_SEQUENCES.length)
    return false;
  if (silent)
    return HTML_SEQUENCES[i][2];
  let nextLine = startLine + 1;
  const endsOnBlankLine = HTML_SEQUENCES[i][1].test("");
  if (!HTML_SEQUENCES[i][1].test(lineText))
    for (;nextLine < endLine; nextLine++) {
      if (state.sCount[nextLine] < state.blkIndent) {
        if (endsOnBlankLine || !state.isEmpty(nextLine))
          break;
      }
      pos = state.bMarks[nextLine] + state.tShift[nextLine];
      max = state.eMarks[nextLine];
      lineText = state.src.slice(pos, max);
      if (HTML_SEQUENCES[i][1].test(lineText)) {
        if (lineText.length !== 0)
          nextLine++;
        break;
      }
    }
  state.line = nextLine;
  const token = state.push("html_block", "", 0);
  token.map = [startLine, nextLine];
  token.content = state.getLines(startLine, nextLine, state.blkIndent, true);
  return true;
}
function heading(state, startLine, endLine, silent) {
  let pos = state.bMarks[startLine] + state.tShift[startLine];
  let max = state.eMarks[startLine];
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  let ch = state.src.charCodeAt(pos);
  if (ch !== 35 || pos >= max)
    return false;
  let level = 1;
  ch = state.src.charCodeAt(++pos);
  while (ch === 35 && pos < max && level <= 6) {
    level++;
    ch = state.src.charCodeAt(++pos);
  }
  if (level > 6 || pos < max && !isSpace(ch))
    return false;
  if (silent)
    return true;
  max = state.skipSpacesBack(max, pos);
  const tmp = state.skipCharsBack(max, 35, pos);
  if (tmp > pos && isSpace(state.src.charCodeAt(tmp - 1)))
    max = tmp;
  state.line = startLine + 1;
  const token_o = state.push("heading_open", `h${level}`, 1);
  token_o.markup = "########".slice(0, level);
  token_o.map = [startLine, state.line];
  const token_i = state.push("inline", "", 0);
  token_i.content = asciiTrim(state.src.slice(pos, max));
  token_i.map = [startLine, state.line];
  token_i.children = [];
  const token_c = state.push("heading_close", `h${level}`, -1);
  token_c.markup = "########".slice(0, level);
  return true;
}
function lheading(state, startLine, endLine) {
  const terminatorRules = state.md.block.ruler.getRules("paragraph");
  if (state.sCount[startLine] - state.blkIndent >= 4)
    return false;
  const oldParentType = state.parentType;
  state.parentType = "paragraph";
  let level = 0;
  let marker;
  let nextLine = startLine + 1;
  for (;nextLine < endLine && !state.isEmpty(nextLine); nextLine++) {
    if (state.sCount[nextLine] - state.blkIndent > 3)
      continue;
    if (state.sCount[nextLine] >= state.blkIndent) {
      let pos = state.bMarks[nextLine] + state.tShift[nextLine];
      const max = state.eMarks[nextLine];
      if (pos < max) {
        marker = state.src.charCodeAt(pos);
        if (marker === 45 || marker === 61) {
          pos = state.skipChars(pos, marker);
          pos = state.skipSpaces(pos);
          if (pos >= max) {
            level = marker === 61 ? 1 : 2;
            break;
          }
        }
      }
    }
    if (state.sCount[nextLine] < 0)
      continue;
    let terminate = false;
    for (let i = 0, l = terminatorRules.length;i < l; i++)
      if (terminatorRules[i](state, nextLine, endLine, true)) {
        terminate = true;
        break;
      }
    if (terminate)
      break;
  }
  if (!level) {
    state.parentType = oldParentType;
    return false;
  }
  const content = asciiTrim(state.getLines(startLine, nextLine, state.blkIndent, false));
  state.line = nextLine + 1;
  const token_o = state.push("heading_open", `h${level}`, 1);
  token_o.markup = String.fromCharCode(marker);
  token_o.map = [startLine, state.line];
  const token_i = state.push("inline", "", 0);
  token_i.content = content;
  token_i.map = [startLine, state.line - 1];
  token_i.children = [];
  const token_c = state.push("heading_close", `h${level}`, -1);
  token_c.markup = String.fromCharCode(marker);
  state.parentType = oldParentType;
  return true;
}
function paragraph(state, startLine, endLine) {
  const terminatorRules = state.md.block.ruler.getRules("paragraph");
  const oldParentType = state.parentType;
  let nextLine = startLine + 1;
  state.parentType = "paragraph";
  for (;nextLine < endLine && !state.isEmpty(nextLine); nextLine++) {
    if (state.sCount[nextLine] - state.blkIndent > 3)
      continue;
    if (state.sCount[nextLine] < 0)
      continue;
    let terminate = false;
    for (let i = 0, l = terminatorRules.length;i < l; i++)
      if (terminatorRules[i](state, nextLine, endLine, true)) {
        terminate = true;
        break;
      }
    if (terminate)
      break;
  }
  const content = asciiTrim(state.getLines(startLine, nextLine, state.blkIndent, false));
  state.line = nextLine;
  const token_o = state.push("paragraph_open", "p", 1);
  token_o.map = [startLine, state.line];
  const token_i = state.push("inline", "", 0);
  token_i.content = content;
  token_i.map = [startLine, state.line];
  token_i.children = [];
  state.push("paragraph_close", "p", -1);
  state.parentType = oldParentType;
  return true;
}
var _rules$1 = [
  [
    "table",
    table,
    ["paragraph", "reference"]
  ],
  ["code", code],
  [
    "fence",
    fence,
    [
      "paragraph",
      "reference",
      "blockquote",
      "list"
    ]
  ],
  [
    "blockquote",
    blockquote,
    [
      "paragraph",
      "reference",
      "blockquote",
      "list"
    ]
  ],
  [
    "hr",
    hr,
    [
      "paragraph",
      "reference",
      "blockquote",
      "list"
    ]
  ],
  [
    "list",
    list,
    [
      "paragraph",
      "reference",
      "blockquote"
    ]
  ],
  ["reference", reference],
  [
    "html_block",
    html_block,
    [
      "paragraph",
      "reference",
      "blockquote"
    ]
  ],
  [
    "heading",
    heading,
    [
      "paragraph",
      "reference",
      "blockquote"
    ]
  ],
  ["lheading", lheading],
  ["paragraph", paragraph]
];
var ParserBlock = class {
  constructor() {
    _defineProperty(this, "ruler", new Ruler);
    _defineProperty(this, "State", StateBlock);
    for (let i = 0;i < _rules$1.length; i++)
      this.ruler.push(_rules$1[i][0], _rules$1[i][1], { alt: (_rules$1[i][2] || []).slice() });
  }
  tokenize(state, startLine, endLine) {
    const rules = this.ruler.getRules("");
    const len = rules.length;
    const maxNesting = state.md.options.maxNesting;
    let line = startLine;
    let hasEmptyLines = false;
    while (line < endLine) {
      state.line = line = state.skipEmptyLines(line);
      if (line >= endLine)
        break;
      if (state.sCount[line] < state.blkIndent)
        break;
      if (state.level >= maxNesting) {
        state.line = endLine;
        break;
      }
      const prevLine = state.line;
      let ok = false;
      for (let i = 0;i < len; i++) {
        ok = rules[i](state, line, endLine, false);
        if (ok) {
          if (prevLine >= state.line)
            throw new Error("block rule didn't increment state.line");
          break;
        }
      }
      if (!ok)
        throw new Error("none of the block rules matched");
      state.tight = !hasEmptyLines;
      if (state.isEmpty(state.line - 1))
        hasEmptyLines = true;
      line = state.line;
      if (line < endLine && state.isEmpty(line)) {
        hasEmptyLines = true;
        line++;
        state.line = line;
      }
    }
  }
  parse(src, md, env, outTokens) {
    if (!src)
      return;
    const state = new this.State(src, md, env, outTokens);
    this.tokenize(state, state.line, state.lineMax);
  }
};
var StateInline = class {
  constructor(src, md, env, outTokens) {
    _defineProperty(this, "pos", 0);
    _defineProperty(this, "level", 0);
    _defineProperty(this, "pending", "");
    _defineProperty(this, "pendingLevel", 0);
    _defineProperty(this, "cache", {});
    _defineProperty(this, "backticks", {});
    _defineProperty(this, "backticksScanned", false);
    _defineProperty(this, "skipHtmlSpecial", false);
    _defineProperty(this, "linkLevel", 0);
    _defineProperty(this, "delimiters", []);
    _defineProperty(this, "_prev_delimiters", []);
    _defineProperty(this, "Token", Token);
    this.src = src;
    this.env = env;
    this.md = md;
    this.tokens = outTokens;
    this.tokens_meta = Array(outTokens.length);
    this.posMax = this.src.length;
  }
  pushPending() {
    const token = new Token("text", "", 0);
    token.content = this.pending;
    token.level = this.pendingLevel;
    this.tokens.push(token);
    this.pending = "";
    return token;
  }
  push(type, tag, nesting) {
    if (this.pending)
      this.pushPending();
    const token = new Token(type, tag, nesting);
    let token_meta = undefined;
    if (nesting < 0) {
      this.level--;
      this.delimiters = this._prev_delimiters.pop();
    }
    token.level = this.level;
    if (nesting > 0) {
      this.level++;
      this._prev_delimiters.push(this.delimiters);
      this.delimiters = [];
      token_meta = { delimiters: this.delimiters };
    }
    this.pendingLevel = this.level;
    this.tokens.push(token);
    this.tokens_meta.push(token_meta);
    return token;
  }
  scanDelims(start, canSplitWord) {
    const max = this.posMax;
    const marker = this.src.charCodeAt(start);
    let lastChar;
    if (start === 0)
      lastChar = 32;
    else if (start === 1) {
      lastChar = this.src.charCodeAt(0);
      if ((lastChar & 63488) === 55296)
        lastChar = 65533;
    } else {
      lastChar = this.src.charCodeAt(start - 1);
      if ((lastChar & 64512) === 56320) {
        const highSurr = this.src.charCodeAt(start - 2);
        lastChar = (highSurr & 64512) === 55296 ? 65536 + (highSurr - 55296 << 10) + (lastChar - 56320) : 65533;
      } else if ((lastChar & 64512) === 55296)
        lastChar = 65533;
    }
    let pos = start;
    while (pos < max && this.src.charCodeAt(pos) === marker)
      pos++;
    const count = pos - start;
    let nextChar = pos < max ? this.src.charCodeAt(pos) : 32;
    if ((nextChar & 64512) === 55296) {
      const lowSurr = this.src.charCodeAt(pos + 1);
      nextChar = (lowSurr & 64512) === 56320 ? 65536 + (nextChar - 55296 << 10) + (lowSurr - 56320) : 65533;
    } else if ((nextChar & 64512) === 56320)
      nextChar = 65533;
    const isLastPunctChar = isMdAsciiPunct(lastChar) || isPunctCharCode(lastChar);
    const isNextPunctChar = isMdAsciiPunct(nextChar) || isPunctCharCode(nextChar);
    const isLastWhiteSpace = isWhiteSpace(lastChar);
    const isNextWhiteSpace = isWhiteSpace(nextChar);
    const left_flanking = !isNextWhiteSpace && (!isNextPunctChar || isLastWhiteSpace || isLastPunctChar);
    const right_flanking = !isLastWhiteSpace && (!isLastPunctChar || isNextWhiteSpace || isNextPunctChar);
    return {
      can_open: left_flanking && (canSplitWord || !right_flanking || isLastPunctChar),
      can_close: right_flanking && (canSplitWord || !left_flanking || isNextPunctChar),
      length: count
    };
  }
};
function isTerminatorChar(ch) {
  switch (ch) {
    case 10:
    case 33:
    case 35:
    case 36:
    case 37:
    case 38:
    case 42:
    case 43:
    case 45:
    case 58:
    case 60:
    case 61:
    case 62:
    case 64:
    case 91:
    case 92:
    case 93:
    case 94:
    case 95:
    case 96:
    case 123:
    case 125:
    case 126:
      return true;
    default:
      return false;
  }
}
function text(state, silent) {
  let pos = state.pos;
  while (pos < state.posMax && !isTerminatorChar(state.src.charCodeAt(pos)))
    pos++;
  if (pos === state.pos)
    return false;
  if (!silent)
    state.pending += state.src.slice(state.pos, pos);
  state.pos = pos;
  return true;
}
function isAsciiAlpha(code) {
  return code >= 65 && code <= 90 || code >= 97 && code <= 122;
}
function isSchemeChar(code) {
  return code >= 65 && code <= 90 || code >= 97 && code <= 122 || code >= 48 && code <= 57 || code === 43 || code === 45 || code === 46;
}
function linkify(state, silent) {
  if (!state.md.options.linkify)
    return false;
  if (state.linkLevel > 0)
    return false;
  const pos = state.pos;
  const max = state.posMax;
  if (pos + 3 > max)
    return false;
  if (state.src.charCodeAt(pos) !== 58)
    return false;
  if (state.src.charCodeAt(pos + 1) !== 47)
    return false;
  if (state.src.charCodeAt(pos + 2) !== 47)
    return false;
  const protoMin = pos - Math.min(10, state.pending.length, pos);
  let protoStart = pos;
  while (protoStart > protoMin && isSchemeChar(state.src.charCodeAt(protoStart - 1)))
    protoStart--;
  if (protoStart === pos || !isAsciiAlpha(state.src.charCodeAt(protoStart)))
    return false;
  const protoLength = pos - protoStart;
  const link = state.md.linkify.matchAtStart(state.src.slice(protoStart));
  if (!link)
    return false;
  let url = link.url;
  if (url.length <= protoLength)
    return false;
  let urlEnd = url.length;
  while (urlEnd > 0 && url.charCodeAt(urlEnd - 1) === 42)
    urlEnd--;
  if (urlEnd !== url.length)
    url = url.slice(0, urlEnd);
  const fullUrl = state.md.normalizeLink(url);
  if (!state.md.validateLink(fullUrl))
    return false;
  if (!silent) {
    state.pending = state.pending.slice(0, -protoLength);
    const token_o = state.push("link_open", "a", 1);
    token_o.attrs = [["href", fullUrl]];
    token_o.markup = "linkify";
    token_o.info = "auto";
    const token_t = state.push("text", "", 0);
    token_t.content = state.md.normalizeLinkText(url);
    const token_c = state.push("link_close", "a", -1);
    token_c.markup = "linkify";
    token_c.info = "auto";
  }
  state.pos += url.length - protoLength;
  return true;
}
function newline(state, silent) {
  let pos = state.pos;
  if (state.src.charCodeAt(pos) !== 10)
    return false;
  const pmax = state.pending.length - 1;
  const max = state.posMax;
  if (!silent) {
    if (pmax >= 0 && state.pending.charCodeAt(pmax) === 32) {
      if (pmax >= 1 && state.pending.charCodeAt(pmax - 1) === 32) {
        let ws = pmax - 1;
        while (ws >= 1 && state.pending.charCodeAt(ws - 1) === 32)
          ws--;
        state.pending = state.pending.slice(0, ws);
        state.push("hardbreak", "br", 0);
      } else {
        state.pending = state.pending.slice(0, -1);
        state.push("softbreak", "br", 0);
      }
    } else
      state.push("softbreak", "br", 0);
  }
  pos++;
  while (pos < max && isSpace(state.src.charCodeAt(pos)))
    pos++;
  state.pos = pos;
  return true;
}
var ESCAPED = [];
for (let i = 0;i < 256; i++)
  ESCAPED.push(0);
"\\!\"#$%&'()*+,./:;<=>?@[]^_`{|}~-".split("").forEach(function(ch) {
  ESCAPED[ch.charCodeAt(0)] = 1;
});
function escape(state, silent) {
  let pos = state.pos;
  const max = state.posMax;
  if (state.src.charCodeAt(pos) !== 92)
    return false;
  pos++;
  if (pos >= max)
    return false;
  let ch1 = state.src.charCodeAt(pos);
  if (ch1 === 10) {
    if (!silent)
      state.push("hardbreak", "br", 0);
    pos++;
    while (pos < max) {
      ch1 = state.src.charCodeAt(pos);
      if (!isSpace(ch1))
        break;
      pos++;
    }
    state.pos = pos;
    return true;
  }
  if (ch1 === 32) {
    if (!silent) {
      const token = state.push("text_special", "", 0);
      token.content = "\\";
      token.markup = "\\";
      token.info = "escape";
    }
    state.pos = pos;
    return true;
  }
  let escapedStr = state.src[pos];
  if (ch1 >= 55296 && ch1 <= 56319 && pos + 1 < max) {
    const ch2 = state.src.charCodeAt(pos + 1);
    if (ch2 >= 56320 && ch2 <= 57343) {
      escapedStr += state.src[pos + 1];
      pos++;
    }
  }
  const origStr = "\\" + escapedStr;
  if (!silent) {
    const token = state.push("text_special", "", 0);
    if (ch1 < 256 && ESCAPED[ch1] !== 0)
      token.content = escapedStr;
    else
      token.content = origStr;
    token.markup = origStr;
    token.info = "escape";
  }
  state.pos = pos + 1;
  return true;
}
function buildLastRuns(src) {
  const lastRuns = {};
  let pos = 0;
  while ((pos = src.indexOf("`", pos)) !== -1) {
    const start = pos;
    while (src.charCodeAt(++pos) === 96)
      ;
    lastRuns[pos - start] = start;
  }
  return lastRuns;
}
function backtick(state, silent) {
  var _state$backticks$open;
  const start = state.pos;
  if (state.src.charCodeAt(start) !== 96)
    return false;
  const max = state.posMax;
  let pos = start + 1;
  while (pos < max && state.src.charCodeAt(pos) === 96)
    pos++;
  const marker = state.src.slice(start, pos);
  const openerLength = marker.length;
  if (!state.backticksScanned) {
    state.backticks = buildLastRuns(state.src);
    state.backticksScanned = true;
  }
  if (((_state$backticks$open = state.backticks[openerLength]) !== null && _state$backticks$open !== undefined ? _state$backticks$open : -1) >= pos) {
    let matchEnd = pos;
    let matchStart;
    while ((matchStart = state.src.indexOf("`", matchEnd)) !== -1 && matchStart < max) {
      matchEnd = matchStart + 1;
      while (state.src.charCodeAt(matchEnd) === 96)
        matchEnd++;
      if (matchEnd > max)
        break;
      if (matchEnd - matchStart === openerLength) {
        if (!silent) {
          const token = state.push("code_inline", "code", 0);
          token.markup = marker;
          let content = state.src.slice(pos, matchStart).replace(/\n/g, " ");
          if (content.startsWith(" ") && content.endsWith(" ") && /[^ ]/.test(content))
            content = content.slice(1, -1);
          token.content = content;
        }
        state.pos = matchEnd;
        return true;
      }
    }
  }
  if (!silent)
    state.pending += marker;
  state.pos = pos;
  return true;
}
function strikethrough_tokenize(state, silent) {
  const start = state.pos;
  const marker = state.src.charCodeAt(start);
  if (silent)
    return false;
  if (marker !== 126)
    return false;
  const scanned = state.scanDelims(state.pos, true);
  let len = scanned.length;
  const ch = String.fromCharCode(marker);
  if (len < 2)
    return false;
  let token;
  if (len % 2) {
    token = state.push("text", "", 0);
    token.content = ch;
    len--;
  }
  for (let i = 0;i < len; i += 2) {
    token = state.push("text", "", 0);
    token.content = ch + ch;
    state.delimiters.push({
      marker,
      length: 0,
      token: state.tokens.length - 1,
      end: -1,
      open: scanned.can_open,
      close: scanned.can_close
    });
  }
  state.pos += scanned.length;
  return true;
}
function postProcess$1(state, delimiters) {
  let token;
  const loneMarkers = [];
  const max = delimiters.length;
  for (let i = 0;i < max; i++) {
    const startDelim = delimiters[i];
    if (startDelim.marker !== 126)
      continue;
    if (startDelim.end === -1)
      continue;
    const endDelim = delimiters[startDelim.end];
    token = state.tokens[startDelim.token];
    token.type = "s_open";
    token.tag = "s";
    token.nesting = 1;
    token.markup = "~~";
    token.content = "";
    token = state.tokens[endDelim.token];
    token.type = "s_close";
    token.tag = "s";
    token.nesting = -1;
    token.markup = "~~";
    token.content = "";
    if (state.tokens[endDelim.token - 1].type === "text" && state.tokens[endDelim.token - 1].content === "~")
      loneMarkers.push(endDelim.token - 1);
  }
  while (loneMarkers.length) {
    const i = loneMarkers.pop();
    let j = i + 1;
    while (j < state.tokens.length && state.tokens[j].type === "s_close")
      j++;
    j--;
    if (i !== j) {
      token = state.tokens[j];
      state.tokens[j] = state.tokens[i];
      state.tokens[i] = token;
    }
  }
}
function strikethrough_postProcess(state) {
  const tokens_meta = state.tokens_meta;
  const max = state.tokens_meta.length;
  postProcess$1(state, state.delimiters);
  for (let curr = 0;curr < max; curr++) {
    var _tokens_meta$curr;
    const delimiters = (_tokens_meta$curr = tokens_meta[curr]) === null || _tokens_meta$curr === undefined ? undefined : _tokens_meta$curr.delimiters;
    if (delimiters)
      postProcess$1(state, delimiters);
  }
}
var strikethrough_default = {
  tokenize: strikethrough_tokenize,
  postProcess: strikethrough_postProcess
};
function emphasis_tokenize(state, silent) {
  const start = state.pos;
  const marker = state.src.charCodeAt(start);
  if (silent)
    return false;
  if (marker !== 95 && marker !== 42)
    return false;
  const scanned = state.scanDelims(state.pos, marker === 42);
  for (let i = 0;i < scanned.length; i++) {
    const token = state.push("text", "", 0);
    token.content = String.fromCharCode(marker);
    state.delimiters.push({
      marker,
      length: scanned.length,
      token: state.tokens.length - 1,
      end: -1,
      open: scanned.can_open,
      close: scanned.can_close
    });
  }
  state.pos += scanned.length;
  return true;
}
function postProcess(state, delimiters) {
  const max = delimiters.length;
  for (let i = max - 1;i >= 0; i--) {
    const startDelim = delimiters[i];
    if (startDelim.marker !== 95 && startDelim.marker !== 42)
      continue;
    if (startDelim.end === -1)
      continue;
    const endDelim = delimiters[startDelim.end];
    const isStrong = i > 0 && delimiters[i - 1].end === startDelim.end + 1 && delimiters[i - 1].marker === startDelim.marker && delimiters[i - 1].token === startDelim.token - 1 && delimiters[startDelim.end + 1].token === endDelim.token + 1;
    const ch = String.fromCharCode(startDelim.marker);
    const token_o = state.tokens[startDelim.token];
    token_o.type = isStrong ? "strong_open" : "em_open";
    token_o.tag = isStrong ? "strong" : "em";
    token_o.nesting = 1;
    token_o.markup = isStrong ? ch + ch : ch;
    token_o.content = "";
    const token_c = state.tokens[endDelim.token];
    token_c.type = isStrong ? "strong_close" : "em_close";
    token_c.tag = isStrong ? "strong" : "em";
    token_c.nesting = -1;
    token_c.markup = isStrong ? ch + ch : ch;
    token_c.content = "";
    if (isStrong) {
      state.tokens[delimiters[i - 1].token].content = "";
      state.tokens[delimiters[startDelim.end + 1].token].content = "";
      i--;
    }
  }
}
function emphasis_post_process(state) {
  const tokens_meta = state.tokens_meta;
  const max = state.tokens_meta.length;
  postProcess(state, state.delimiters);
  for (let curr = 0;curr < max; curr++) {
    var _tokens_meta$curr;
    const delimiters = (_tokens_meta$curr = tokens_meta[curr]) === null || _tokens_meta$curr === undefined ? undefined : _tokens_meta$curr.delimiters;
    if (delimiters)
      postProcess(state, delimiters);
  }
}
var emphasis_default = {
  tokenize: emphasis_tokenize,
  postProcess: emphasis_post_process
};
function link(state, silent) {
  let code, label, res, ref;
  let href = "";
  let title = "";
  let start = state.pos;
  let parseReference = true;
  if (state.src.charCodeAt(state.pos) !== 91)
    return false;
  const oldPos = state.pos;
  const max = state.posMax;
  const labelStart = state.pos + 1;
  const labelEnd = state.md.helpers.parseLinkLabel(state, state.pos, true);
  if (labelEnd < 0)
    return false;
  let pos = labelEnd + 1;
  if (pos < max && state.src.charCodeAt(pos) === 40) {
    parseReference = false;
    pos++;
    for (;pos < max; pos++) {
      code = state.src.charCodeAt(pos);
      if (!isSpace(code) && code !== 10)
        break;
    }
    if (pos >= max)
      return false;
    start = pos;
    res = state.md.helpers.parseLinkDestination(state.src, pos, state.posMax);
    if (res.ok) {
      href = state.md.normalizeLink(res.str);
      if (state.md.validateLink(href))
        pos = res.pos;
      else
        href = "";
      start = pos;
      for (;pos < max; pos++) {
        code = state.src.charCodeAt(pos);
        if (!isSpace(code) && code !== 10)
          break;
      }
      res = state.md.helpers.parseLinkTitle(state.src, pos, state.posMax);
      if (pos < max && start !== pos && res.ok) {
        title = res.str;
        pos = res.pos;
        for (;pos < max; pos++) {
          code = state.src.charCodeAt(pos);
          if (!isSpace(code) && code !== 10)
            break;
        }
      }
    }
    if (pos >= max || state.src.charCodeAt(pos) !== 41)
      parseReference = true;
    pos++;
  }
  if (parseReference) {
    if (typeof state.env.references === "undefined")
      return false;
    if (pos < max && state.src.charCodeAt(pos) === 91) {
      start = pos + 1;
      pos = state.md.helpers.parseLinkLabel(state, pos);
      if (pos >= 0)
        label = state.src.slice(start, pos++);
      else
        pos = labelEnd + 1;
    } else
      pos = labelEnd + 1;
    if (!label)
      label = state.src.slice(labelStart, labelEnd);
    label = normalizeReference(label);
    ref = state.env.references[label];
    if (!ref) {
      state.pos = oldPos;
      return false;
    }
    href = ref.href;
    title = ref.title;
  }
  if (!silent) {
    state.pos = labelStart;
    state.posMax = labelEnd;
    const token_o = state.push("link_open", "a", 1);
    const attrs = [["href", href]];
    token_o.attrs = attrs;
    if (title)
      attrs.push(["title", title]);
    if (label) {
      const meta = Object.create(null);
      meta.label = label;
      token_o.meta = meta;
    }
    state.linkLevel++;
    state.md.inline.tokenize(state);
    state.linkLevel--;
    state.push("link_close", "a", -1);
  }
  state.pos = pos;
  state.posMax = max;
  return true;
}
function image(state, silent) {
  let code, content, label, pos, ref, res, title, start;
  let href = "";
  const oldPos = state.pos;
  const max = state.posMax;
  if (state.src.charCodeAt(state.pos) !== 33)
    return false;
  if (state.src.charCodeAt(state.pos + 1) !== 91)
    return false;
  const labelStart = state.pos + 2;
  const labelEnd = state.md.helpers.parseLinkLabel(state, state.pos + 1, false);
  if (labelEnd < 0)
    return false;
  pos = labelEnd + 1;
  if (pos < max && state.src.charCodeAt(pos) === 40) {
    pos++;
    for (;pos < max; pos++) {
      code = state.src.charCodeAt(pos);
      if (!isSpace(code) && code !== 10)
        break;
    }
    if (pos >= max)
      return false;
    start = pos;
    res = state.md.helpers.parseLinkDestination(state.src, pos, state.posMax);
    if (res.ok) {
      href = state.md.normalizeLink(res.str);
      if (state.md.validateLink(href))
        pos = res.pos;
      else
        href = "";
    }
    start = pos;
    for (;pos < max; pos++) {
      code = state.src.charCodeAt(pos);
      if (!isSpace(code) && code !== 10)
        break;
    }
    res = state.md.helpers.parseLinkTitle(state.src, pos, state.posMax);
    if (pos < max && start !== pos && res.ok) {
      title = res.str;
      pos = res.pos;
      for (;pos < max; pos++) {
        code = state.src.charCodeAt(pos);
        if (!isSpace(code) && code !== 10)
          break;
      }
    } else
      title = "";
    if (pos >= max || state.src.charCodeAt(pos) !== 41) {
      state.pos = oldPos;
      return false;
    }
    pos++;
  } else {
    if (typeof state.env.references === "undefined")
      return false;
    if (pos < max && state.src.charCodeAt(pos) === 91) {
      start = pos + 1;
      pos = state.md.helpers.parseLinkLabel(state, pos);
      if (pos >= 0)
        label = state.src.slice(start, pos++);
      else
        pos = labelEnd + 1;
    } else
      pos = labelEnd + 1;
    if (!label)
      label = state.src.slice(labelStart, labelEnd);
    label = normalizeReference(label);
    ref = state.env.references[label];
    if (!ref) {
      state.pos = oldPos;
      return false;
    }
    href = ref.href;
    title = ref.title;
  }
  if (!silent) {
    content = state.src.slice(labelStart, labelEnd);
    const tokens = [];
    state.md.inline.parse(content, state.md, state.env, tokens);
    const token = state.push("image", "img", 0);
    const attrs = [["src", href], ["alt", ""]];
    token.attrs = attrs;
    token.children = tokens;
    token.content = content;
    if (title)
      attrs.push(["title", title]);
    if (label) {
      const meta = Object.create(null);
      meta.label = label;
      token.meta = meta;
    }
  }
  state.pos = pos;
  state.posMax = max;
  return true;
}
var EMAIL_RE = /^([a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*)$/;
var AUTOLINK_RE = /^([a-zA-Z][a-zA-Z0-9+.-]{1,31}):([^<>\x00-\x20]*)$/;
function autolink(state, silent) {
  let pos = state.pos;
  if (state.src.charCodeAt(pos) !== 60)
    return false;
  const start = state.pos;
  const max = state.posMax;
  for (;; ) {
    if (++pos >= max)
      return false;
    const ch = state.src.charCodeAt(pos);
    if (ch === 60)
      return false;
    if (ch === 62)
      break;
  }
  const url = state.src.slice(start + 1, pos);
  if (AUTOLINK_RE.test(url)) {
    const fullUrl = state.md.normalizeLink(url);
    if (!state.md.validateLink(fullUrl))
      return false;
    if (!silent) {
      const token_o = state.push("link_open", "a", 1);
      token_o.attrs = [["href", fullUrl]];
      token_o.markup = "autolink";
      token_o.info = "auto";
      const token_t = state.push("text", "", 0);
      token_t.content = state.md.normalizeLinkText(url);
      const token_c = state.push("link_close", "a", -1);
      token_c.markup = "autolink";
      token_c.info = "auto";
    }
    state.pos += url.length + 2;
    return true;
  }
  if (EMAIL_RE.test(url)) {
    const fullUrl = state.md.normalizeLink(`mailto:${url}`);
    if (!state.md.validateLink(fullUrl))
      return false;
    if (!silent) {
      const token_o = state.push("link_open", "a", 1);
      token_o.attrs = [["href", fullUrl]];
      token_o.markup = "autolink";
      token_o.info = "auto";
      const token_t = state.push("text", "", 0);
      token_t.content = state.md.normalizeLinkText(url);
      const token_c = state.push("link_close", "a", -1);
      token_c.markup = "autolink";
      token_c.info = "auto";
    }
    state.pos += url.length + 2;
    return true;
  }
  return false;
}
function isLinkOpen(str) {
  return /^<a[>\s]/i.test(str);
}
function isLinkClose(str) {
  return /^<\/a\s*>/i.test(str);
}
function isLetter(ch) {
  const lc = ch | 32;
  return lc >= 97 && lc <= 122;
}
function scanSpecial(state, pos) {
  const src = state.src;
  let start;
  let terminator;
  if (src.startsWith("<!--", pos)) {
    if (src.startsWith(">", pos + 4))
      return pos + 5;
    if (src.startsWith("->", pos + 4))
      return pos + 6;
    start = pos + 4;
    terminator = "-->";
  } else if (src.startsWith("<![CDATA[", pos)) {
    start = pos + 9;
    terminator = "]]>";
  } else if (src.charCodeAt(pos + 1) === 63) {
    start = pos + 2;
    terminator = "?>";
  } else if (isLetter(src.charCodeAt(pos + 2))) {
    start = pos + 3;
    terminator = ">";
  } else
    return -1;
  if (state.skipHtmlSpecial)
    return -1;
  const end = src.indexOf(terminator, start);
  if (end < 0) {
    state.skipHtmlSpecial = true;
    return -1;
  }
  return end + terminator.length;
}
function html_inline(state, silent) {
  if (!state.md.options.html)
    return false;
  const max = state.posMax;
  const pos = state.pos;
  if (state.src.charCodeAt(pos) !== 60 || pos + 2 >= max)
    return false;
  let end;
  const ch = state.src.charCodeAt(pos + 1);
  if (ch === 33 || ch === 63)
    end = scanSpecial(state, pos);
  else if (ch === 47 || isLetter(ch)) {
    const match = state.src.slice(pos).match(HTML_OPEN_CLOSE_TAG_RE);
    end = match ? pos + match[0].length : -1;
  } else
    return false;
  if (end < 0)
    return false;
  if (!silent) {
    const token = state.push("html_inline", "", 0);
    token.content = state.src.slice(pos, end);
    if (isLinkOpen(token.content))
      state.linkLevel++;
    if (isLinkClose(token.content))
      state.linkLevel--;
  }
  state.pos = end;
  return true;
}
var DIGITAL_RE = /^&#((?:x[a-f0-9]{1,6}|[0-9]{1,7}));/i;
var NAMED_RE = /^&([a-z][a-z0-9]{1,31});/i;
function entity(state, silent) {
  const pos = state.pos;
  const max = state.posMax;
  if (state.src.charCodeAt(pos) !== 38)
    return false;
  if (pos + 1 >= max)
    return false;
  if (state.src.charCodeAt(pos + 1) === 35) {
    const match = state.src.slice(pos).match(DIGITAL_RE);
    if (match) {
      if (!silent) {
        const code = match[1][0].toLowerCase() === "x" ? parseInt(match[1].slice(1), 16) : parseInt(match[1], 10);
        const token = state.push("text_special", "", 0);
        token.content = isValidEntityCode(code) ? fromCodePoint(code) : fromCodePoint(65533);
        token.markup = match[0];
        token.info = "entity";
      }
      state.pos += match[0].length;
      return true;
    }
  } else {
    const match = state.src.slice(pos).match(NAMED_RE);
    if (match) {
      const decoded = decodeHTMLStrict(match[0]);
      if (decoded !== match[0]) {
        if (!silent) {
          const token = state.push("text_special", "", 0);
          token.content = decoded;
          token.markup = match[0];
          token.info = "entity";
        }
        state.pos += match[0].length;
        return true;
      }
    }
  }
  return false;
}
function processDelimiters(delimiters) {
  const openersBottom = {};
  const max = delimiters.length;
  if (!max)
    return;
  let headerIdx = 0;
  let lastTokenIdx = -2;
  const jumps = [];
  for (let closerIdx = 0;closerIdx < max; closerIdx++) {
    const closer = delimiters[closerIdx];
    jumps.push(0);
    if (delimiters[headerIdx].marker !== closer.marker || lastTokenIdx !== closer.token - 1)
      headerIdx = closerIdx;
    lastTokenIdx = closer.token;
    closer.length = closer.length || 0;
    if (!closer.close)
      continue;
    if (!openersBottom.hasOwnProperty(closer.marker))
      openersBottom[closer.marker] = [
        -1,
        -1,
        -1,
        -1,
        -1,
        -1
      ];
    const minOpenerIdx = openersBottom[closer.marker][(closer.open ? 3 : 0) + closer.length % 3];
    let openerIdx = headerIdx - jumps[headerIdx] - 1;
    let newMinOpenerIdx = openerIdx;
    for (;openerIdx > minOpenerIdx; openerIdx -= jumps[openerIdx] + 1) {
      const opener = delimiters[openerIdx];
      if (opener.marker !== closer.marker)
        continue;
      if (opener.open && opener.end < 0) {
        let isOddMatch = false;
        if (opener.close || closer.open) {
          if ((opener.length + closer.length) % 3 === 0) {
            if (opener.length % 3 !== 0 || closer.length % 3 !== 0)
              isOddMatch = true;
          }
        }
        if (!isOddMatch) {
          const lastJump = openerIdx > 0 && !delimiters[openerIdx - 1].open ? jumps[openerIdx - 1] + 1 : 0;
          jumps[closerIdx] = closerIdx - openerIdx + lastJump;
          jumps[openerIdx] = lastJump;
          closer.open = false;
          opener.end = closerIdx;
          opener.close = false;
          newMinOpenerIdx = -1;
          lastTokenIdx = -2;
          break;
        }
      }
    }
    if (newMinOpenerIdx !== -1)
      openersBottom[closer.marker][(closer.open ? 3 : 0) + (closer.length || 0) % 3] = newMinOpenerIdx;
  }
}
function link_pairs(state) {
  const tokens_meta = state.tokens_meta;
  const max = state.tokens_meta.length;
  processDelimiters(state.delimiters);
  for (let curr = 0;curr < max; curr++) {
    var _tokens_meta$curr;
    const delimiters = (_tokens_meta$curr = tokens_meta[curr]) === null || _tokens_meta$curr === undefined ? undefined : _tokens_meta$curr.delimiters;
    if (delimiters)
      processDelimiters(delimiters);
  }
}
function fragments_join(state) {
  let curr, last;
  let level = 0;
  const tokens = state.tokens;
  const max = state.tokens.length;
  for (curr = last = 0;curr < max; curr++) {
    if (tokens[curr].nesting < 0)
      level--;
    tokens[curr].level = level;
    if (tokens[curr].nesting > 0)
      level++;
    if (tokens[curr].type === "text" && curr + 1 < max && tokens[curr + 1].type === "text")
      tokens[curr + 1].content = tokens[curr].content + tokens[curr + 1].content;
    else {
      if (curr !== last)
        tokens[last] = tokens[curr];
      last++;
    }
  }
  if (curr !== last)
    tokens.length = last;
}
var _rules = [
  ["text", text],
  ["linkify", linkify],
  ["newline", newline],
  ["escape", escape],
  ["backticks", backtick],
  ["strikethrough", strikethrough_default.tokenize],
  ["emphasis", emphasis_default.tokenize],
  ["link", link],
  ["image", image],
  ["autolink", autolink],
  ["html_inline", html_inline],
  ["entity", entity]
];
var _rules2 = [
  ["balance_pairs", link_pairs],
  ["strikethrough", strikethrough_default.postProcess],
  ["emphasis", emphasis_default.postProcess],
  ["fragments_join", fragments_join]
];
var ParserInline = class {
  constructor() {
    _defineProperty(this, "ruler", new Ruler);
    _defineProperty(this, "ruler2", new Ruler);
    _defineProperty(this, "State", StateInline);
    for (let i = 0;i < _rules.length; i++)
      this.ruler.push(_rules[i][0], _rules[i][1]);
    for (let i = 0;i < _rules2.length; i++)
      this.ruler2.push(_rules2[i][0], _rules2[i][1]);
  }
  skipToken(state) {
    const pos = state.pos;
    const rules = this.ruler.getRules("");
    const len = rules.length;
    const maxNesting = state.md.options.maxNesting;
    const cache = state.cache;
    if (typeof cache[pos] !== "undefined") {
      state.pos = cache[pos];
      return;
    }
    let ok = false;
    if (state.level < maxNesting)
      for (let i = 0;i < len; i++) {
        state.level++;
        ok = rules[i](state, true);
        state.level--;
        if (ok) {
          if (pos >= state.pos)
            throw new Error("inline rule didn't increment state.pos");
          break;
        }
      }
    else
      state.pos = state.posMax;
    if (!ok)
      state.pos++;
    cache[pos] = state.pos;
  }
  tokenize(state) {
    const rules = this.ruler.getRules("");
    const len = rules.length;
    const end = state.posMax;
    const maxNesting = state.md.options.maxNesting;
    while (state.pos < end) {
      const prevPos = state.pos;
      let ok = false;
      if (state.level < maxNesting)
        for (let i = 0;i < len; i++) {
          ok = rules[i](state, false);
          if (ok) {
            if (prevPos >= state.pos)
              throw new Error("inline rule didn't increment state.pos");
            break;
          }
        }
      if (ok) {
        if (state.pos >= end)
          break;
        continue;
      }
      state.pending += state.src[state.pos++];
    }
    if (state.pending)
      state.pushPending();
  }
  parse(str, md, env, outTokens) {
    const state = new this.State(str, md, env, outTokens);
    this.tokenize(state);
    const rules = this.ruler2.getRules("");
    const len = rules.length;
    for (let i = 0;i < len; i++)
      rules[i](state);
  }
};
var config = {
  default: {
    options: {
      html: false,
      xhtmlOut: false,
      breaks: false,
      langPrefix: "language-",
      linkify: false,
      typographer: false,
      quotes: "\u201C\u201D\u2018\u2019",
      highlight: null,
      maxNesting: 100
    },
    components: {
      core: {},
      block: {},
      inline: {}
    }
  },
  zero: {
    options: {
      html: false,
      xhtmlOut: false,
      breaks: false,
      langPrefix: "language-",
      linkify: false,
      typographer: false,
      quotes: "\u201C\u201D\u2018\u2019",
      highlight: null,
      maxNesting: 20
    },
    components: {
      core: { rules: [
        "normalize",
        "block",
        "strip_references",
        "inline",
        "text_join"
      ] },
      block: { rules: ["paragraph"] },
      inline: {
        rules: ["text"],
        rules2: ["balance_pairs", "fragments_join"]
      }
    }
  },
  commonmark: {
    options: {
      html: true,
      xhtmlOut: true,
      breaks: false,
      langPrefix: "language-",
      linkify: false,
      typographer: false,
      quotes: "\u201C\u201D\u2018\u2019",
      highlight: null,
      maxNesting: 20
    },
    components: {
      core: { rules: [
        "normalize",
        "block",
        "strip_references",
        "inline",
        "text_join"
      ] },
      block: { rules: [
        "blockquote",
        "code",
        "fence",
        "heading",
        "hr",
        "html_block",
        "lheading",
        "list",
        "reference",
        "paragraph"
      ] },
      inline: {
        rules: [
          "autolink",
          "backticks",
          "emphasis",
          "entity",
          "escape",
          "html_inline",
          "image",
          "link",
          "newline",
          "text"
        ],
        rules2: [
          "balance_pairs",
          "emphasis",
          "fragments_join"
        ]
      }
    }
  }
};
var BAD_PROTO_RE = /^(vbscript|javascript|file|data):/;
var GOOD_DATA_RE = /^data:image\/(gif|png|jpeg|webp);/;
var RECODE_HOSTNAME_FOR = [
  "http:",
  "https:",
  "mailto:"
];
var MarkdownIt = class {
  validateLink(url) {
    const str = url.trim().toLowerCase();
    return BAD_PROTO_RE.test(str) ? GOOD_DATA_RE.test(str) : true;
  }
  normalizeLink(url) {
    const parsed = parse_default(url, true);
    if (parsed.hostname) {
      if (!parsed.protocol || RECODE_HOSTNAME_FOR.indexOf(parsed.protocol) >= 0)
        try {
          parsed.hostname = punycode_es6_default.toASCII(parsed.hostname);
        } catch (er) {}
    }
    if (parsed.auth)
      parsed.auth = encode_default(parsed.auth);
    if (parsed.hostname)
      parsed.hostname = encode_default(parsed.hostname);
    if (parsed.pathname)
      parsed.pathname = encode_default(parsed.pathname);
    if (parsed.search)
      parsed.search = encode_default(parsed.search);
    if (parsed.hash)
      parsed.hash = encode_default(parsed.hash);
    return format(parsed);
  }
  normalizeLinkText(url) {
    const parsed = parse_default(url, true);
    if (parsed.hostname) {
      if (!parsed.protocol || RECODE_HOSTNAME_FOR.indexOf(parsed.protocol) >= 0)
        try {
          parsed.hostname = punycode_es6_default.toUnicode(parsed.hostname);
        } catch (er) {}
    }
    return decode_default(format(parsed), decode_default.defaultChars + "%");
  }
  constructor(...args) {
    _defineProperty(this, "inline", new ParserInline);
    _defineProperty(this, "block", new ParserBlock);
    _defineProperty(this, "core", new ParserCore);
    _defineProperty(this, "renderer", new Renderer);
    _defineProperty(this, "linkify", new LinkifyIt);
    _defineProperty(this, "utils", utils_exports);
    _defineProperty(this, "helpers", Object.assign({}, helpers_exports));
    const [presetNameOrOptions, options] = args;
    if (typeof presetNameOrOptions === "string") {
      this.configure(presetNameOrOptions);
      if (options)
        this.set(options);
    } else {
      this.configure("default");
      this.set(presetNameOrOptions || {});
    }
  }
  set(options) {
    Object.assign(this.options, options);
    return this;
  }
  configure(presets) {
    let p;
    if (typeof presets === "string") {
      const presetName = presets;
      p = config[presetName];
      if (!p)
        throw new Error(`Wrong 'markdown-it' preset "${presetName}", check name`);
    } else
      p = presets;
    if (!p)
      throw new Error("Wrong `markdown-it` preset, can't be empty");
    if (p.options)
      this.options = { ...p.options };
    const components = p.components;
    if (components) {
      var _components$inline;
      [
        "core",
        "block",
        "inline"
      ].forEach((name) => {
        var _components$name;
        const rules = (_components$name = components[name]) === null || _components$name === undefined ? undefined : _components$name.rules;
        if (rules)
          this[name].ruler.enableOnly(rules);
      });
      const rules2 = (_components$inline = components.inline) === null || _components$inline === undefined ? undefined : _components$inline.rules2;
      if (rules2)
        this.inline.ruler2.enableOnly(rules2);
    }
    return this;
  }
  enable(list, ignoreInvalid = false) {
    let result = [];
    if (!Array.isArray(list))
      list = [list];
    [
      "core",
      "block",
      "inline"
    ].forEach((chain) => {
      result = result.concat(this[chain].ruler.enable(list, true));
    });
    result = result.concat(this.inline.ruler2.enable(list, true));
    const missed = list.filter((name) => result.indexOf(name) < 0);
    if (missed.length && !ignoreInvalid)
      throw new Error(`MarkdownIt. Failed to enable unknown rule(s): ${missed}`);
    return this;
  }
  disable(list, ignoreInvalid = false) {
    let result = [];
    if (!Array.isArray(list))
      list = [list];
    [
      "core",
      "block",
      "inline"
    ].forEach((chain) => {
      result = result.concat(this[chain].ruler.disable(list, true));
    });
    result = result.concat(this.inline.ruler2.disable(list, true));
    const missed = list.filter((name) => result.indexOf(name) < 0);
    if (missed.length && !ignoreInvalid)
      throw new Error(`MarkdownIt. Failed to disable unknown rule(s): ${missed}`);
    return this;
  }
  use(plugin, ...params) {
    plugin.apply(plugin, [this, ...params]);
    return this;
  }
  parse(src, env) {
    if (typeof src !== "string")
      throw new Error("Input data should be a String");
    const state = new this.core.State(src, this, env);
    this.core.process(state);
    return state.tokens;
  }
  render(src, env = {}) {
    return this.renderer.render(this.parse(src, env), this.options, env);
  }
  parseInline(src, env) {
    const state = new this.core.State(src, this, env);
    state.inlineMode = true;
    this.core.process(state);
    return state.tokens;
  }
  renderInline(src, env = {}) {
    return this.renderer.render(this.parseInline(src, env), this.options, env);
  }
};
_defineProperty(MarkdownIt, "Token", Token);
_defineProperty(MarkdownIt, "Ruler", Ruler);
_defineProperty(MarkdownIt, "Renderer", Renderer);
_defineProperty(MarkdownIt, "ParserCore", ParserCore);
_defineProperty(MarkdownIt, "StateCore", StateCore);
_defineProperty(MarkdownIt, "ParserBlock", ParserBlock);
_defineProperty(MarkdownIt, "StateBlock", StateBlock);
_defineProperty(MarkdownIt, "ParserInline", ParserInline);
_defineProperty(MarkdownIt, "StateInline", StateInline);
var MarkdownItCallable = callable(MarkdownIt);

// packages/editor/src/convert.ts
var md = new MarkdownItCallable({ html: false, linkify: false, breaks: false });
function parseMarkdown(text) {
  const tokens = md.parse(text, {});
  const raws = [];
  const doc = schema2.node("doc", null, blockNodes(tokens, raws));
  return { doc, raws };
}
function blockNodes(tokens, raws, from = 0, to = tokens.length) {
  const out = [];
  let i = from;
  while (i < to) {
    const token = tokens[i];
    if (token === undefined)
      break;
    switch (token.type) {
      case "heading_open": {
        const level = Number(token.tag.slice(1));
        out.push(schema2.node("heading", { level }, inlineContent(tokens[i + 1], raws)));
        i += 3;
        continue;
      }
      case "paragraph_open": {
        out.push(schema2.node("paragraph", null, inlineContent(tokens[i + 1], raws)));
        i += 3;
        continue;
      }
      case "blockquote_open": {
        const close = findClose(tokens, i, "blockquote_close");
        out.push(schema2.node("blockquote", null, blockNodes(tokens, raws, i + 1, close)));
        i = close + 1;
        continue;
      }
      case "bullet_list_open":
      case "ordered_list_open": {
        const close = findClose(tokens, i, token.type.replace("_open", "_close"));
        const items = listItems(tokens, raws, i + 1, close);
        const attrs = token.type === "ordered_list_open" ? { order: Number(token.attrGet("start") ?? 1) } : null;
        out.push(schema2.node(token.type === "bullet_list_open" ? "bullet_list" : "ordered_list", attrs, items));
        i = close + 1;
        continue;
      }
      case "fence": {
        const language = (token.info ?? "").trim().split(/\s+/)[0] ?? "";
        out.push(schema2.node("code_block", { language }, codeText(token.content)));
        i += 1;
        continue;
      }
      case "code_block": {
        out.push(schema2.node("code_block", { language: "" }, codeText(token.content)));
        i += 1;
        continue;
      }
      case "hr": {
        out.push(schema2.node("horizontal_rule"));
        i += 1;
        continue;
      }
      case "table_open": {
        const close = findClose(tokens, i, "table_close");
        out.push(tableNode(tokens, raws, i + 1, close));
        i = close + 1;
        continue;
      }
      default: {
        if (token.content !== "")
          out.push(rawNode(token.content, raws));
        i += 1;
        continue;
      }
    }
  }
  return out;
}
function codeText(content) {
  const body = content.replace(/\n$/, "");
  return body === "" ? [] : [schema2.text(body)];
}
function listItems(tokens, raws, from, to) {
  const items = [];
  let i = from;
  while (i < to) {
    const token = tokens[i];
    if (token === undefined)
      break;
    if (token.type !== "list_item_open") {
      i += 1;
      continue;
    }
    const close = findClose(tokens, i, "list_item_close");
    const children = blockNodes(tokens, raws, i + 1, close);
    const first = children[0];
    if (first === undefined)
      children.push(schema2.node("paragraph"));
    else if (first.type.name !== "paragraph")
      children.unshift(schema2.node("paragraph"));
    items.push(schema2.node("list_item", null, children));
    i = close + 1;
  }
  return items.length > 0 ? items : [schema2.node("list_item", null, [schema2.node("paragraph")])];
}
function tableNode(tokens, raws, from, to) {
  const rows = [];
  let i = from;
  let inHead = false;
  while (i < to) {
    const token = tokens[i];
    if (token === undefined)
      break;
    if (token.type === "thead_open")
      inHead = true;
    if (token.type === "thead_close")
      inHead = false;
    if (token.type === "tr_open") {
      const close = findClose(tokens, i, "tr_close");
      const cells = [];
      let j = i + 1;
      while (j < close) {
        const cell = tokens[j];
        if (cell === undefined)
          break;
        if (cell.type === "th_open" || cell.type === "td_open") {
          const cellClose = findClose(tokens, j, cell.type.replace("_open", "_close"));
          const content = inlineContent(tokens[j + 1], raws);
          const name = cell.type === "th_open" || inHead ? "table_header" : "table_cell";
          cells.push(schema2.node(name, { align: alignOfCell(cell) }, [schema2.node("paragraph", null, content)]));
          j = cellClose + 1;
          continue;
        }
        j += 1;
      }
      if (cells.length > 0)
        rows.push(schema2.node("table_row", null, cells));
      i = close + 1;
      continue;
    }
    i += 1;
  }
  if (rows.length === 0) {
    return schema2.node("table", null, [
      schema2.node("table_row", null, [schema2.node("table_header", null, [schema2.node("paragraph")])])
    ]);
  }
  return schema2.node("table", null, rows);
}
function alignOfCell(token) {
  const style = String(token.attrGet("style") ?? "");
  return /text-align:\s*(left|center|right)/.exec(style)?.[1] ?? "";
}
function inlineContent(token, raws) {
  if (token === undefined || token.children === null)
    return [];
  const out = [];
  let marks = [];
  const pushText = (text) => {
    if (text === "")
      return;
    out.push(schema2.text(text, marks.map((m) => schema2.marks[m.type].create(m.attrs ?? null))));
  };
  for (const child of token.children) {
    switch (child.type) {
      case "text":
        pushText(child.content);
        break;
      case "softbreak":
        pushText(`
`);
        break;
      case "hardbreak":
        out.push(schema2.node("hard_break", undefined, undefined, marks.map((m) => schema2.marks[m.type].create(m.attrs ?? null))));
        break;
      case "strong_open":
        marks = [...marks, { type: "strong" }];
        break;
      case "strong_close":
        marks = marks.filter((m) => m.type !== "strong");
        break;
      case "em_open":
        marks = [...marks, { type: "em" }];
        break;
      case "em_close":
        marks = marks.filter((m) => m.type !== "em");
        break;
      case "s_open":
        marks = [...marks, { type: "strike" }];
        break;
      case "s_close":
        marks = marks.filter((m) => m.type !== "strike");
        break;
      case "code_inline":
        out.push(schema2.text(child.content, [...marks.map((m) => schema2.marks[m.type].create(m.attrs ?? null)), schema2.marks.code.create()]));
        break;
      case "link_open":
        marks = [...marks, { type: "link", attrs: { href: child.attrGet("href") ?? "", title: child.attrGet("title") } }];
        break;
      case "link_close":
        marks = marks.filter((m) => m.type !== "link");
        break;
      case "image":
        out.push(schema2.node("image", {
          src: String(child.attrGet("src") ?? ""),
          alt: child.content,
          title: child.attrGet("title") ?? "",
          width: 0
        }));
        break;
      case "html_inline": {
        raws.push(child.content);
        pushText(child.content);
        break;
      }
      default: {
        if (child.content !== "")
          pushText(child.content);
        break;
      }
    }
  }
  return out;
}
function rawNode(text, raws) {
  raws.push(text);
  return schema2.node("raw", { text: text.replace(/\n$/, "") });
}
function findClose(tokens, from, closeType) {
  const openType = closeType.replace(/_close$/, "_open");
  let depth = 0;
  for (let i = from;i < tokens.length; i += 1) {
    const type = tokens[i]?.type;
    if (type === openType)
      depth += 1;
    else if (type === closeType && (depth -= 1) === 0)
      return i;
  }
  return tokens.length;
}
var INLINE_ESCAPE = /([\\`*_[\]~|])/g;
var LINE_START_ESCAPE = /^([#>+\-=])/;
var ORDERED_ESCAPE = /^(\d+)([.)])/;
var LIST_KINDS = new Set(["bullet_list", "ordered_list"]);
function serializeMarkdown(doc) {
  const losses = [];
  const body = blocksToMd(doc, losses);
  return { markdown: body === "" ? "" : `${body}
`, losses };
}
function blocksToMd(parent, losses, owner) {
  const parts = [];
  let blockNo = 0;
  parent.forEach((child) => {
    blockNo += 1;
    const at = owner ?? blockNo;
    if (child.type.name === "paragraph" && child.content.size === 0) {
      losses.push({ block: at, what: "paragraph", detail: "emptyParagraph" });
      return;
    }
    parts.push(blockToMd(child, losses, at));
  });
  return parts.join(`

`);
}
function blockToMd(node, losses, blockNo, blockStart = true) {
  const lost = lostCodes(node.attrs);
  if (lost.length > 0)
    losses.push({ block: blockNo, what: node.type.name, detail: lost.join(",") });
  const note = (code) => {
    losses.push({ block: blockNo, what: node.type.name, detail: code });
  };
  switch (node.type.name) {
    case "paragraph":
      return inlineToMd(node, note, blockStart).replace(/[ \t]+$/, "");
    case "heading": {
      const level = Math.min(Math.max(Number(node.attrs.level ?? 1), 1), 6);
      const body = inlineToMd(node, note, false);
      return body === "" ? "#".repeat(level) : `${"#".repeat(level)} ${body}`;
    }
    case "blockquote":
      return quoteMd(node, losses, blockNo);
    case "bullet_list":
      return listMd(node, losses, blockNo, () => "- ");
    case "ordered_list": {
      const start = Number(node.attrs.order ?? 1);
      return listMd(node, losses, blockNo, (index) => `${start + index}. `);
    }
    case "code_block":
      return codeMd(node);
    case "horizontal_rule":
      return "---";
    case "table":
      return tableMd(node, losses, blockNo);
    case "raw":
      return String(node.attrs.text ?? "");
    default:
      return inlineToMd(node, note, blockStart);
  }
}
function quoteMd(node, losses, blockNo) {
  const inner = blocksToMd(node, losses, blockNo);
  return inner === "" ? ">" : inner.split(`
`).map((line) => line === "" ? ">" : `> ${line}`).join(`
`);
}
function listMd(node, losses, blockNo, marker) {
  const lines = [];
  node.forEach((item, _offset, index) => {
    const prefix = marker(index);
    const pad = " ".repeat(prefix.length);
    const [head, ...rest] = itemMd(item, losses, blockNo).split(`
`);
    lines.push(`${prefix}${head ?? ""}`.trimEnd());
    for (const line of rest)
      lines.push(line === "" ? "" : `${pad}${line}`);
  });
  return lines.join(`
`);
}
function itemMd(item, losses, blockNo) {
  const parts = [];
  let first = true;
  item.forEach((child) => {
    if (child.type.name === "paragraph" && child.content.size === 0) {
      losses.push({ block: blockNo, what: "paragraph", detail: "emptyParagraph" });
      return;
    }
    parts.push({ kind: child.type.name, text: blockToMd(child, losses, blockNo, !first) });
    first = false;
  });
  const head = parts[0];
  if (head === undefined)
    return "";
  let out = head.text;
  for (let i = 1;i < parts.length; i += 1) {
    const prev = parts[i - 1];
    const cur = parts[i];
    if (prev === undefined || cur === undefined)
      continue;
    const tight = LIST_KINDS.has(cur.kind) && prev.kind === "paragraph";
    out += `${tight ? `
` : `

`}${cur.text}`;
  }
  return out;
}
function codeMd(node) {
  const body = node.textContent;
  const longest = Math.max(0, ...(body.match(/`+/g) ?? []).map((run) => run.length));
  const fence = "`".repeat(Math.max(3, longest + 1));
  return `${fence}${String(node.attrs.language ?? "")}
${body}
${fence}`;
}
function tableMd(node, losses, blockNo) {
  const rows = [];
  const aligns = [];
  node.forEach((row) => {
    const cells = [];
    const firstRow = rows.length === 0;
    row.forEach((cell, _offset, index) => {
      cells.push(cellToMd(cell, losses, blockNo));
      if (firstRow)
        aligns[index] = String(cell.attrs.align ?? "");
    });
    rows.push(cells);
  });
  const width = Math.max(...rows.map((row) => row.length), 1);
  const pad = (row) => `| ${Array.from({ length: width }, (_, i) => row[i] ?? "").join(" | ")} |`;
  const sep = `| ${Array.from({ length: width }, (_, i) => separatorOf(aligns[i] ?? "")).join(" | ")} |`;
  return [pad(rows[0] ?? []), sep, ...rows.slice(1).map(pad)].join(`
`);
}
function separatorOf(align) {
  if (align === "left")
    return ":---";
  if (align === "center")
    return ":---:";
  if (align === "right")
    return "---:";
  return "---";
}
function cellToMd(cell, losses, blockNo) {
  const blocks = [];
  cell.forEach((child) => {
    blocks.push(blockToMd(child, losses, blockNo).replace(/\n+/g, " ").trim());
  });
  if (blocks.length > 1)
    losses.push({ block: blockNo, what: cell.type.name, detail: "cellBlocks" });
  return blocks.filter((text) => text !== "").join(" ").replace(/(?<!\\)\|/g, "\\|");
}
function inlineToMd(node, note, blockStart = true) {
  const children = [];
  node.forEach((child) => children.push(child));
  let out = "";
  let active = [];
  let atStart = blockStart;
  const closeTo = (keep) => {
    for (let i = active.length - 1;i >= keep; i -= 1) {
      const mark = active[i];
      if (mark !== undefined)
        out += delimOf(mark).close;
    }
    active = active.slice(0, keep);
  };
  for (const child of children) {
    const marks = child.marks;
    let shared = 0;
    while (shared < active.length && shared < marks.length && active[shared].eq(marks[shared]))
      shared += 1;
    closeTo(shared);
    for (let i = shared;i < marks.length; i += 1) {
      const mark = marks[i];
      if (mark === undefined)
        continue;
      out += delimOf(mark).open;
      active.push(mark);
    }
    out += leafToMd(child, atStart || atLineStart(out), note);
    atStart = false;
  }
  closeTo(0);
  return out;
}
function leafToMd(node, lineStart, note) {
  if (node.type.name === "image") {
    if (Number(node.attrs.width ?? 0) > 0)
      note("imageWidth");
    return imageMd(node);
  }
  if (node.type.name === "hard_break")
    return `  
`;
  if (!node.isText)
    return escapeText(node.textContent, lineStart);
  const raw = node.text ?? "";
  if (node.marks.some((mark) => mark.type.name === "code"))
    return raw.replace(/`/g, "\\`");
  return escapeText(raw, lineStart);
}
function delimOf(mark) {
  switch (mark.type.name) {
    case "strong":
      return { open: "**", close: "**" };
    case "em":
      return { open: "*", close: "*" };
    case "code":
      return { open: "`", close: "`" };
    case "strike":
      return { open: "~~", close: "~~" };
    case "link":
      return {
        open: "[",
        close: `](${linkTarget(String(mark.attrs.href ?? ""))}${linkTitle(mark.attrs.title)})`
      };
    default:
      return { open: "", close: "" };
  }
}
function atLineStart(out) {
  return out === "" || out.endsWith(`
`);
}
function escapeText(text, lineStart) {
  const escaped = text.replace(INLINE_ESCAPE, "\\$1");
  if (!lineStart)
    return escaped;
  return escaped.replace(LINE_START_ESCAPE, "\\$1").replace(ORDERED_ESCAPE, "$1\\$2");
}
function linkTarget(url) {
  return /[ ()]/.test(url) ? `<${url}>` : url;
}
function linkTitle(title) {
  if (title === null || title === undefined || title === "")
    return "";
  return ` "${String(title).replace(/"/g, "\\\"")}"`;
}
function imageMd(node) {
  const alt = escapeText(String(node.attrs.alt ?? ""), false);
  return `![${alt}](${linkTarget(String(node.attrs.src ?? ""))}${linkTitle(node.attrs.title)})`;
}
function lostCodes(attrs) {
  const codes = [];
  if (Number(attrs.indent ?? 0) !== 0)
    codes.push("indent");
  if (String(attrs.font ?? "") !== "")
    codes.push("font");
  if (Number(attrs.size ?? 0) !== 0)
    codes.push("size");
  if (Number(attrs.lineHeight ?? 0) !== 0)
    codes.push("lineHeight");
  if (String(attrs.align ?? "") !== "")
    codes.push("align");
  return codes;
}
function loadMarkdown(text) {
  if (text.trim() === "")
    return { doc: schema2.node("doc", null, [schema2.node("paragraph")]), raws: [] };
  return parseMarkdown(text);
}
// packages/editor/src/pmd.ts
var PMD_FORMAT = "tessera.pmd";
var PMD_VERSION = 1;
var isDocKind = (value) => value === "chapter" || value === "note" || value === "setting";
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function encodePmd(doc, kind = "chapter") {
  return `${JSON.stringify({ format: PMD_FORMAT, version: PMD_VERSION, kind, doc: doc.toJSON() }, null, 2)}
`;
}
function decodePmd(text) {
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return { ok: false, reason: "json" };
  }
  if (!isRecord(parsed))
    return { ok: false, reason: "format" };
  if (parsed.format !== PMD_FORMAT)
    return { ok: false, reason: "format" };
  const version = parsed.version;
  if (typeof version !== "number" || !Number.isInteger(version) || version < 1) {
    return { ok: false, reason: "version" };
  }
  if (version > PMD_VERSION)
    return { ok: false, reason: "version" };
  try {
    const doc = schema2.nodeFromJSON(parsed.doc);
    if (doc.type.name !== "doc")
      return { ok: false, reason: "schema" };
    doc.check();
    const kind = isDocKind(parsed.kind) ? parsed.kind : "chapter";
    return { ok: true, doc, version, kind };
  } catch {
    return { ok: false, reason: "schema" };
  }
}
// packages/editor/src/text.ts
var CJK = /[\u3400-\u4dbf\u4e00-\u9fff]/g;
var LATIN = /[A-Za-z][A-Za-z'-]*|\d+/g;
function countText(text) {
  const chars = [...text].length;
  const cjk = (text.match(CJK) ?? []).length;
  const latin = (text.match(LATIN) ?? []).length;
  const lines = text === "" ? 1 : text.split(`
`).length;
  return { chars, words: cjk + latin, lines };
}
var countWords = (text) => countText(text).words;
// packages/editor/src/diff.ts
var MAX_CELLS = 4000000;
var splitLines = (text) => {
  if (text === "")
    return [];
  const normalized = text.replace(/\r\n/g, `
`);
  const lines = normalized.split(`
`);
  if (lines.length > 1 && lines[lines.length - 1] === "")
    lines.pop();
  return lines;
};
function diffLines(before, after) {
  const a = splitLines(before);
  const b = splitLines(after);
  let head = 0;
  while (head < a.length && head < b.length && a[head] === b[head])
    head += 1;
  let tail = 0;
  while (tail < a.length - head && tail < b.length - head && a[a.length - 1 - tail] === b[b.length - 1 - tail]) {
    tail += 1;
  }
  const middleA = a.slice(head, a.length - tail);
  const middleB = b.slice(head, b.length - tail);
  const ops = [];
  for (let i = 0;i < head; i += 1)
    ops.push({ type: "same", text: a[i] });
  if (middleA.length * middleB.length > MAX_CELLS) {
    for (const line of middleA)
      ops.push({ type: "del", text: line });
    for (const line of middleB)
      ops.push({ type: "add", text: line });
  } else {
    ops.push(...lcsOps(middleA, middleB));
  }
  for (let i = a.length - tail;i < a.length; i += 1)
    ops.push({ type: "same", text: a[i] });
  return {
    ops,
    added: ops.filter((op) => op.type === "add").length,
    removed: ops.filter((op) => op.type === "del").length
  };
}
function lcsOps(a, b) {
  const rows = a.length;
  const cols = b.length;
  const table = Array.from({ length: rows + 1 }, () => new Array(cols + 1).fill(0));
  for (let i = rows - 1;i >= 0; i -= 1) {
    for (let j = cols - 1;j >= 0; j -= 1) {
      table[i][j] = a[i] === b[j] ? table[i + 1][j + 1] + 1 : Math.max(table[i + 1][j], table[i][j + 1]);
    }
  }
  const ops = [];
  let i = 0;
  let j = 0;
  while (i < rows && j < cols) {
    if (a[i] === b[j]) {
      ops.push({ type: "same", text: a[i] });
      i += 1;
      j += 1;
      continue;
    }
    if (table[i + 1][j] >= table[i][j + 1]) {
      ops.push({ type: "del", text: a[i] });
      i += 1;
      continue;
    }
    ops.push({ type: "add", text: b[j] });
    j += 1;
  }
  while (i < rows) {
    ops.push({ type: "del", text: a[i] });
    i += 1;
  }
  while (j < cols) {
    ops.push({ type: "add", text: b[j] });
    j += 1;
  }
  return ops;
}
// packages/editor/src/verify.ts
var UNEXPRESSED = new Set(["indent", "font", "size", "lineHeight", "align"]);
// packages/library/src/documents.ts
var MANUSCRIPT_MAX_DEPTH = 4;
var MAX_DOCS = 5000;
var MAX_DRAFT_BYTES = 4 * 1024 * 1024;
var MAX_SEARCH_FILES = 2000;
var DEFAULT_SEARCH_LIMIT = 50;
var SNIPPET_MAX = 200;
var TITLE_MAX = 80;
var PMD_EXT = ".pmd";
var MD_EXT = ".md";
var SNAPSHOT_DIR = ".tessera/snapshots";
var STATS_FILE = ".tessera/stats.json";
var MAX_SNAPSHOTS = 50;

class DocError extends Error {
  reason;
  constructor(reason) {
    super(`doc.${reason}`);
    this.reason = reason;
    this.name = "DocError";
  }
}
function revOfBytes(bytes) {
  return bytes ? `sha256:${createHash("sha256").update(bytes).digest("hex")}` : null;
}
var encoder = new TextEncoder;
var decoder = new TextDecoder("utf-8");
var isPmd = (path) => path.toLowerCase().endsWith(PMD_EXT);
var stemOf = (path) => path.replace(/\.(pmd|md)$/i, "");
var mirrorOf = (path) => `${stemOf(path)}${isPmd(path) ? MD_EXT : PMD_EXT}`;
function readDocContent(store, path) {
  const bytes = store.readRaw(path);
  if (bytes === null)
    return null;
  if (!isPmd(path))
    return { bytes, markdown: decoder.decode(bytes), pmd: null, kind: "chapter" };
  const pmd = decoder.decode(bytes);
  const decoded = decodePmd(pmd);
  if (!decoded.ok)
    return null;
  return { bytes, markdown: serializeMarkdown(decoded.doc).markdown, pmd, kind: decoded.kind };
}
function titleOf(path) {
  const name = path.slice(path.lastIndexOf("/") + 1).replace(/\.(md|pmd)$/i, "");
  return name.replace(/^\d+[-_.\s]+/, "").slice(0, TITLE_MAX) || name;
}
function hasTitle(paths, slug) {
  const needle = slug.toLowerCase();
  return paths.some((path) => titleOf(path).toLowerCase() === needle);
}
function isAliasMap(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  return Object.values(value).every((to) => typeof to === "string");
}
function withAlias(aliases, from, to) {
  const next = {};
  for (const [old, current] of Object.entries(aliases ?? {})) {
    next[old] = current === from ? to : current;
  }
  if (from !== to)
    next[from] = to;
  return next;
}
function slugOf(title) {
  const cleaned = title.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "").replace(/[.\s]+$/g, "").trim().slice(0, TITLE_MAX);
  if (/^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(cleaned))
    return `doc-${cleaned}`;
  return cleaned;
}
function projectIdOf(path) {
  const slash = path.indexOf("/");
  if (slash <= 0)
    throw new DocError("path.invalid");
  return path.slice(0, slash);
}
function basenameOf(path) {
  return path.slice(path.lastIndexOf("/") + 1);
}
function trashNameOf(id) {
  const dash = id.indexOf("-");
  return dash > 0 ? id.slice(dash + 1) : id;
}
function trashAtOf(id) {
  const dash = id.indexOf("-");
  const ts = dash > 0 ? Number(id.slice(0, dash)) : Number.NaN;
  return Number.isFinite(ts) ? ts : 0;
}
function createDocumentService(store) {
  const projectPath = (projectId) => {
    if (projectId === "" || projectId === "." || projectId === "..")
      throw new DocError("path.invalid");
    if (projectId.includes("/") || projectId.includes("\\"))
      throw new DocError("path.invalid");
    return `${projectId}/${PROJECT_FILE}`;
  };
  const manuscriptDir = (projectId) => `${projectId}/${MANUSCRIPT_DIR}`;
  const DOC_ROOTS = [MANUSCRIPT_DIR, "notes", "settings"];
  const draftPath = (docId) => {
    const digest = createHash("sha256").update(docId).digest("hex").slice(0, 16);
    return draftFile(projectIdOf(docId), digest);
  };
  const snapshotDir = (docId) => `${projectIdOf(docId)}/${SNAPSHOT_DIR}/${createHash("sha256").update(docId).digest("hex").slice(0, 16)}`;
  const snapshotMetaPath = (docId) => `${snapshotDir(docId)}/reasons.json`;
  const readSnapshotReasons = (docId) => {
    const raw = store.read(snapshotMetaPath(docId));
    if (raw === null)
      return {};
    try {
      const parsed = JSON.parse(raw);
      if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed))
        return {};
      const out = {};
      for (const [key, value] of Object.entries(parsed)) {
        if (typeof value === "string")
          out[key] = value;
      }
      return out;
    } catch {
      return {};
    }
  };
  const listSnapshotRefs = (docId) => {
    const dir = snapshotDir(docId);
    if (!store.exists(dir))
      return [];
    const reasons = readSnapshotReasons(docId);
    const refs = [];
    for (const name of store.list(dir)) {
      const lower = name.toLowerCase();
      if (!lower.endsWith(PMD_EXT) && !lower.endsWith(MD_EXT))
        continue;
      const id = stemOf(name);
      const at = Number(id);
      if (!Number.isFinite(at))
        continue;
      const stat = store.stat(`${dir}/${name}`);
      refs.push({ id, docId, at, bytes: stat?.size ?? 0, reason: reasons[id] ?? "" });
    }
    return refs.sort((a, b) => b.at - a.at);
  };
  const pruneSnapshots = (docId) => {
    const refs = listSnapshotRefs(docId);
    if (refs.length <= MAX_SNAPSHOTS)
      return;
    const dir = snapshotDir(docId);
    const reasons = readSnapshotReasons(docId);
    for (const ref of refs.slice(MAX_SNAPSHOTS)) {
      for (const ext of [PMD_EXT, MD_EXT])
        store.remove(`${dir}/${ref.id}${ext}`);
      delete reasons[ref.id];
    }
    store.write(snapshotMetaPath(docId), JSON.stringify(reasons));
  };
  const migrateDocSidecars = (fromDocId, toDocId) => {
    const fromSnap = snapshotDir(fromDocId);
    const toSnap = snapshotDir(toDocId);
    try {
      if (store.exists(fromSnap) && !store.exists(toSnap)) {
        store.move(fromSnap, toSnap);
      }
    } catch {}
    try {
      const fromDraft = draftPath(fromDocId);
      if (store.exists(fromDraft)) {
        const toDraft = draftPath(toDocId);
        store.write(toDraft, store.read(fromDraft) ?? "");
        store.remove(fromDraft);
      }
    } catch {}
  };
  const takeSnapshot = (docId, reason) => {
    const bytes = store.readRaw(docId);
    if (bytes === null)
      throw new DocError("not.found");
    const dir = snapshotDir(docId);
    const ext = isPmd(docId) ? PMD_EXT : MD_EXT;
    let at = Date.now();
    while (store.exists(`${dir}/${at}${ext}`))
      at += 1;
    store.writeBytes(`${dir}/${at}${ext}`, bytes);
    const reasons = readSnapshotReasons(docId);
    reasons[String(at)] = reason;
    store.write(snapshotMetaPath(docId), JSON.stringify(reasons));
    pruneSnapshots(docId);
    return { id: String(at), docId, at, bytes: bytes.byteLength, reason };
  };
  const snapshotMarkdown = (docId, id) => {
    const dir = snapshotDir(docId);
    const pmdPath = `${dir}/${id}${PMD_EXT}`;
    const path = store.exists(pmdPath) ? pmdPath : `${dir}/${id}${MD_EXT}`;
    const bytes = store.readRaw(path);
    if (bytes === null)
      return null;
    const text = decoder.decode(bytes);
    if (path !== pmdPath)
      return text;
    const decoded = decodePmd(text);
    return decoded.ok ? serializeMarkdown(decoded.doc).markdown : null;
  };
  const markdownOf = (pmdText) => {
    const decoded = decodePmd(pmdText);
    return decoded.ok ? serializeMarkdown(decoded.doc).markdown : null;
  };
  const statsPath = (projectId) => `${projectId}/${STATS_FILE}`;
  const STATS_KEEP_DAYS = 180;
  const readStats = (projectId) => {
    const raw = store.read(statsPath(projectId));
    if (raw === null)
      return { docs: {}, days: {} };
    try {
      const parsed = JSON.parse(raw);
      return { docs: parsed.docs ?? {}, days: parsed.days ?? {} };
    } catch {
      return { docs: {}, days: {} };
    }
  };
  const recordStats = (projectId, docId, words) => {
    const stats = readStats(projectId);
    const previous = stats.docs[docId] ?? 0;
    const delta = words - previous;
    stats.docs[docId] = words;
    if (delta > 0) {
      const today = new Date().toLocaleDateString("sv-SE");
      stats.days[today] = (stats.days[today] ?? 0) + delta;
      const dates = Object.keys(stats.days).sort();
      for (const date of dates.slice(0, Math.max(0, dates.length - STATS_KEEP_DAYS)))
        delete stats.days[date];
    }
    try {
      store.write(statsPath(projectId), JSON.stringify({ version: 1, ...stats }));
    } catch {}
  };
  const wordsCache = new Map;
  const readProjectFile = (projectId) => {
    const raw = store.read(projectPath(projectId));
    if (raw === null)
      return null;
    try {
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed.order) || parsed.order.some((p) => typeof p !== "string")) {
        throw new DocError("project.invalid");
      }
      return {
        schemaVersion: 1,
        title: typeof parsed.title === "string" ? parsed.title : projectId,
        order: parsed.order,
        updatedAt: typeof parsed.updatedAt === "string" ? parsed.updatedAt : new Date(0).toISOString(),
        ...isAliasMap(parsed.aliases) ? { aliases: parsed.aliases } : {}
      };
    } catch (err) {
      if (err instanceof DocError)
        throw err;
      throw new DocError("project.invalid");
    }
  };
  const writeProjectFile = (projectId, file) => {
    store.write(projectPath(projectId), `${JSON.stringify(file, null, 2)}
`);
  };
  const normalizeDir = (projectId, dir) => {
    const trimmed = dir.replaceAll("\\", "/").replace(/^\/+|\/+$/g, "");
    if (trimmed === "")
      return manuscriptDir(projectId);
    if (trimmed.includes("..") || trimmed.startsWith("."))
      return null;
    if (trimmed.includes(".tessera"))
      return null;
    const head = trimmed.split("/")[0] ?? "";
    const rooted = DOC_ROOTS.includes(head);
    const base = `${projectId}/${rooted ? head : MANUSCRIPT_DIR}`;
    const rest = rooted ? trimmed.slice(head.length).replace(/^\/+/, "") : trimmed;
    const full = rest === "" ? base : `${base}/${rest}`;
    if (full !== base && !full.startsWith(`${base}/`))
      return null;
    return full;
  };
  const scanAssets = (projectId) => {
    const dir = `${projectId}/assets`;
    const entries = store.walk(dir, 1, 500);
    return entries.filter((entry) => entry.isFile).map((entry) => ({
      name: entry.path.slice(dir.length + 1),
      bytes: store.stat(entry.path)?.size ?? 0,
      url: `/a/${entry.path}`
    })).sort((a, b) => a.name.localeCompare(b.name));
  };
  const saveAsset = (docId, dataUrl) => {
    const match = /^data:image\/([a-z0-9+.-]+);base64,(.+)$/i.exec(dataUrl);
    if (match === null)
      return { ok: false, reason: "params.invalid" };
    const raw = match[1] ?? "";
    const ext = raw === "jpeg" ? "jpg" : raw;
    if (!["png", "jpg", "gif", "webp", "bmp"].includes(ext))
      return { ok: false, reason: "params.invalid" };
    const projectId = projectIdOf(docId);
    let bytes;
    try {
      bytes = Uint8Array.from(atob(match[2] ?? ""), (c) => c.charCodeAt(0));
    } catch {
      return { ok: false, reason: "params.invalid" };
    }
    if (bytes.byteLength === 0 || bytes.byteLength > 12 * 1024 * 1024)
      return { ok: false, reason: "params.invalid" };
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const rel = `${projectId}/assets/${name}`;
    try {
      store.writeBytes(rel, bytes);
    } catch {
      return { ok: false, reason: "io.failed" };
    }
    return { ok: true, url: `/a/${projectId}/assets/${name}` };
  };
  const removeAsset = (projectId, name) => {
    if (name === "" || name.includes("/") || name.includes("\\") || name.includes("..")) {
      return { ok: false, reason: "params.invalid" };
    }
    const path = `${projectId}/assets/${name}`;
    if (!store.exists(path))
      return { ok: false, reason: "not.found" };
    try {
      store.remove(path);
    } catch {
      return { ok: false, reason: "io.failed" };
    }
    return { ok: true };
  };
  const renameFolder = (projectId, from, to) => {
    const fromDir = normalizeDir(projectId, from);
    const toDir = normalizeDir(projectId, to);
    if (fromDir === null || toDir === null)
      return { ok: false, reason: "params.invalid" };
    if (fromDir === manuscriptDir(projectId) || toDir === manuscriptDir(projectId)) {
      return { ok: false, reason: "params.invalid" };
    }
    if (!store.exists(fromDir))
      return { ok: false, reason: "not.found" };
    if (store.exists(toDir))
      return { ok: false, reason: "exists" };
    const { file } = reconcile(projectId);
    const prefix = `${fromDir}/`;
    const moved = file.order.filter((path) => path.startsWith(prefix));
    if (moved.length === 0)
      return { ok: false, reason: "not.found" };
    try {
      store.move(fromDir, toDir);
    } catch {
      return { ok: false, reason: "io.failed" };
    }
    const order = file.order.map((path) => path.startsWith(prefix) ? `${toDir}/${path.slice(prefix.length)}` : path);
    writeProjectFile(projectId, { ...file, order, updatedAt: new Date().toISOString() });
    return { ok: true, order };
  };
  const moveDoc = (docId, dir) => {
    const projectId = projectIdOf(docId);
    if (!store.exists(docId))
      return { ok: false, reason: "not.found" };
    const folder = normalizeDir(projectId, dir);
    if (folder === null)
      return { ok: false, reason: "params.invalid" };
    const currentFolder = docId.slice(0, docId.lastIndexOf("/"));
    if (currentFolder === folder)
      return { ok: false, reason: "noop" };
    const target = `${folder}/${docId.split("/").pop() ?? ""}`;
    if (store.exists(target))
      return { ok: false, reason: "exists" };
    const { file } = reconcile(projectId);
    try {
      store.move(docId, target);
      if (store.exists(mirrorOf(docId)) && !store.exists(mirrorOf(target))) {
        store.move(mirrorOf(docId), mirrorOf(target));
      }
    } catch {
      return { ok: false, reason: "io.failed" };
    }
    migrateDocSidecars(docId, target);
    const order = file.order.map((path) => path === docId ? target : path);
    writeProjectFile(projectId, { ...file, order, updatedAt: new Date().toISOString() });
    return { ok: true, docId: target, order };
  };
  const WORKSPACE_KEYS = new Set([
    "editor.fontFamily",
    "editor.proseSize",
    "editor.lineHeight",
    "editor.columnWidth",
    "editor.paragraphSpacing"
  ]);
  const workspacePath = (projectId) => `${projectId}/.tessera/workspace.json`;
  const readWorkspace = (projectId) => {
    const raw = store.read(workspacePath(projectId));
    if (raw === null)
      return {};
    try {
      const parsed = JSON.parse(raw);
      if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed))
        return {};
      const out = {};
      for (const [key, value] of Object.entries(parsed)) {
        if (WORKSPACE_KEYS.has(key))
          out[key] = value;
      }
      return out;
    } catch {
      return {};
    }
  };
  const writeWorkspace = (projectId, patch) => {
    const next = { ...readWorkspace(projectId) };
    for (const [key, value] of Object.entries(patch)) {
      if (!WORKSPACE_KEYS.has(key))
        continue;
      if (value === null)
        delete next[key];
      else
        next[key] = value;
    }
    try {
      if (Object.keys(next).length === 0) {
        const path = workspacePath(projectId);
        if (store.exists(path))
          store.remove(path);
      } else {
        store.write(workspacePath(projectId), `${JSON.stringify(next, null, 2)}
`);
      }
    } catch {
      return { ok: false, reason: "io.failed" };
    }
    return { ok: true, prefs: next };
  };
  const createFolder = (projectId, dir) => {
    const target = normalizeDir(projectId, dir);
    if (target === null || target === manuscriptDir(projectId))
      return { ok: false, reason: "params.invalid" };
    if (store.exists(target))
      return { ok: false, reason: "exists" };
    try {
      store.write(`${target}/.keep`, "");
    } catch {
      return { ok: false, reason: "io.failed" };
    }
    return { ok: true };
  };
  const removeFolder = (projectId, dir) => {
    const target = normalizeDir(projectId, dir);
    if (target === null || target === manuscriptDir(projectId))
      return { ok: false, reason: "params.invalid" };
    if (!store.exists(target))
      return { ok: false, reason: "not.found" };
    const { file } = reconcile(projectId);
    if (file.order.some((path) => path.startsWith(`${target}/`)))
      return { ok: false, reason: "not.empty" };
    try {
      store.remove(target);
    } catch {
      return { ok: false, reason: "io.failed" };
    }
    return { ok: true };
  };
  const scanManuscript = (projectId) => {
    const files = [];
    for (const root of DOC_ROOTS) {
      const entries = store.walk(`${projectId}/${root}`, MANUSCRIPT_MAX_DEPTH, MAX_DOCS * 4);
      files.push(...entries.filter((e) => e.isFile).map((e) => e.path));
    }
    const pmd = new Set(files.filter(isPmd).map(stemOf));
    const isMirror = (path) => (store.read(path) ?? "").startsWith(MIRROR_MARK);
    return files.filter((path) => isPmd(path) ? true : !pmd.has(stemOf(path)) && !isMirror(path)).sort((a, b) => a.localeCompare(b, "zh-Hans-CN"));
  };
  const reconcile = (projectId, options = {}) => {
    const persist = options.persist ?? true;
    const present = scanManuscript(projectId);
    const presentSet = new Set(present);
    const existing = readProjectFile(projectId);
    if (!existing) {
      const rebuilt = {
        schemaVersion: 1,
        title: projectId,
        order: present,
        updatedAt: new Date().toISOString()
      };
      if (persist)
        writeProjectFile(projectId, rebuilt);
      return { file: rebuilt, present, adopted: present.length };
    }
    const kept = existing.order.filter((p) => presentSet.has(p));
    const known = new Set(kept);
    const added = present.filter((p) => !known.has(p));
    const changed = kept.length !== existing.order.length || added.length > 0;
    const file = {
      ...existing,
      order: [...kept, ...added],
      ...changed ? { updatedAt: new Date().toISOString() } : {}
    };
    if (changed && persist)
      writeProjectFile(projectId, file);
    return { file, present, adopted: added.length };
  };
  const metaCache = new Map;
  const metaOf = (path, order) => {
    const content = readDocContent(store, path);
    if (content === null)
      throw new DocError(isPmd(path) ? "io.failed" : "not.found");
    const stat = store.stat(path);
    return {
      docId: path,
      path,
      projectId: projectIdOf(path),
      title: titleOf(path),
      rev: revOfBytes(content.bytes),
      bytes: content.bytes.byteLength,
      mtimeMs: Math.round(stat?.mtimeMs ?? 0),
      order,
      words: countWords(content.markdown),
      kind: content.kind
    };
  };
  const readDraft = (docId) => {
    const raw = store.read(draftPath(docId));
    if (raw === null)
      return null;
    try {
      const parsed = JSON.parse(raw);
      if (parsed.docId !== docId || typeof parsed.baseRev !== "string" || typeof parsed.rev !== "string" || typeof parsed.text !== "string" || typeof parsed.at !== "number") {
        return null;
      }
      return {
        docId,
        baseRev: parsed.baseRev,
        rev: parsed.rev,
        text: parsed.text,
        at: parsed.at,
        stale: false
      };
    } catch {
      return null;
    }
  };
  const clearDraft = (docId) => {
    store.remove(draftPath(docId));
  };
  const pmdBytesOf = (req, kind) => {
    if (typeof req.pmd === "string" && req.pmd !== "") {
      const decoded = decodePmd(req.pmd);
      if (decoded.ok)
        return encoder.encode(encodePmd(decoded.doc, kind));
      return encoder.encode(req.pmd);
    }
    return encoder.encode(encodePmd(loadMarkdown(req.text).doc, kind));
  };
  const writeMirror = (path, pmdBytes) => {
    const decoded = decodePmd(decoder.decode(pmdBytes));
    if (!decoded.ok)
      return;
    store.write(mirrorOf(path), `${MIRROR_MARK}
${serializeMarkdown(decoded.doc).markdown}`);
  };
  const draftFor = (docId, fileRev) => {
    const draft = readDraft(docId);
    if (!draft)
      return;
    if (draft.rev === fileRev) {
      clearDraft(docId);
      return;
    }
    return { rev: draft.rev, baseRev: draft.baseRev, at: draft.at, stale: draft.baseRev !== fileRev };
  };
  const projectMeta = (projectId) => {
    const present = scanManuscript(projectId);
    const file = readProjectFile(projectId);
    let bytes = 0;
    for (const path of present)
      bytes += store.stat(path)?.size ?? 0;
    const updated = file ? Date.parse(file.updatedAt) : Number.NaN;
    const updatedAt = Number.isFinite(updated) ? updated : 0;
    const signature = `${present.length}|${bytes}|${updatedAt}`;
    const cached = wordsCache.get(projectId);
    let words = cached !== undefined && cached.signature === signature ? cached.words : -1;
    if (words < 0) {
      words = 0;
      for (const path of present) {
        const content = readDocContent(store, path);
        if (content !== null)
          words += countWords(content.markdown);
      }
      wordsCache.set(projectId, { signature, words });
    }
    return {
      id: projectId,
      title: file?.title ?? projectId,
      docCount: present.length,
      words,
      bytes,
      updatedAt
    };
  };
  const projectIds = () => {
    const entries = store.walk("", 2, MAX_DOCS);
    const ids = new Set;
    for (const entry of entries) {
      if (!entry.isDir)
        continue;
      if (entry.path.includes("/"))
        continue;
      if (entry.path.startsWith("."))
        continue;
      ids.add(entry.path);
    }
    return [...ids];
  };
  return {
    list(projectId) {
      const { file, adopted } = reconcile(projectId, { persist: false });
      const docs = file.order.map((path, index) => {
        const stamp = Math.round(store.stat(path)?.mtimeMs ?? 0);
        const hit = metaCache.get(path);
        if (hit !== undefined && Math.round(hit.mtimeMs) === stamp) {
          return { ...hit.meta, order: index };
        }
        const meta = metaOf(path, index);
        metaCache.set(path, { mtimeMs: meta.mtimeMs, meta });
        return meta;
      });
      return { ok: true, projectId, docs, adopted, assets: scanAssets(projectId) };
    },
    digest(projectId, limit = 200) {
      const { file } = reconcile(projectId, { persist: false });
      const docs = file.order.slice(0, Math.max(0, limit)).map((path, index) => {
        const content = readDocContent(store, path);
        const text = content === null ? "" : content.markdown;
        const plain = text.replace(/^#{1,6}\s*/gm, "").replace(/[*_`>]/g, "").replace(/\s+/g, " ").trim();
        return { docId: path, title: metaOf(path, index).title, digest: plain.slice(0, 80) };
      });
      return { ok: true, projectId, docs };
    },
    open(docId) {
      const content = readDocContent(store, docId);
      if (content === null) {
        return { ok: false, reason: store.exists(docId) ? "io.failed" : "not.found" };
      }
      const fileRev = revOfBytes(content.bytes);
      const projectId = projectIdOf(docId);
      const order = readProjectFile(projectId)?.order.indexOf(docId) ?? -1;
      const draft = draftFor(docId, fileRev);
      return {
        ok: true,
        meta: metaOf(docId, order),
        text: content.markdown,
        ...content.pmd === null ? {} : { pmd: content.pmd },
        ...draft === undefined ? {} : { draft }
      };
    },
    stat(docId) {
      const bytes = store.readRaw(docId);
      if (bytes === null)
        return null;
      const projectId = projectIdOf(docId);
      const order = readProjectFile(projectId)?.order.indexOf(docId) ?? -1;
      return metaOf(docId, order);
    },
    save(req) {
      const { doc, baseRev, text } = req;
      if (doc.docId !== doc.path)
        return { ok: false, reason: "doc.mismatch" };
      const current = store.readRaw(doc.path);
      if (current === null)
        return { ok: false, reason: "not.found" };
      const previousKind = readDocContent(store, doc.path)?.kind ?? "chapter";
      const nextKind = req.kind ?? previousKind;
      const nextBytes = isPmd(doc.path) ? pmdBytesOf(req, nextKind) : encoder.encode(text);
      const currentRev = revOfBytes(current);
      const nextRev = revOfBytes(nextBytes);
      if (nextRev === currentRev) {
        clearDraft(doc.path);
        const stat = store.stat(doc.path);
        return { ok: true, rev: currentRev, bytes: current.byteLength, mtimeMs: Math.round(stat?.mtimeMs ?? 0) };
      }
      if (baseRev !== currentRev)
        return { ok: false, reason: "conflict", rev: currentRev };
      if (isPmd(doc.path)) {
        store.writeBytes(doc.path, nextBytes);
        writeMirror(doc.path, nextBytes);
      } else {
        store.write(doc.path, text);
      }
      clearDraft(doc.path);
      const savedText = isPmd(doc.path) ? markdownOf(decoder.decode(nextBytes)) : text;
      if (savedText !== null)
        recordStats(projectIdOf(doc.path), doc.path, countWords(savedText));
      const stat = store.stat(doc.path);
      return { ok: true, rev: nextRev, bytes: nextBytes.byteLength, mtimeMs: Math.round(stat?.mtimeMs ?? 0) };
    },
    saveAsset(docId, dataUrl) {
      if (!store.exists(docId))
        return { ok: false, reason: "not.found" };
      return saveAsset(docId, dataUrl);
    },
    removeAsset(projectId, name) {
      return removeAsset(projectId, name);
    },
    renameFolder(projectId, from, to) {
      return renameFolder(projectId, from, to);
    },
    createFolder(projectId, dir) {
      return createFolder(projectId, dir);
    },
    moveDoc(docId, dir) {
      return moveDoc(docId, dir);
    },
    stats(projectId) {
      const stats = readStats(projectId);
      const total = Object.values(stats.docs).reduce((sum, words) => sum + words, 0);
      const today = new Date().toLocaleDateString("sv-SE");
      const days = [];
      for (let back = 29;back >= 0; back -= 1) {
        const date = new Date(Date.now() - back * 86400000).toLocaleDateString("sv-SE");
        days.push({ date, added: stats.days[date] ?? 0 });
      }
      return { ok: true, total, today: stats.days[today] ?? 0, days };
    },
    workspaceGet(projectId) {
      return { ok: true, prefs: readWorkspace(projectId) };
    },
    workspaceSet(projectId, patch) {
      return writeWorkspace(projectId, patch);
    },
    removeFolder(projectId, dir) {
      return removeFolder(projectId, dir);
    },
    create(projectId, title, afterDocId, dir, kind) {
      const { file } = reconcile(projectId);
      const slug = slugOf(title);
      if (slug === "")
        return { ok: false, reason: "title.invalid" };
      if (hasTitle(file.order, slug))
        return { ok: false, reason: "exists" };
      let maxSeq = 0;
      for (const path of file.order) {
        const m = /^(\d+)-/.exec(basenameOf(path));
        if (m)
          maxSeq = Math.max(maxSeq, Number(m[1]));
      }
      const folder = dir === undefined || dir === "" ? manuscriptDir(projectId) : normalizeDir(projectId, dir);
      if (folder === null)
        return { ok: false, reason: "params.invalid" };
      let path = "";
      for (let seq = maxSeq + 1;seq < maxSeq + 200; seq += 1) {
        const candidate = `${folder}/${String(seq).padStart(3, "0")}-${slug}${PMD_EXT}`;
        if (!store.exists(candidate)) {
          path = candidate;
          break;
        }
      }
      if (path === "")
        return { ok: false, reason: "io.failed" };
      const empty = encoder.encode(encodePmd(loadMarkdown("").doc, kind ?? "chapter"));
      store.writeBytes(path, empty);
      writeMirror(path, empty);
      const at = afterDocId ? file.order.indexOf(afterDocId) : -1;
      const order = [...file.order];
      order.splice(at >= 0 ? at + 1 : order.length, 0, path);
      writeProjectFile(projectId, { ...file, order, updatedAt: new Date().toISOString() });
      return { ok: true, meta: metaOf(path, order.indexOf(path)), text: "" };
    },
    rename(docId, title) {
      if (!store.exists(docId))
        return { ok: false, reason: "not.found" };
      const slug = slugOf(title);
      if (slug === "")
        return { ok: false, reason: "title.invalid" };
      const projectId = projectIdOf(docId);
      const current = basenameOf(docId);
      const seq = /^(\d+)-/.exec(current)?.[1];
      const parent = docId.slice(0, docId.lastIndexOf("/"));
      const target = `${parent}/${seq === undefined ? "" : `${seq}-`}${slug}${isPmd(docId) ? PMD_EXT : MD_EXT}`;
      const { file } = reconcile(projectId);
      const index = file.order.indexOf(docId);
      if (target === docId)
        return { ok: true, meta: metaOf(docId, index) };
      if (store.exists(target))
        return { ok: false, reason: "exists" };
      if (hasTitle(file.order.filter((path) => path !== docId), slug))
        return { ok: false, reason: "exists" };
      store.move(docId, target);
      if (store.exists(mirrorOf(docId)) && !store.exists(mirrorOf(target))) {
        store.move(mirrorOf(docId), mirrorOf(target));
      }
      migrateDocSidecars(docId, target);
      const order = file.order.map((p) => p === docId ? target : p);
      const aliases = withAlias(file.aliases, titleOf(docId), titleOf(target));
      writeProjectFile(projectId, { ...file, order, aliases, updatedAt: new Date().toISOString() });
      return { ok: true, meta: metaOf(target, order.indexOf(target)) };
    },
    reorder(projectId, docId, before) {
      const { file } = reconcile(projectId);
      if (!file.order.includes(docId))
        return { ok: false, reason: "not.found" };
      const next = file.order.filter((p) => p !== docId);
      if (before === undefined || before === null || before === "") {
        next.push(docId);
      } else {
        if (before === docId)
          return { ok: true, order: file.order };
        const at = next.indexOf(before);
        if (at < 0)
          return { ok: false, reason: "params.invalid" };
        next.splice(at, 0, docId);
      }
      writeProjectFile(projectId, { ...file, order: next, updatedAt: new Date().toISOString() });
      return { ok: true, order: next };
    },
    snapshot(docId, reason) {
      const label = (reason ?? "").slice(0, 120);
      return { ok: true, snapshot: takeSnapshot(docId, label) };
    },
    listSnapshots(docId) {
      if (!store.exists(docId))
        return { ok: false, reason: "not.found" };
      return { ok: true, snapshots: listSnapshotRefs(docId) };
    },
    restoreSnapshot(docId, id, baseRev) {
      if (id === "" || id.includes("/") || id.includes("\\"))
        return { ok: false, reason: "path.invalid" };
      const current = store.readRaw(docId);
      if (current === null)
        return { ok: false, reason: "not.found" };
      const currentRev = revOfBytes(current);
      if (baseRev !== currentRev)
        return { ok: false, reason: "conflict", rev: currentRev };
      const dir = snapshotDir(docId);
      const snapExt = store.exists(`${dir}/${id}${PMD_EXT}`) ? PMD_EXT : MD_EXT;
      const snap = store.readRaw(`${dir}/${id}${snapExt}`);
      if (snap === null)
        return { ok: false, reason: "not.found" };
      if (snapExt !== (isPmd(docId) ? PMD_EXT : MD_EXT))
        return { ok: false, reason: "not.found" };
      takeSnapshot(docId, "before restore");
      store.writeBytes(docId, snap);
      if (isPmd(docId))
        writeMirror(docId, snap);
      clearDraft(docId);
      return { ok: true, rev: revOfBytes(store.readRaw(docId)), bytes: snap.byteLength };
    },
    diffSnapshot(docId, id) {
      if (id === "" || id.includes("/") || id.includes("\\"))
        return { ok: false, reason: "path.invalid" };
      const before = snapshotMarkdown(docId, id);
      if (before === null)
        return { ok: false, reason: "not.found" };
      const current = readDocContent(store, docId);
      if (current === null)
        return { ok: false, reason: "not.found" };
      const summary = diffLines(before, current.markdown);
      return { ok: true, ops: summary.ops, added: summary.added, removed: summary.removed };
    },
    draft(docId, baseRev, text) {
      if (!store.exists(docId))
        return { ok: false, reason: "not.found" };
      const bytes = encoder.encode(text);
      if (bytes.byteLength > MAX_DRAFT_BYTES)
        return { ok: false, reason: "io.failed" };
      const rev = revOfBytes(bytes);
      const existing = readDraft(docId);
      if (existing && existing.rev === rev && existing.baseRev === baseRev) {
        return { ok: true, at: existing.at };
      }
      const at = Date.now();
      const payload = { docId, baseRev, rev, text, at, stale: false };
      store.write(draftPath(docId), JSON.stringify(payload));
      return { ok: true, at };
    },
    recover(docId, action) {
      const draft = readDraft(docId);
      if (!draft)
        return { ok: false, reason: "not.found" };
      if (action === "discard") {
        clearDraft(docId);
        return { ok: true };
      }
      return { ok: true, text: draft.text, baseRev: draft.baseRev };
    },
    remove(docId) {
      if (!store.exists(docId))
        return { ok: false, reason: "not.found" };
      const projectId = projectIdOf(docId);
      const { file } = reconcile(projectId);
      const name = basenameOf(docId);
      let ts = Date.now();
      while (store.exists(`${trashDir(projectId)}/${ts}-${name}`))
        ts += 1;
      const trashId = `${ts}-${name}`;
      store.move(docId, `${trashDir(projectId)}/${trashId}`);
      const mirror = mirrorOf(docId);
      if (store.exists(mirror))
        store.remove(mirror);
      clearDraft(docId);
      const order = file.order.filter((p) => p !== docId);
      if (order.length !== file.order.length) {
        writeProjectFile(projectId, { ...file, order, updatedAt: new Date().toISOString() });
      }
      return { ok: true, trashId };
    },
    listTrash(projectId) {
      const entries = store.walk(trashDir(projectId), 2, MAX_DOCS);
      return entries.filter((e) => e.isFile).map((e) => {
        const id = basenameOf(e.path);
        return { id, name: trashNameOf(id), at: trashAtOf(id), bytes: e.size };
      }).sort((a, b) => b.at - a.at);
    },
    restore(projectId, trashId) {
      if (trashId === "" || trashId.includes("/") || trashId.includes("\\")) {
        return { ok: false, reason: "path.invalid" };
      }
      const from = `${trashDir(projectId)}/${trashId}`;
      if (!store.exists(from))
        return { ok: false, reason: "not.found" };
      const { file } = reconcile(projectId);
      const original = trashNameOf(trashId);
      let target = `${manuscriptDir(projectId)}/${original}`;
      if (store.exists(target)) {
        const stem = stemOf(original);
        const ext = isPmd(original) ? PMD_EXT : MD_EXT;
        for (let n = 2;n < 100; n += 1) {
          const candidate = `${manuscriptDir(projectId)}/${stem}-${n}${ext}`;
          if (!store.exists(candidate)) {
            target = candidate;
            break;
          }
        }
      }
      store.move(from, target);
      writeProjectFile(projectId, { ...file, order: [...file.order, target], updatedAt: new Date().toISOString() });
      return { ok: true, meta: metaOf(target, file.order.length) };
    },
    projectList() {
      const projects = projectIds().map((id) => projectMeta(id));
      projects.sort((a, b) => b.updatedAt - a.updatedAt);
      return { ok: true, projects };
    },
    projectCreate(title) {
      const slug = slugOf(title);
      if (slug === "")
        return { ok: false, reason: "title.invalid" };
      if (store.exists(`${slug}/${PROJECT_FILE}`))
        return { ok: false, reason: "exists" };
      writeProjectFile(slug, {
        schemaVersion: 1,
        title,
        order: [],
        updatedAt: new Date().toISOString()
      });
      return { ok: true, meta: projectMeta(slug) };
    },
    resolve(projectId, title) {
      const wanted = title.trim();
      if (wanted === "")
        return { ok: false, reason: "params.invalid" };
      const { file } = reconcile(projectId, { persist: false });
      const hit = (name) => {
        const path = file.order.find((item) => titleOf(item).toLowerCase() === name.toLowerCase());
        return path ?? null;
      };
      const direct = hit(wanted);
      if (direct !== null)
        return { ok: true, docId: direct };
      let name = wanted;
      for (let hop = 0;hop < 8; hop += 1) {
        const next = file.aliases?.[name];
        if (next === undefined)
          break;
        const path = hit(next);
        if (path !== null)
          return { ok: true, docId: path };
        name = next;
      }
      return { ok: false, reason: "not.found" };
    },
    search(projectId, query, limit, options) {
      const raw = query.trim();
      if (raw === "")
        return { ok: false, reason: "params.invalid" };
      const cap = Math.min(Math.max(limit ?? DEFAULT_SEARCH_LIMIT, 1), 500);
      const flags = options?.caseSensitive === true ? "" : "i";
      const matches = (() => {
        if (options?.regex === true) {
          try {
            const re = new RegExp(raw, flags);
            return (line) => re.test(line);
          } catch {
            return null;
          }
        }
        if (options?.wholeWord === true) {
          if (/[^\x00-\x7f]/.test(raw)) {
            const needle = raw.toLowerCase();
            return (line) => line.toLowerCase().includes(needle);
          }
          const escaped = raw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
          const re = new RegExp(`\\b${escaped}\\b`, flags);
          return (line) => re.test(line);
        }
        if (options?.caseSensitive === true)
          return (line) => line.includes(raw);
        const needle = raw.toLowerCase();
        return (line) => line.toLowerCase().includes(needle);
      })();
      if (matches === null)
        return { ok: false, reason: "params.invalid" };
      const { file } = reconcile(projectId, { persist: false });
      const hits = [];
      let truncated = false;
      const files = file.order.length > 0 ? file.order : scanManuscript(projectId);
      for (const path of files.slice(0, MAX_SEARCH_FILES)) {
        const content = readDocContent(store, path);
        if (content === null)
          continue;
        const text = content.markdown;
        const title = titleOf(path);
        const lines = text.split(`
`);
        for (let i = 0;i < lines.length; i += 1) {
          const line = lines[i] ?? "";
          if (!matches(line))
            continue;
          hits.push({ docId: path, title, line: i + 1, text: line.trim().slice(0, SNIPPET_MAX) });
          if (hits.length >= cap) {
            truncated = true;
            break;
          }
        }
        if (truncated)
          break;
      }
      return { ok: true, hits, truncated };
    }
  };
}
function reasonOf(err) {
  if (err instanceof DocError)
    return err.reason;
  if (err instanceof PathRejected)
    return "path.invalid";
  return "io.failed";
}
// plugins/manuscript/locales/en.ts
var en = {
  "tessera.manuscript.title": "Manuscripts",
  "tessera.manuscript.activated": "Library ready"
};

// plugins/manuscript/locales/zh-cn.ts
var zhCN = {
  "tessera.manuscript.title": "\u6587\u7A3F",
  "tessera.manuscript.activated": "\u6587\u7A3F\u5E93\u5DF2\u5C31\u7EEA"
};

// plugins/manuscript/src/index.ts
function requireString(params, field) {
  const value = params?.[field];
  if (typeof value !== "string" || value === "")
    throw new DocError("params.invalid");
  return value;
}
function optionalString(params, field) {
  const value = params?.[field];
  return typeof value === "string" && value !== "" ? value : undefined;
}
function safe(fn) {
  try {
    return fn();
  } catch (err) {
    return { ok: false, reason: reasonOf(err) };
  }
}
function parseSave(params) {
  const p = params ?? {};
  const doc = p.doc;
  if (typeof doc?.docId !== "string" || typeof doc.path !== "string")
    throw new DocError("params.invalid");
  if (typeof p.baseRev !== "string" || p.baseRev === "")
    throw new DocError("params.invalid");
  if (typeof p.text !== "string")
    throw new DocError("params.invalid");
  return {
    doc: { docId: doc.docId, path: doc.path },
    baseRev: p.baseRev,
    text: p.text,
    ...typeof p.clientSeq === "number" ? { clientSeq: p.clientSeq } : {}
  };
}
var definition = {
  manifest: {
    apiVersion: 2,
    id: "tessera.manuscript",
    kind: "official",
    version: "0.1.0",
    title: "tessera.manuscript.title",
    activation: ["onStartup"],
    implements: ["fs", "docs"],
    requires: { services: ["library.root"], plugins: [] },
    contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] }
  },
  activate(ctx) {
    const root = ctx.services.get("library.root");
    const store = createLibraryStore(root);
    const docs = createDocumentService(store);
    ctx.implement("fs", {
      exists: (path) => store.exists(path),
      stat: (path) => store.stat(path),
      list: (path) => store.list(path),
      read: (path) => store.read(path),
      write: (path, text) => store.write(path, text),
      remove: (path) => store.remove(path)
    });
    ctx.implement("docs", {
      list: (projectId) => docs.list(projectId),
      open: (docId) => docs.open(docId),
      stat: (docId) => docs.stat(docId)
    });
    ctx.handle("docsList", (params) => safe(() => docs.list(requireString(params, "projectId"))));
    ctx.handle("docOpen", (params) => safe(() => docs.open(requireString(params, "docId"))));
    ctx.handle("docSave", (params) => safe(() => docs.save(parseSave(params))));
    ctx.handle("docCreate", (params) => safe(() => docs.create(requireString(params, "projectId"), requireString(params, "title"), optionalString(params, "afterDocId"), optionalString(params, "dir"), (() => {
      const value = params?.kind;
      return value === "chapter" || value === "note" || value === "setting" ? value : undefined;
    })())));
    ctx.handle("docRename", (params) => safe(() => docs.rename(requireString(params, "docId"), requireString(params, "title"))));
    ctx.handle("docResolve", (params) => safe(() => docs.resolve(requireString(params, "projectId"), requireString(params, "title"))));
    ctx.handle("docReorder", (params) => {
      const { before } = params ?? {};
      return safe(() => {
        const projectId = requireString(params, "projectId");
        const docId = requireString(params, "docId");
        if (before !== undefined && before !== null && typeof before !== "string")
          throw new DocError("params.invalid");
        return docs.reorder(projectId, docId, before);
      });
    });
    ctx.handle("docSnapshot", (params) => safe(() => docs.snapshot(requireString(params, "docId"), optionalString(params, "reason"))));
    ctx.handle("docListSnapshots", (params) => safe(() => docs.listSnapshots(requireString(params, "docId"))));
    ctx.handle("docRestoreSnapshot", (params) => {
      const { id, baseRev } = params ?? {};
      return safe(() => {
        const docId = requireString(params, "docId");
        if (typeof id !== "string" || id === "")
          throw new DocError("params.invalid");
        if (typeof baseRev !== "string" || baseRev === "")
          throw new DocError("params.invalid");
        return docs.restoreSnapshot(docId, id, baseRev);
      });
    });
    ctx.handle("docDigest", (params) => {
      const raw = params ?? {};
      const limit = typeof raw.limit === "number" ? raw.limit : undefined;
      return safe(() => docs.digest(requireString(params, "projectId"), limit));
    });
    ctx.handle("docStats", (params) => safe(() => docs.stats(requireString(params, "projectId"))));
    ctx.handle("docSnapshotDiff", (params) => {
      const { id } = params ?? {};
      return safe(() => {
        const docId = requireString(params, "docId");
        if (typeof id !== "string" || id === "")
          throw new DocError("params.invalid");
        return docs.diffSnapshot(docId, id);
      });
    });
    ctx.handle("docDraft", (params) => {
      const p = params ?? {};
      return safe(() => {
        const docId = requireString(params, "docId");
        if (typeof p.baseRev !== "string" || p.baseRev === "")
          throw new DocError("params.invalid");
        if (typeof p.text !== "string")
          throw new DocError("params.invalid");
        return docs.draft(docId, p.baseRev, p.text);
      });
    });
    ctx.handle("docRecover", (params) => {
      const { action } = params ?? {};
      return safe(() => {
        const docId = requireString(params, "docId");
        if (action !== "accept" && action !== "discard")
          throw new DocError("params.invalid");
        return docs.recover(docId, action);
      });
    });
    ctx.handle("docRemove", (params) => safe(() => docs.remove(requireString(params, "docId"))));
    ctx.handle("docAsset", (params) => safe(() => docs.saveAsset(requireString(params, "docId"), requireString(params, "data"))));
    ctx.handle("assetRemove", (params) => safe(() => docs.removeAsset(requireString(params, "projectId"), requireString(params, "name"))));
    ctx.handle("folderRename", (params) => safe(() => docs.renameFolder(requireString(params, "projectId"), requireString(params, "from"), requireString(params, "to"))));
    ctx.handle("docMove", (params) => safe(() => docs.moveDoc(requireString(params, "docId"), optionalString(params, "dir") ?? "")));
    ctx.handle("workspaceGet", (params) => safe(() => docs.workspaceGet(requireString(params, "projectId"))));
    ctx.handle("workspaceSet", (params) => {
      const patch = (params ?? {}).patch;
      if (patch === null || typeof patch !== "object" || Array.isArray(patch)) {
        throw new DocError("params.invalid");
      }
      return safe(() => docs.workspaceSet(requireString(params, "projectId"), patch));
    });
    ctx.handle("folderCreate", (params) => safe(() => docs.createFolder(requireString(params, "projectId"), requireString(params, "dir"))));
    ctx.handle("folderRemove", (params) => safe(() => docs.removeFolder(requireString(params, "projectId"), requireString(params, "dir"))));
    ctx.handle("docListTrash", (params) => safe(() => docs.listTrash(requireString(params, "projectId"))));
    ctx.handle("docRestore", (params) => safe(() => docs.restore(requireString(params, "projectId"), requireString(params, "trashId"))));
    ctx.handle("projectList", () => safe(() => docs.projectList()));
    ctx.handle("projectCreate", (params) => safe(() => docs.projectCreate(requireString(params, "title"))));
    ctx.handle("projectSearch", (params) => {
      const { limit, caseSensitive, wholeWord, regex } = params ?? {};
      return safe(() => docs.search(requireString(params, "projectId"), requireString(params, "query"), typeof limit === "number" ? limit : undefined, { caseSensitive: caseSensitive === true, wholeWord: wholeWord === true, regex: regex === true }));
    });
    ctx.log("info", "tessera.manuscript.activated");
  }
};
export {
  definition
};
