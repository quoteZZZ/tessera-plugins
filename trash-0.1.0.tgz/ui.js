/**
 * trash 插件（前端）：回收站。
 *
 * 它是**侧栏里的一个视图**，不是弹窗：和文件树/大纲/搜索并列。
 * 理由：回收站是"活动区里的一等公民"，切走再切回来内容还在；
 * 弹窗会挡住正文，也没法一边看文稿一边恢复。
 *
 * 壳只给：call、getProjectId、refresh、registerSideView、applyActivity。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  let list = null;
  let empty = null;

  const render = (items) => {
    list.replaceChildren();
    list.hidden = items.length === 0;
    empty.hidden = items.length > 0;
    for (const item of items) {
      const li = document.createElement("li");
      const name = document.createElement("span");
      name.textContent = item.title;
      const when = document.createElement("small");
      when.className = "row-when";
      when.textContent = item.deletedAt === undefined ? "" : ui.t("web.trash.deleted");
      const restore = document.createElement("button");
      restore.type = "button";
      restore.className = "version-restore";
      restore.textContent = ui.t("web.trash.restore");
      restore.addEventListener("click", async () => {
        const res = await ui.call("tessera.manuscript/docRestore", {
          projectId: ui.getProjectId(),
          trashId: item.trashId,
        });
        if (!res.ok) {
          ui.toast("web.status.error", "bad");
          return;
        }
        await ui.refresh();
        await load();
      });
      li.append(name, when, restore);
      list.append(li);
    }
  };

  const load = async () => {
    if (list === null) return;
    const res = await ui.call("tessera.manuscript/docListTrash", { projectId: ui.getProjectId() }).catch(() => null);
    const items = Array.isArray(res) ? res : Array.isArray(res?.items) ? res.items : [];
    render(items);
  };

  const build = (container) => {
    list = document.createElement("ul");
    list.className = "version-list";
    list.hidden = true;

    empty = document.createElement("div");
    empty.className = "sheet-empty";
    empty.hidden = true;
    const label = document.createElement("p");
    label.className = "sheet-empty-title";
    label.textContent = ui.t("web.trash.empty");
    empty.append(label);

    container.append(list, empty);
  };

  ui.registerSideView({
    id: "trash",
    titleKey: "web.trash",
    render: build,
    refresh: () => void load(),
  });
  ui.registerCommand({ id: "trash", title: ui.t("web.trash"), run: () => ui.applyActivity("trash") });
  // 深链与旧调用仍然可用：打开的是侧栏视图，不是弹窗
  window.__tesseraTrashOpen = () => ui.applyActivity("trash");
}
