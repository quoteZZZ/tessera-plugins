// @bun
// examples/clock/src/index.ts
var manifest = {
  apiVersion: 2,
  id: "tessera.clock",
  kind: "community",
  version: "0.1.0",
  title: "clock.title",
  activation: ["onStartup"],
  contributes: {
    locales: [
      { locale: "zh-CN", messages: { "clock.title": "\u65F6\u949F", "clock.hint": "\u5F53\u524D\u65F6\u95F4" } },
      { locale: "en", messages: { "clock.title": "Clock", "clock.hint": "Current time" } }
    ]
  }
};
var definition = {
  manifest,
  activate() {}
};
export {
  definition
};
