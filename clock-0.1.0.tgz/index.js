// @bun
// examples/clock/locales/en.ts
var en = {
  "clock.title": "Clock",
  "clock.hint": "Current time"
};

// examples/clock/locales/zh-cn.ts
var zhCN = {
  "clock.title": "\u65F6\u949F",
  "clock.hint": "\u5F53\u524D\u65F6\u95F4"
};

// examples/clock/src/index.ts
var manifest = {
  apiVersion: 2,
  id: "tessera.clock",
  kind: "community",
  version: "0.1.0",
  title: "clock.title",
  activation: ["onStartup"],
  contributes: {
    locales: [
      { locale: "zh-CN", messages: zhCN },
      { locale: "en", messages: en }
    ]
  }
};
var definition = {
  manifest,
  activate() {}
};
export {
  definition
};
