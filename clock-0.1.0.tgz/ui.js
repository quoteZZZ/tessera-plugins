/**
 * 示例插件的前端：状态栏右侧显示当前时间。
 * 只依赖 TesseraUI 的公开接口，和后端没有任何耦合。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  const tick = (span) => {
    const now = new Date();
    span.textContent = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
    span.title = ui.t("clock.hint");
    window.__tesseraClock = span.textContent;
  };
  ui.registerStatusItem({ id: "clock", slot: "statusbar.right", render: tick });
  // 状态栏重绘会换掉节点：定时找回来再画，示例也要能长期不消失
  setInterval(() => {
    const span = document.querySelector('.sb-item[data-item="clock"]');
    if (span !== null) tick(span);
  }, 30_000);
}
