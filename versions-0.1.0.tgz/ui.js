/**
 * versions 插件（前端）：版本历史。
 *
 * 判定标准照旧：关掉它，编辑与保存完全不受影响；它有自己的状态（快照列表），
 * 界面 DOM 也由它自己创建——壳里既没有弹窗，也没有渲染代码。
 */
const ui = window.TesseraUI;
if (ui !== undefined) {
  let dialog = null;
  let list = null;
  let empty = null;
  let diffBox = null;

  const build = () => {
    if (dialog !== null) return dialog;
    dialog = document.createElement("dialog");
    dialog.className = "settings sheet";
    dialog.id = "plugin-versions";

    const head = document.createElement("div");
    head.className = "sheet-head";
    const title = document.createElement("h2");
    title.textContent = ui.t("web.versions");
    const close = document.createElement("button");
    close.type = "button";
    close.className = "icon-btn sheet-x";
    close.innerHTML = window.TesseraIcons?.svg("close") ?? "";
    close.addEventListener("click", () => dialog.close());
    head.append(title, close);

    list = document.createElement("ul");
    list.className = "version-list";

    empty = document.createElement("div");
    empty.className = "sheet-empty";
    empty.hidden = true;
    const label = document.createElement("p");
    label.className = "sheet-empty-title";
    label.textContent = ui.t("web.version.empty");
    empty.append(label);

    // 比对区：点哪条快照就显示"那条 → 现在"的差异，只读
    diffBox = document.createElement("div");
    diffBox.className = "version-diff";
    diffBox.hidden = true;

    const actions = document.createElement("div");
    actions.className = "dialog-actions";
    const save = document.createElement("button");
    save.type = "button";
    save.textContent = ui.t("web.version.save");
    save.addEventListener("click", async () => {
      const res = await ui.call("tessera.manuscript/docSnapshot", { docId: ui.getCurrentDoc() });
      if (!res.ok) {
        ui.toast("web.status.error", "bad");
        return;
      }
      await load();
    });
    const closeFoot = document.createElement("button");
    closeFoot.type = "button";
    closeFoot.textContent = ui.t("web.close");
    closeFoot.addEventListener("click", () => dialog.close());
    actions.append(save, closeFoot);

    dialog.append(head, list, diffBox, empty, actions);
    document.body.append(dialog);
    return dialog;
  };

  const render = (items) => {
    list.replaceChildren();
    empty.hidden = items.length > 0;
    for (const item of items) {
      const li = document.createElement("li");
      const when = document.createElement("div");
      when.className = "version-when";
      const at = new Date(item.at);
      const main = document.createElement("span");
      main.textContent = at.toLocaleString(navigator.language, {
        month: "numeric",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      });
      when.append(main);

      const reason = document.createElement("small");
      reason.className = "version-reason";
      reason.textContent = item.reason ?? "";

      const restore = document.createElement("button");
      restore.type = "button";
      restore.className = "version-restore";
      restore.textContent = ui.t("web.version.restore");
      restore.addEventListener("click", async () => {
        const res = await ui.call("tessera.manuscript/docRestoreSnapshot", {
          docId: ui.getCurrentDoc(),
          snapshotId: item.id,
        });
        if (!res.ok) {
          ui.toast("web.status.error", "bad");
          return;
        }
        ui.toast("web.status.saved", "ok");
        dialog.close();
      });

      li.append(when, reason, restore);
      li.addEventListener("click", (event) => {
        if (event.target instanceof HTMLElement && event.target.closest(".version-restore") !== null) return;
        for (const row of list.children) row.dataset.active = String(row === li);
        void showDiff(item.id);
      });
      list.append(li);
    }
  };

  /** 取某条快照与"现在"的差异并就地渲染 */
  const showDiff = async (id) => {
    const res = await ui.call("tessera.manuscript/docSnapshotDiff", { docId: ui.getCurrentDoc(), id });
    if (!res.ok) {
      ui.toast("web.status.error", "bad");
      return;
    }
    diffBox.replaceChildren();
    diffBox.hidden = false;

    const summary = document.createElement("div");
    summary.className = "version-diff-summary";
    summary.textContent = `+${res.added} −${res.removed}`;
    diffBox.append(summary);

    const body = document.createElement("div");
    body.className = "version-diff-body";
    for (const op of res.ops) {
      const line = document.createElement("div");
      line.className = `version-diff-line ${op.type}`;
      line.textContent = op.text === "" ? " " : op.text;
      body.append(line);
    }
    diffBox.append(body);
  };

  const load = async () => {
    const res = await ui.call("tessera.manuscript/docListSnapshots", { docId: ui.getCurrentDoc() });
    render(res.ok ? res.snapshots : []);
  };

  const open = async () => {
    const node = build();
    ui.openModal(node);
    if (ui.getCurrentDoc() === "") {
      render([]);
      ui.toast("web.version.needDoc", "bad");
      return;
    }
    await load();
  };

  ui.registerCommand({ id: "versions", title: ui.t("web.versions"), run: () => void open() });
  window.__tesseraVersionsOpen = open;
}
