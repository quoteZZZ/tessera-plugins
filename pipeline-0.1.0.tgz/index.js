// @bun
// plugins/pipeline/locales/en.ts
var en = {
  "tessera.pipeline.title": "Review",
  "tessera.pipeline.activated": "pipeline activated: v1 reviews one doc, never edits text",
  "tessera.pipeline.reviewed": "reviewed: {docId} (truncated={truncated})"
};

// plugins/pipeline/locales/zh-cn.ts
var zhCN = {
  "tessera.pipeline.title": "\u5BA1\u6539",
  "tessera.pipeline.activated": "\u5BA1\u6539\u53F6\u5DF2\u6FC0\u6D3B\uFF1Av1 \u53EA\u505A\u201C\u5BA1\u4E00\u7AE0\u201D\uFF0C\u4E0D\u6539\u6B63\u6587",
  "tessera.pipeline.reviewed": "\u5DF2\u5BA1\uFF1A{docId}\uFF08\u622A\u65AD={truncated}\uFF09"
};

// plugins/pipeline/src/index.ts
var MAX_CHAPTER_CHARS = 20000;
var REVIEW_DIR = ".tessera/pipeline/reviews";
var MAX_READ_BYTES = 4 * 1024 * 1024;
var SYSTEM_PROMPT = [
  "You are a senior fiction editor.",
  "Reply in the same language as the manuscript.",
  "Return ONLY a JSON object, no prose and no code fence:",
  '{"summary":"...","findings":[{"quote":"exact sentence from the manuscript","kind":"pacing|logic|voice|clarity|other","severity":"high|medium|low","suggestion":"..."}]}',
  "quote must be copied verbatim from the manuscript and at most 80 characters; give 1 to 8 findings, most important first.",
  "Do not rewrite the text and do not quote whole paragraphs."
].join(`
`);
var KINDS = new Set(["pacing", "logic", "voice", "clarity", "other"]);
var SEVERITIES = new Set(["high", "medium", "low"]);
var MAX_QUOTE = 200;
var MAX_FINDINGS = 8;
function parseReview(text) {
  const fence = /```(?:json)?\s*([\s\S]*?)```/i.exec(text);
  const body = fence?.[1] ?? (() => {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    return start >= 0 && end > start ? text.slice(start, end + 1) : null;
  })();
  if (body === null)
    return null;
  let raw;
  try {
    raw = JSON.parse(body);
  } catch {
    return null;
  }
  if (raw === null || typeof raw !== "object")
    return null;
  const obj = raw;
  if (typeof obj.summary !== "string" || !Array.isArray(obj.findings))
    return null;
  const findings = [];
  for (const item of obj.findings) {
    if (item === null || typeof item !== "object")
      continue;
    const entry = item;
    const quote = typeof entry.quote === "string" ? entry.quote.trim() : "";
    const suggestion = typeof entry.suggestion === "string" ? entry.suggestion.trim() : "";
    if (quote === "" || suggestion === "" || [...quote].length > MAX_QUOTE)
      continue;
    const kind = typeof entry.kind === "string" && KINDS.has(entry.kind) ? entry.kind : "other";
    const severity = typeof entry.severity === "string" && SEVERITIES.has(entry.severity) ? entry.severity : "medium";
    findings.push({ quote, kind, severity, suggestion });
    if (findings.length >= MAX_FINDINGS)
      break;
  }
  const summary = obj.summary.trim();
  if (summary === "" && findings.length === 0)
    return null;
  return { summary, findings };
}
function renderReview(summary, findings) {
  const lines = [summary];
  for (const finding of findings) {
    lines.push("", `- [${finding.severity}/${finding.kind}] ${finding.quote} \u2192 ${finding.suggestion}`);
  }
  return lines.join(`
`);
}
function modelFailure(reason, detail) {
  return { ok: false, reason: "model.failed", detail: detail === undefined ? reason : `${reason}: ${detail}` };
}
var definition = {
  manifest: {
    apiVersion: 2,
    id: "tessera.pipeline",
    kind: "official",
    version: "0.1.0",
    title: "tessera.pipeline.title",
    activation: ["onStartup"],
    requires: { services: [], plugins: ["tessera.manuscript", "tessera.ai"] },
    contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] }
  },
  activate(ctx) {
    const fs = ctx.resolve("fs");
    const reviewDoc = async (params) => {
      const { projectId, docId, instructions } = params ?? {};
      if (typeof projectId !== "string" || projectId === "")
        return { ok: false, reason: "params.invalid" };
      if (typeof docId !== "string" || docId === "")
        return { ok: false, reason: "params.invalid" };
      const docs = ctx.resolve("docs");
      if (docs === null)
        return { ok: false, reason: "seam.missing" };
      const model = ctx.resolve("model");
      if (model === null)
        return { ok: false, reason: "seam.missing" };
      const opened = docs.open(docId);
      if (!opened.ok) {
        return { ok: false, reason: opened.reason === "not.found" ? "doc.notFound" : "params.invalid" };
      }
      const full = opened.text;
      const truncated = full.length > MAX_CHAPTER_CHARS;
      const body = truncated ? full.slice(0, MAX_CHAPTER_CHARS) : full;
      if (body.trim() === "")
        return { ok: false, reason: "params.invalid", detail: "empty doc" };
      const ask = typeof instructions === "string" && instructions.trim() !== "" ? `

Also pay special attention to: ${instructions.trim()}` : "";
      const progress = (stage) => ctx.emit("tessera.pipeline:progress", { docId, stage });
      progress("model");
      const started = Date.now();
      const result = await model.invoke({
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: `Manuscript: ${opened.meta.title}

${body}${ask}` }
        ]
      });
      if (!result.ok)
        return modelFailure(result.reason, result.detail);
      progress("saving");
      const parsed = parseReview(result.text);
      const review = parsed === null ? result.text : renderReview(parsed.summary, parsed.findings);
      const text = `<!-- ${new Date(started).toISOString()} \xB7 ${result.model} \xB7 ${docId} -->

${review}
`;
      let savedTo;
      if (fs !== null) {
        try {
          const slug = docId.replaceAll("/", "_").replace(/\.md$/i, "");
          savedTo = `${projectId}/${REVIEW_DIR}/${slug}-${started}.md`;
          fs.write(savedTo, text);
          if (parsed !== null) {
            fs.write(savedTo.replace(/\.md$/, ".json"), JSON.stringify({ at: started, docId, model: result.model, truncated, ...parsed }, null, 1));
          }
        } catch {
          savedTo = undefined;
        }
      }
      ctx.log("info", "tessera.pipeline.reviewed", { docId, truncated: truncated ? 1 : 0 });
      return {
        ok: true,
        review,
        ...parsed === null ? {} : { summary: parsed.summary, findings: parsed.findings },
        model: result.model,
        ms: Date.now() - started,
        truncated,
        ...savedTo === undefined ? {} : { savedTo }
      };
    };
    ctx.handle("reviewDoc", (params) => reviewDoc(params));
    ctx.handle("listReviews", (params) => {
      const { projectId } = params ?? {};
      if (typeof projectId !== "string" || projectId === "")
        return { ok: false, reason: "params.invalid" };
      if (fs === null)
        return { ok: false, reason: "seam.missing" };
      const dir = `${projectId}/${REVIEW_DIR}`;
      if (!fs.exists(dir))
        return { ok: true, records: [] };
      const records = [];
      for (const name of fs.list(dir)) {
        if (!name.endsWith(".md"))
          continue;
        const raw = fs.read(`${dir}/${name}`);
        if (raw === null)
          continue;
        if (new TextEncoder().encode(raw).byteLength > MAX_READ_BYTES)
          continue;
        const head = /^<!-- (\S+) \u00B7 (\S+) \u00B7 (\S+) -->/.exec(raw);
        records.push({
          id: name,
          docId: head?.[3] ?? "",
          model: head?.[2] ?? "",
          at: head ? Date.parse(head[1] ?? "") || 0 : 0,
          bytes: new TextEncoder().encode(raw).byteLength
        });
      }
      return { ok: true, records: records.sort((a, b) => b.at - a.at) };
    });
    ctx.handle("readReview", (params) => {
      const { projectId, id } = params ?? {};
      if (typeof projectId !== "string" || projectId === "")
        return { ok: false, reason: "params.invalid" };
      if (typeof id !== "string" || !id.endsWith(".md") || id.includes("/") || id.includes("\\") || id.includes("..")) {
        return { ok: false, reason: "params.invalid" };
      }
      if (fs === null)
        return { ok: false, reason: "seam.missing" };
      const raw = fs.read(`${projectId}/${REVIEW_DIR}/${id}`);
      if (raw === null)
        return { ok: false, reason: "doc.notFound" };
      if (new TextEncoder().encode(raw).byteLength > MAX_READ_BYTES)
        return { ok: false, reason: "io.failed" };
      const head = /^<!-- (\S+) \u00B7 (\S+) \u00B7 (\S+) -->/.exec(raw);
      return {
        ok: true,
        detail: {
          id,
          docId: head?.[3] ?? "",
          model: head?.[2] ?? "",
          at: head ? Date.parse(head[1] ?? "") || 0 : 0,
          review: raw.replace(/^<!--[\s\S]*?-->\s*/, "").trim()
        }
      };
    });
    ctx.handle("reviewStats", (params) => {
      const { projectId } = params ?? {};
      if (typeof projectId !== "string" || projectId === "")
        return { ok: false, reason: "params.invalid" };
      if (fs === null)
        return { ok: false, reason: "seam.missing" };
      const stats = {
        total: 0,
        byKind: { pacing: 0, logic: 0, voice: 0, clarity: 0, other: 0 },
        bySeverity: { high: 0, medium: 0, low: 0 }
      };
      const dir = `${projectId}/${REVIEW_DIR}`;
      if (!fs.exists(dir))
        return { ok: true, stats };
      for (const name of fs.list(dir)) {
        if (!name.endsWith(".json"))
          continue;
        const raw = fs.read(`${dir}/${name}`);
        if (raw === null)
          continue;
        let parsed;
        try {
          parsed = JSON.parse(raw);
        } catch {
          continue;
        }
        const findings = parsed.findings;
        if (!Array.isArray(findings))
          continue;
        for (const item of findings) {
          if (item === null || typeof item !== "object")
            continue;
          const entry = item;
          const kind = typeof entry.kind === "string" && KINDS.has(entry.kind) ? entry.kind : "other";
          const severity = typeof entry.severity === "string" && SEVERITIES.has(entry.severity) ? entry.severity : "medium";
          stats.total += 1;
          stats.byKind[kind] += 1;
          stats.bySeverity[severity] += 1;
        }
      }
      return { ok: true, stats };
    });
    ctx.log("info", "tessera.pipeline.activated");
  }
};
export {
  definition,
  parseReview
};
