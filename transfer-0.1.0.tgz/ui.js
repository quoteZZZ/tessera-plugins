/**
 * transfer 插件的前端部分：导出参数（纸张 / 页边距 / 首行缩进）。
 *
 * 右栏「导出预览」已随「右栏只留 AI 面板」下线，`ui.exportPreview()` 暂时没有
 * 调用方；要恢复预览时在这里重新挂 dock 视图，序列化仍留在壳里。
 */
const ui = window.TesseraUI;

if (ui !== undefined) {
  /* 导出参数归本插件：以前在宿主设置表里，插件关掉后那几行还留在页面上。
     `page` 指定落在「高级」页，`order: 5` 让它排在语言/键位那几组前面 */
  ui.registerPrefs({
    id: "plugin.transfer.export",
    titleKey: "pref.sec.export",
    page: "advanced",
    order: 5,
    items: [
      {
        key: "export.paper",
        labelKey: "pref.export.paper",
        type: "select",
        default: "a4",
        options: [
          { value: "a4", labelKey: "pref.opt.a4" },
          { value: "a5", labelKey: "pref.opt.a5" },
          { value: "letter", labelKey: "pref.opt.letter" },
        ],
      },
      {
        key: "export.margin",
        labelKey: "pref.export.margin",
        type: "select",
        default: "normal",
        options: [
          { value: "narrow", labelKey: "pref.opt.narrow" },
          { value: "normal", labelKey: "pref.opt.stdMargin" },
          { value: "wide", labelKey: "pref.opt.wide" },
        ],
      },
      { key: "export.indent", labelKey: "pref.export.indent", type: "range", min: 0, max: 3, step: 1, default: 2, unitKey: "pref.unit.char" },
    ],
  });

}
