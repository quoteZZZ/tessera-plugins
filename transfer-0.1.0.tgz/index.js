// @bun
// plugins/transfer/locales/en.ts
var en = {
  "tessera.transfer.title": "Import / Export",
  "tessera.transfer.activated": "transfer leaf activated (v1 exports only)"
};

// plugins/transfer/locales/zh-cn.ts
var zhCN = {
  "tessera.transfer.title": "\u5BFC\u5165\u5BFC\u51FA",
  "tessera.transfer.activated": "\u5BFC\u5165\u5BFC\u51FA\u53F6\u5DF2\u6FC0\u6D3B\uFF08v1 \u53EA\u505A\u5BFC\u51FA\uFF09"
};

// plugins/transfer/src/index.ts
var EXPORT_DIR = "exports";
var PROJECT_FILE = "project.json";
var MAX_READ_BYTES = 2 * 1024 * 1024;
var definition = {
  manifest: {
    apiVersion: 2,
    id: "tessera.transfer",
    kind: "official",
    version: "0.1.0",
    title: "tessera.transfer.title",
    activation: ["onStartup"],
    requires: { services: ["library.root"], plugins: ["tessera.manuscript"] },
    contributes: { locales: [{ locale: "zh-CN", messages: zhCN }, { locale: "en", messages: en }] }
  },
  activate(ctx) {
    const exportProject = (params) => {
      const { projectId, format } = params ?? {};
      if (typeof projectId !== "string" || projectId === "")
        return { ok: false, reason: "params.invalid" };
      if (format !== undefined && format !== "md")
        return { ok: false, reason: "params.invalid" };
      const docs = ctx.resolve("docs");
      if (docs === null)
        return { ok: false, reason: "seam.missing" };
      const fs = ctx.resolve("fs");
      if (fs === null)
        return { ok: false, reason: "seam.missing" };
      const listed = docs.list(projectId);
      if (!("docs" in listed))
        return { ok: false, reason: "source.failed" };
      if (listed.docs.length === 0)
        return { ok: false, reason: "empty" };
      const sections = [];
      for (const doc of listed.docs) {
        const opened = docs.open(doc.docId);
        if (!opened.ok)
          return { ok: false, reason: "source.failed" };
        const hasHeading = opened.text.trimStart().startsWith("#");
        sections.push(`${hasHeading ? "" : `## ${doc.title}

`}${opened.text.trim()}`);
      }
      let title = projectId;
      try {
        const raw = fs.read(`${projectId}/${PROJECT_FILE}`);
        if (raw !== null) {
          const parsed = JSON.parse(raw);
          if (typeof parsed.title === "string" && parsed.title !== "")
            title = parsed.title;
        }
      } catch {}
      const body = `# ${title}

${sections.join(`

---

`)}
`;
      const path = `${projectId}/${EXPORT_DIR}/${projectId}-${Date.now()}.md`;
      try {
        fs.write(path, body);
      } catch {
        return { ok: false, reason: "write.failed" };
      }
      ctx.log("info", "tessera.transfer.exported", { projectId, docs: listed.docs.length });
      return { ok: true, path, bytes: new TextEncoder().encode(body).byteLength, docs: listed.docs.length };
    };
    ctx.handle("exportProject", (params) => {
      try {
        return exportProject(params);
      } catch {
        return { ok: false, reason: "write.failed" };
      }
    });
    ctx.handle("readExport", (params) => {
      const { path } = params ?? {};
      if (typeof path !== "string" || path === "")
        return { ok: false, reason: "params.invalid" };
      if (!path.includes(`/${EXPORT_DIR}/`) || path.includes(".."))
        return { ok: false, reason: "params.invalid" };
      const fs = ctx.resolve("fs");
      if (fs === null)
        return { ok: false, reason: "seam.missing" };
      const text = fs.read(path);
      if (text === null)
        return { ok: false, reason: "not.found" };
      const bytes = new TextEncoder().encode(text).byteLength;
      if (bytes > MAX_READ_BYTES)
        return { ok: false, reason: "write.failed" };
      return { ok: true, text, bytes };
    });
    ctx.log("info", "tessera.transfer.activated");
  }
};
export {
  definition
};
